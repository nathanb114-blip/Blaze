import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Orientation, TubeSource, VideoCard } from "@/lib/blaze/types";
import { SOURCE_META } from "@/lib/blaze/types";

const MAX_LATER = 400;
const MAX_HISTORY = 400;
const MAX_HIDDEN = 400;

export const REPORT_REASONS = [
  { id: "illegal", label: "Illegal content" },
  { id: "nonconsensual", label: "Non-consensual / revenge" },
  { id: "underage", label: "Involves a minor" },
  { id: "other", label: "Other" },
] as const;

export type ReportReason = (typeof REPORT_REASONS)[number]["id"];

export interface HistoryItem extends VideoCard {
  watchedAt: number;
}

function withSource(v: VideoCard): VideoCard {
  const source = v.source && SOURCE_META[v.source] ? v.source : "eporner";
  return {
    ...v,
    source,
    playMode: v.playMode ?? SOURCE_META[source].playMode,
  };
}

function isVideoCard(value: unknown): value is VideoCard {
  if (!value || typeof value !== "object") return false;
  const video = value as Partial<VideoCard>;
  return typeof video.id === "string" && video.id.length > 0 && video.id.length <= 1_000 &&
    typeof video.title === "string" && video.title.length > 0 && video.title.length <= 2_000;
}

interface TubeState {
  orientation: Orientation;
  net: TubeSource | "all";
  privateSession: boolean;
  autoplay: boolean;
  hiddenIds: string[];
  setOrientation: (o: Orientation) => void;
  setNet: (n: TubeSource | "all") => void;
  setPrivateSession: (on: boolean) => void;
  setAutoplay: (on: boolean) => void;
  isHidden: (id: string) => boolean;
  reportVideo: (id: string, reason: ReportReason) => void;
  clearHidden: () => void;
  later: VideoCard[];
  history: HistoryItem[];
  toggleLater: (v: VideoCard) => void;
  isLater: (id: string) => boolean;
  pushHistory: (v: VideoCard) => void;
  removeLater: (id: string) => void;
  clearLater: () => void;
  clearHistory: () => void;
  progress: Record<string, number>;
  setProgress: (id: string, seconds: number) => void;
  exportSnapshot: () => string;
  importSnapshot: (raw: string) => void;
}

export const useTube = create<TubeState>()(
  persist(
    (set, get) => ({
      orientation: "straight",
      net: "all",
      privateSession: false,
      autoplay: true,
      hiddenIds: [],
      setOrientation: (orientation) => set({ orientation }),
      setNet: (net) => set({ net }),
      setPrivateSession: (privateSession) => set({ privateSession }),
      setAutoplay: (autoplay) => set({ autoplay }),
      isHidden: (id) => get().hiddenIds.includes(id),
      reportVideo: (id, _reason) => {
        const hiddenIds = [id, ...get().hiddenIds.filter((x) => x !== id)].slice(0, MAX_HIDDEN);
        set({
          hiddenIds,
          later: get().later.filter((x) => x.id !== id),
          history: get().history.filter((x) => x.id !== id),
        });
      },
      clearHidden: () => set({ hiddenIds: [] }),
      later: [],
      history: [],
      progress: {},
      toggleLater: (v) => {
        const video = withSource(v);
        const exists = get().later.some((x) => x.id === video.id);
        set({
          later: exists
            ? get().later.filter((x) => x.id !== video.id)
            : [video, ...get().later].slice(0, MAX_LATER),
        });
      },
      isLater: (id) => get().later.some((x) => x.id === id),
      removeLater: (id) => set({ later: get().later.filter((x) => x.id !== id) }),
      pushHistory: (v) => {
        if (get().privateSession) return;
        const video = withSource(v);
        const rest = get().history.filter((x) => x.id !== video.id);
        set({ history: [{ ...video, watchedAt: Date.now() }, ...rest].slice(0, MAX_HISTORY) });
      },
      clearLater: () => set({ later: [] }),
      clearHistory: () => set({ history: [], progress: {} }),
      setProgress: (id, seconds) => {
        if (get().privateSession) return;
        const next = { ...get().progress };
        delete next[id];
        next[id] = seconds;
        const keys = Object.keys(next);
        if (keys.length > 500) delete next[keys[0]!];
        set({ progress: next });
      },
      exportSnapshot: () =>
        JSON.stringify(
          {
            version: 1,
            exportedAt: new Date().toISOString(),
            later: get().later,
            history: get().history,
            progress: get().progress,
            hiddenIds: get().hiddenIds,
            autoplay: get().autoplay,
            orientation: get().orientation,
            net: get().net,
          },
          null,
          2,
        ),
      importSnapshot: (raw) => {
        if (raw.length > 5_000_000) throw new Error("Library file is too large");
        const parsed: unknown = JSON.parse(raw);
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
          throw new Error("Not a BLAZE library file");
        }
        const data = parsed as {
          later?: VideoCard[];
          history?: HistoryItem[];
          progress?: Record<string, number>;
          hiddenIds?: string[];
          autoplay?: boolean;
          orientation?: Orientation;
          net?: TubeSource | "all";
        };
        const hasLater = Array.isArray(data.later);
        const hasHistory = Array.isArray(data.history);
        const hasProgress = Boolean(data.progress) && typeof data.progress === "object";
        if (!hasLater && !hasHistory && !hasProgress && !Array.isArray(data.hiddenIds)) {
          throw new Error("Not a BLAZE library file");
        }
        const later = hasLater ? data.later!.filter(isVideoCard).map(withSource).slice(0, MAX_LATER) : get().later;
        const history = hasHistory
          ? data.history!
              .filter(isVideoCard)
              .map((v) => ({ ...withSource(v), watchedAt: Number.isFinite(v.watchedAt) ? v.watchedAt : Date.now() }))
              .slice(0, MAX_HISTORY)
          : get().history;
        const progress = hasProgress
          ? Object.fromEntries(
              Object.entries(data.progress!)
                .filter(([id, seconds]) => id.length > 0 && id.length <= 1_000 && Number.isFinite(seconds) && seconds >= 0)
                .slice(-500),
            )
          : get().progress;
        const hiddenIds = Array.isArray(data.hiddenIds)
          ? data.hiddenIds.filter((id): id is string => typeof id === "string" && id.length > 0 && id.length <= 1_000).slice(0, MAX_HIDDEN)
          : get().hiddenIds;
        set({
          later,
          history,
          progress,
          hiddenIds,
          autoplay: typeof data.autoplay === "boolean" ? data.autoplay : get().autoplay,
          orientation: data.orientation === "gay" || data.orientation === "trans" || data.orientation === "straight" ? data.orientation : get().orientation,
          net: data.net === "all" || (typeof data.net === "string" && data.net in SOURCE_META) ? data.net : get().net,
        });
      },
    }),
    { name: "blaze-tube" },
  ),
);
