import { createFileRoute, Link } from "@tanstack/react-router";
import { catsForOrientation } from "@/lib/blaze/categories";
import { Shell, usePageTitle } from "@/components/shell";
import { useTube } from "@/store/tube";

export const Route = createFileRoute("/categories")({
  component: CategoriesPage,
});

function CategoriesPage() {
  const orientation = useTube((s) => s.orientation);
  const cats = catsForOrientation(orientation);
  usePageTitle("Categories · BLAZE");

  const grouped = new Map<string, typeof cats>();
  for (const c of cats) {
    const letter = c.label[0]!.toUpperCase();
    const key = /[A-Z]/.test(letter) ? letter : "#";
    const list = grouped.get(key) ?? [];
    list.push(c);
    grouped.set(key, list);
  }
  const letters = [...grouped.keys()].sort();

  return (
    <Shell>
      <h1 className="mb-6 font-display text-3xl tracking-wide">Categories</h1>
      <div className="mb-6 flex flex-wrap gap-1">
        {letters.map((l) => (
          <button
            key={l}
            type="button"
            onClick={() =>
              document.getElementById(`cat-${l}`)?.scrollIntoView({ behavior: "smooth", block: "start" })
            }
            className="flex size-10 items-center justify-center rounded-xs bg-surface-2 text-sm font-semibold text-muted hover:text-accent"
          >
            {l}
          </button>
        ))}
      </div>
      <div className="space-y-8">
        {letters.map((l) => (
          <section key={l} id={`cat-${l}`} className="scroll-mt-20">
            <h2 className="mb-3 font-display text-2xl tracking-wide text-subtle">{l}</h2>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
              {(grouped.get(l) ?? []).map((c) => (
                <Link
                  key={c.slug}
                  to="/cat/$slug"
                  params={{ slug: c.slug }}
                  className="flex h-14 items-center justify-center rounded-sm bg-surface-2 px-3 text-center text-sm font-medium hover:bg-surface-3 hover:text-accent"
                >
                  {c.label}
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </Shell>
  );
}
