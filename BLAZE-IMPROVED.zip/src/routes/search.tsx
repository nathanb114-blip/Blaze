import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { CategoryChips, LoadError, NetworkBar, Pager, Shell, SortBar, usePageTitle } from "@/components/shell";
import { VideoGrid, VideoGridSkeleton } from "@/components/video-card";
import { fetchSearch } from "@/lib/api";
import { isProhibitedText } from "@/lib/blaze/policy";
import type { SortMode } from "@/lib/blaze/types";
import { useTube } from "@/store/tube";

const SORTS = new Set<SortMode>([
  "most-popular",
  "latest",
  "top-rated",
  "longest",
  "top-weekly",
  "top-monthly",
]);

type SearchParams = { q?: string; sort?: SortMode; page?: number };

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>): SearchParams => {
    const out: SearchParams = {};
    if (typeof s.q === "string") out.q = s.q;
    if (typeof s.sort === "string" && SORTS.has(s.sort as SortMode)) out.sort = s.sort as SortMode;
    const page = Number(s.page);
    if (Number.isFinite(page) && page > 1) out.page = page;
    return out;
  },
  component: SearchPage,
});

function SearchPage() {
  const { q = "", sort = "most-popular", page = 1 } = Route.useSearch();
  const navigate = Route.useNavigate();
  const orient = useTube((s) => s.orientation);
  const net = useTube((s) => s.net);
  const query = q.trim();
  const blocked = Boolean(query) && isProhibitedText(query);
  const heading = blocked ? "Search blocked" : query ? `Results for “${query}”` : "Search";
  usePageTitle(blocked ? "Search blocked · BLAZE" : query ? `${query} · BLAZE` : "Search · BLAZE");
  const result = useQuery({
    queryKey: ["search", query, sort, page, orient, net],
    queryFn: () => fetchSearch({ q: query, sort, page, orient, net }),
    enabled: Boolean(query) && !blocked,
  });

  const prevFilter = useRef({ net, orient });
  useEffect(() => {
    if (prevFilter.current.net !== net || prevFilter.current.orient !== orient) {
      prevFilter.current = { net, orient };
      if (page > 1) void navigate({ search: (s) => ({ ...s, page: undefined }) });
    }
  }, [net, orient, page, navigate]);

  return (
    <Shell query={q}>
      <CategoryChips />
      <div className="mb-3 flex items-end justify-between gap-3">
        <h1 className="font-display text-3xl tracking-wide">{heading}</h1>
        {result.data ? (
          <p className="text-xs tabular-nums text-subtle">{result.data.total.toLocaleString()}+ videos</p>
        ) : null}
      </div>
      <NetworkBar />
      <SortBar
        sort={sort}
        onChange={(next) => void navigate({ search: (prev) => ({ ...prev, sort: next, page: 1 }) })}
      />
      {result.isLoading ? (
        <VideoGridSkeleton />
      ) : result.isError ? (
        /blocked/i.test((result.error as Error).message) ? (
          <div className="flex flex-col items-center gap-4 py-16 text-center">
            <p className="max-w-md text-sm text-muted">
              {(result.error as Error).message || "That search is blocked."}
            </p>
            <Link
              to="/"
              className="inline-flex h-11 items-center rounded-sm bg-accent px-5 text-sm font-semibold text-accent-fg hover:bg-accent-hover"
            >
              Browse videos
            </Link>
          </div>
        ) : (
          <LoadError
            message={(result.error as Error).message || "Could not search right now."}
            onRetry={() => void result.refetch()}
          />
        )
      ) : (
        <>
          <VideoGrid videos={result.data?.results ?? []} empty="No videos matched that search." />
          <Pager
            page={page}
            totalPages={result.data?.totalPages ?? 1}
            onPage={(p) => void navigate({ search: (prev) => ({ ...prev, page: p }) })}
          />
        </>
      )}
    </Shell>
  );
}
