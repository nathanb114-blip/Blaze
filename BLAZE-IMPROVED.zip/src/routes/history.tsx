import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock } from "lucide-react";
import { Shell, usePageTitle } from "@/components/shell";
import { VideoGrid } from "@/components/video-card";
import { useTube } from "@/store/tube";

export const Route = createFileRoute("/history")({
  component: HistoryPage,
});

function HistoryPage() {
  const history = useTube((s) => s.history);
  const clearHistory = useTube((s) => s.clearHistory);
  usePageTitle("History · BLAZE");

  return (
    <Shell>
      <div className="mb-4 flex items-end justify-between gap-3">
        <h1 className="font-display text-3xl tracking-wide">Watch history</h1>
        {history.length > 0 ? (
          <button
            type="button"
            onClick={() => {
              if (window.confirm("Clear watch history on this device?")) clearHistory();
            }}
            className="inline-flex h-10 items-center rounded-sm border border-border px-3 text-sm font-medium text-muted hover:bg-surface-2 hover:text-fg"
          >
            Clear
          </button>
        ) : null}
      </div>
      <p className="mb-4 text-xs text-subtle">Stored only on this device. Never sent to the server.</p>
      {history.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-4 py-16 text-center">
          <Clock className="size-10 text-subtle" />
          <p className="max-w-sm text-sm text-muted">You have not watched anything on this device yet.</p>
          <Link
            to="/"
            className="inline-flex h-11 items-center rounded-sm bg-accent px-5 text-sm font-semibold text-accent-fg hover:bg-accent-hover"
          >
            Browse videos
          </Link>
        </div>
      ) : (
        <VideoGrid videos={history} />
      )}
    </Shell>
  );
}
