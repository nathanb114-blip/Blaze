import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { CategoryChips, LoadError, NetworkBar, Pager, Shell, SortBar, usePageTitle } from "@/components/shell";
import { VideoGrid, VideoGridSkeleton } from "@/components/video-card";
import { fetchSearch } from "@/lib/api";
import { categoryBySlug } from "@/lib/blaze/categories";
import type { SortMode } from "@/lib/blaze/types";
import { useTube } from "@/store/tube";

const SORTS = new Set<SortMode>([
  "most-popular",
  "latest",
  "top-rated",
  "longest",
  "top-weekly",
  "top-monthly",
]);

type CatSearch = { sort?: SortMode; page?: number };

export const Route = createFileRoute("/cat/$slug")({
  validateSearch: (s: Record<string, unknown>): CatSearch => {
    const out: CatSearch = {};
    if (typeof s.sort === "string" && SORTS.has(s.sort as SortMode)) out.sort = s.sort as SortMode;
    const page = Number(s.page);
    if (Number.isFinite(page) && page > 1) out.page = page;
    return out;
  },
  component: CategoryPage,
});

function CategoryPage() {
  const { slug } = Route.useParams();
  const { sort = "most-popular", page = 1 } = Route.useSearch();
  const navigate = Route.useNavigate();
  const cat = categoryBySlug(slug);
  const orient = useTube((s) => s.orientation);
  const net = useTube((s) => s.net);
  const query = cat?.query ?? slug.replace(/-/g, " ");
  usePageTitle(`${cat?.label ?? slug} · BLAZE`);
  const result = useQuery({
    queryKey: ["search", query, sort, page, cat?.orientation ?? orient, net],
    queryFn: () =>
      fetchSearch({
        q: query,
        sort,
        page,
        orient: cat?.orientation ?? orient,
        net,
      }),
    enabled: Boolean(cat),
  });

  const prevFilter = useRef({ net, orient });
  useEffect(() => {
    if (prevFilter.current.net !== net || prevFilter.current.orient !== orient) {
      prevFilter.current = { net, orient };
      if (page > 1) void navigate({ search: (s) => ({ ...s, page: undefined }) });
    }
  }, [net, orient, page, navigate]);

  if (!cat) {
    return (
      <Shell>
        <div className="flex flex-col items-center gap-4 py-20 text-center">
          <h1 className="font-display text-3xl tracking-wide">Category not found</h1>
          <p className="max-w-sm text-sm text-muted">That category is not on BLAZE.</p>
          <Link
            to="/categories"
            className="inline-flex h-11 items-center rounded-sm bg-accent px-5 text-sm font-semibold text-accent-fg hover:bg-accent-hover"
          >
            All categories
          </Link>
        </div>
      </Shell>
    );
  }

  return (
    <Shell activeCat={slug}>
      <CategoryChips active={slug} />
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-wide">{cat?.label ?? slug}</h1>
          <p className="mt-1 text-xs text-subtle">
            {cat ? `${cat.label} videos from every live tube` : "Category"}
          </p>
        </div>
        {result.data ? (
          <p className="text-xs tabular-nums text-subtle">
            {result.data.total.toLocaleString()}+ videos
            {result.data.sources.length ? ` · ${result.data.sources.length} tubes` : ""}
          </p>
        ) : null}
      </div>
      <NetworkBar />
      <SortBar
        sort={sort}
        onChange={(next) => void navigate({ search: { sort: next, page: 1 } })}
      />
      {result.isLoading ? (
        <VideoGridSkeleton />
      ) : result.isError ? (
        <LoadError message="Could not load this category." onRetry={() => void result.refetch()} />
      ) : (result.data?.results.length ?? 0) === 0 ? (
        <div className="flex flex-col items-center gap-4 py-16 text-center">
          <p className="text-sm text-muted">No videos in this category right now. Try another.</p>
          <Link
            to="/categories"
            className="inline-flex h-11 items-center rounded-sm bg-accent px-5 text-sm font-semibold text-accent-fg hover:bg-accent-hover"
          >
            All categories
          </Link>
        </div>
      ) : (
        <>
          <VideoGrid videos={result.data?.results ?? []} />
          <Pager
            page={page}
            totalPages={result.data?.totalPages ?? 1}
            onPage={(p) => void navigate({ search: (prev) => ({ ...prev, page: p }) })}
          />
        </>
      )}
    </Shell>
  );
}
