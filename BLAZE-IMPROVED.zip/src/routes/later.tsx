import { createFileRoute, Link } from "@tanstack/react-router";
import { Bookmark } from "lucide-react";
import { Shell, usePageTitle } from "@/components/shell";
import { VideoGrid } from "@/components/video-card";
import { useTube } from "@/store/tube";

export const Route = createFileRoute("/later")({
  component: LaterPage,
});

function LaterPage() {
  const later = useTube((s) => s.later);
  const clearLater = useTube((s) => s.clearLater);
  usePageTitle("Watch later · BLAZE");

  return (
    <Shell>
      <div className="mb-4 flex items-end justify-between gap-3">
        <h1 className="font-display text-3xl tracking-wide">Watch later</h1>
        {later.length > 0 ? (
          <button
            type="button"
            onClick={() => {
              if (window.confirm("Clear all saved videos on this device?")) clearLater();
            }}
            className="inline-flex h-10 items-center rounded-sm border border-border px-3 text-sm font-medium text-muted hover:bg-surface-2 hover:text-fg"
          >
            Clear
          </button>
        ) : null}
      </div>
      {later.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-4 py-20 text-center">
          <Bookmark className="size-10 text-subtle" />
          <p className="max-w-sm text-sm text-muted">
            Nothing saved yet. Tap the bookmark on any video to watch it later on this device.
          </p>
          <Link
            to="/"
            className="inline-flex h-11 items-center rounded-sm bg-accent px-5 text-sm font-semibold text-accent-fg hover:bg-accent-hover"
          >
            Browse videos
          </Link>
        </div>
      ) : (
        <VideoGrid videos={later} />
      )}
    </Shell>
  );
}
