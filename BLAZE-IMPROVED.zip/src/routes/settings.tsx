import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { resetAgeGate } from "@/components/age-gate";
import { Shell, usePageTitle } from "@/components/shell";
import { ALL_SOURCES, SOURCE_META } from "@/lib/blaze/types";
import { cn } from "@/lib/utils";
import { useTube } from "@/store/tube";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const privateSession = useTube((s) => s.privateSession);
  const setPrivateSession = useTube((s) => s.setPrivateSession);
  const autoplay = useTube((s) => s.autoplay);
  const setAutoplay = useTube((s) => s.setAutoplay);
  const hiddenCount = useTube((s) => s.hiddenIds.length);
  const clearHidden = useTube((s) => s.clearHidden);
  const clearHistory = useTube((s) => s.clearHistory);
  const clearLater = useTube((s) => s.clearLater);
  const laterCount = useTube((s) => s.later.length);
  const historyCount = useTube((s) => s.history.length);
  const exportSnapshot = useTube((s) => s.exportSnapshot);
  const importSnapshot = useTube((s) => s.importSnapshot);
  const [importMsg, setImportMsg] = useState<{ ok: boolean; text: string } | null>(null);
  usePageTitle("Settings · BLAZE");

  function downloadExport() {
    const blob = new Blob([exportSnapshot()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "blaze-library.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function onImport(file: File | null) {
    if (!file) return;
    if (file.size > 5_000_000) {
      setImportMsg({ ok: false, text: "That file is too large to be a BLAZE library export." });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        importSnapshot(String(reader.result ?? ""));
        setImportMsg({ ok: true, text: "Library imported on this device." });
      } catch {
        setImportMsg({ ok: false, text: "That file is not a BLAZE library export." });
      }
    };
    reader.readAsText(file);
  }

  return (
    <Shell>
      <h1 className="mb-6 font-display text-3xl tracking-wide">Settings</h1>
      <div className="max-w-xl space-y-4">
        <section className="rounded-sm border border-border bg-surface p-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-sm font-semibold">Private session</h2>
              <p className="mt-1 text-xs leading-relaxed text-muted">
                Stop writing watch history and progress on this device. Saved videos are unchanged.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={privateSession}
              aria-label="Private session"
              onClick={() => setPrivateSession(!privateSession)}
              className={cn(
                "relative h-8 w-14 shrink-0 rounded-full",
                privateSession ? "bg-accent" : "bg-surface-3",
              )}
            >
              <span
                className={cn(
                  "absolute top-1 size-6 rounded-full bg-fg transition-transform",
                  privateSession ? "translate-x-7" : "translate-x-1",
                )}
              />
            </button>
          </div>
        </section>
        <section className="rounded-sm border border-border bg-surface p-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-sm font-semibold">Autoplay</h2>
              <p className="mt-1 text-xs leading-relaxed text-muted">
                Start playback when you open a video. Phones may still require a tap.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={autoplay}
              aria-label="Autoplay videos"
              onClick={() => setAutoplay(!autoplay)}
              className={cn("relative h-8 w-14 shrink-0 rounded-full", autoplay ? "bg-accent" : "bg-surface-3")}
            >
              <span
                className={cn(
                  "absolute top-1 size-6 rounded-full bg-fg transition-transform",
                  autoplay ? "translate-x-7" : "translate-x-1",
                )}
              />
            </button>
          </div>
        </section>
        <section className="rounded-sm border border-border bg-surface p-4">
          <h2 className="text-sm font-semibold">This device</h2>
          <p className="mt-1 text-xs text-muted">
            {hiddenCount} hidden · {historyCount} in history · {laterCount} saved. Nothing is stored on a server.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => {
                if (window.confirm("Clear watch history on this device?")) clearHistory();
              }}
              className="h-11 rounded-sm border border-border px-3 text-sm font-medium hover:bg-surface-2"
            >
              Clear history
            </button>
            <button
              type="button"
              onClick={() => {
                if (window.confirm("Clear all saved videos on this device?")) clearLater();
              }}
              className="h-11 rounded-sm border border-border px-3 text-sm font-medium hover:bg-surface-2"
            >
              Clear watch later
            </button>
            <button
              type="button"
              onClick={() => {
                if (window.confirm("Show videos you hid from reports again?")) clearHidden();
              }}
              className="h-11 rounded-sm border border-border px-3 text-sm font-medium hover:bg-surface-2"
            >
              Restore hidden
            </button>
            <button
              type="button"
              onClick={downloadExport}
              className="h-11 rounded-sm border border-border px-3 text-sm font-medium hover:bg-surface-2"
            >
              Export JSON
            </button>
            <label className="inline-flex h-11 cursor-pointer items-center rounded-sm border border-border px-3 text-sm font-medium hover:bg-surface-2">
              Import JSON
              <input
                type="file"
                accept="application/json"
                aria-label="Import BLAZE library JSON"
                className="hidden"
                onChange={(e) => {
                  onImport(e.target.files?.[0] ?? null);
                  e.currentTarget.value = "";
                }}
              />
            </label>
          </div>
          {importMsg ? (
            <p className={cn("mt-3 text-sm", importMsg.ok ? "text-ok" : "text-danger")} role="status">
              {importMsg.text}
            </p>
          ) : null}
        </section>
        <section className="rounded-sm border border-border bg-surface p-4">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-sm font-semibold">Networks</h2>
            <Link to="/networks" className="inline-flex h-11 items-center text-sm font-medium text-accent hover:text-accent-hover">
              Manage
            </Link>
          </div>
          <p className="mt-1 text-xs text-muted">BLAZE mixes these public catalogs. Filter any one from the network bar.</p>
          <ul className="mt-3 grid grid-cols-2 gap-2 text-sm">
            {ALL_SOURCES.map((s) => (
              <li key={s} className="rounded-xs bg-surface-2 px-2 py-2 text-muted">
                {SOURCE_META[s].label}
              </li>
            ))}
          </ul>
        </section>
        <section className="rounded-sm border border-border bg-surface p-4">
          <h2 className="text-sm font-semibold">Safety</h2>
          <p className="mt-1 text-xs leading-relaxed text-muted">
            BLAZE is 18+ only. Content involving minors, animals, or other illegal material is blocked from search.
            Report a clip on its watch page to hide it on this device. BLAZE does not host, upload, or moderate
            partner catalogs.
          </p>
          <button
            type="button"
            onClick={() => {
              if (window.confirm("Forget the 18+ confirmation on this device? You will have to confirm your age again.")) {
                resetAgeGate();
                window.location.reload();
              }
            }}
            className="mt-3 h-11 rounded-sm border border-border px-3 text-sm font-medium hover:bg-surface-2"
          >
            Reset age confirmation
          </button>
        </section>
      </div>
    </Shell>
  );
}
