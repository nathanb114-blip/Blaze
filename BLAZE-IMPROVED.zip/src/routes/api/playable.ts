import { createFileRoute } from "@tanstack/react-router";
import { handleApi, readQuery } from "@/lib/blaze/http.server.ts";
import { errorResponse, jsonResponse } from "@/lib/blaze/security.server.ts";
import { resolvePlayable } from "@/lib/blaze/playable.server.ts";

export const Route = createFileRoute("/api/playable")({
  server: {
    handlers: {
      GET: async ({ request }) =>
        handleApi(request, ["GET"], "playable", async () => {
          const id = (readQuery(request).get("id") ?? "").trim();
          if (!id) return errorResponse("Missing video id", 400);
          return jsonResponse(await resolvePlayable(id));
        }),
      OPTIONS: async ({ request }) => handleApi(request, ["GET"], null, async () => jsonResponse({})),
    },
  },
});
