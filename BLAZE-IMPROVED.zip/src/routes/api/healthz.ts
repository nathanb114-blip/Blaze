import { createFileRoute } from "@tanstack/react-router";
import { handleApi } from "@/lib/blaze/http.server.ts";
import { jsonResponse } from "@/lib/blaze/security.server.ts";

export const Route = createFileRoute("/api/healthz")({
  server: {
    handlers: {
      GET: async ({ request }) =>
        handleApi(request, ["GET"], null, async () => jsonResponse({ status: "ok" }, 200, "ok")),
      OPTIONS: async ({ request }) => handleApi(request, ["GET"], null, async () => jsonResponse({ status: "ok" })),
    },
  },
});
