import { createFileRoute } from "@tanstack/react-router";
import { handleApi, readQuery } from "@/lib/blaze/http.server.ts";
import { jsonResponse } from "@/lib/blaze/security.server.ts";
import { featuredRails } from "@/lib/blaze/catalog.server.ts";
import type { Orientation, TubeSource } from "@/lib/blaze/types.ts";
import { ALL_SOURCES } from "@/lib/blaze/types.ts";

export const Route = createFileRoute("/api/featured")({
  server: {
    handlers: {
      GET: async ({ request }) =>
        handleApi(request, ["GET"], "search", async () => {
          const orient = (readQuery(request).get("orient") ?? "straight") as Orientation;
          const orientation: Orientation = ["straight", "gay", "trans"].includes(orient)
            ? orient
            : "straight";
          const netRaw = readQuery(request).get("net") ?? "all";
          const net: TubeSource | "all" =
            netRaw === "all" || (ALL_SOURCES as string[]).includes(netRaw) ? (netRaw as TubeSource | "all") : "all";
          return jsonResponse(await featuredRails(orientation, net));
        }),
      OPTIONS: async ({ request }) => handleApi(request, ["GET"], null, async () => jsonResponse([])),
    },
  },
});
