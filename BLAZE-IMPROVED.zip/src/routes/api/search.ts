import { createFileRoute } from "@tanstack/react-router";
import { handleApi, readQuery } from "@/lib/blaze/http.server.ts";
import { errorResponse, jsonResponse } from "@/lib/blaze/security.server.ts";
import { searchCatalog } from "@/lib/blaze/catalog.server.ts";
import type { Orientation, SortMode, TubeSource } from "@/lib/blaze/types.ts";
import { ALL_SOURCES } from "@/lib/blaze/types.ts";

const SORTS = new Set<SortMode>([
  "most-popular",
  "latest",
  "top-rated",
  "longest",
  "top-weekly",
  "top-monthly",
]);

const NETS = new Set<string>(["all", ...ALL_SOURCES]);

export const Route = createFileRoute("/api/search")({
  server: {
    handlers: {
      GET: async ({ request }) =>
        handleApi(request, ["GET"], "search", async () => {
          const params = readQuery(request);
          const q = (params.get("q") ?? "all").trim() || "all";
          const page = Number(params.get("page") ?? "1");
          const sort = (params.get("sort") ?? "most-popular") as SortMode;
          const orientation = (params.get("orient") ?? "straight") as Orientation;
          const net = (params.get("net") ?? "all") as TubeSource | "all";
          if (q.length > 120) return errorResponse("Query too long", 400);
          if (!SORTS.has(sort)) return errorResponse("Invalid sort", 400);
          if (!["straight", "gay", "trans"].includes(orientation)) {
            return errorResponse("Invalid orientation", 400);
          }
          if (!NETS.has(net)) return errorResponse("Invalid network", 400);
          return jsonResponse(
            await searchCatalog({
              query: q,
              page: Number.isFinite(page) ? page : 1,
              sort,
              orientation,
              net,
            }),
          );
        }),
      OPTIONS: async ({ request }) => handleApi(request, ["GET"], null, async () => jsonResponse({})),
    },
  },
});
