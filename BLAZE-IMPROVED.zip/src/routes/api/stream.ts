import { createFileRoute } from "@tanstack/react-router";
import { handleApi } from "@/lib/blaze/http.server.ts";
import { handleStreamProxy } from "@/lib/blaze/proxy.server.ts";
import { jsonResponse } from "@/lib/blaze/security.server.ts";

export const Route = createFileRoute("/api/stream")({
  server: {
    handlers: {
      GET: async ({ request }) => handleApi(request, ["GET"], "stream", () => handleStreamProxy(request)),
      OPTIONS: async ({ request }) => handleApi(request, ["GET"], null, async () => jsonResponse({})),
    },
  },
});
