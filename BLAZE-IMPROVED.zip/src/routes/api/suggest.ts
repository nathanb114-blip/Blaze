import { createFileRoute } from "@tanstack/react-router";
import { handleApi, readQuery } from "@/lib/blaze/http.server.ts";
import { jsonResponse } from "@/lib/blaze/security.server.ts";
import { suggestTitles } from "@/lib/blaze/catalog.server.ts";

export const Route = createFileRoute("/api/suggest")({
  server: {
    handlers: {
      GET: async ({ request }) =>
        handleApi(request, ["GET"], "search", async () => {
          const q = (readQuery(request).get("q") ?? "").trim();
          return jsonResponse({ suggestions: q ? await suggestTitles(q) : [] });
        }),
      OPTIONS: async ({ request }) => handleApi(request, ["GET"], null, async () => jsonResponse({ suggestions: [] })),
    },
  },
});
