import { createFileRoute } from "@tanstack/react-router";
import { handleApi } from "@/lib/blaze/http.server.ts";
import { handleImageProxy } from "@/lib/blaze/proxy.server.ts";
import { jsonResponse } from "@/lib/blaze/security.server.ts";

export const Route = createFileRoute("/api/image")({
  server: {
    handlers: {
      GET: async ({ request }) => handleApi(request, ["GET"], "image", () => handleImageProxy(request)),
      OPTIONS: async ({ request }) => handleApi(request, ["GET"], null, async () => jsonResponse({})),
    },
  },
});
