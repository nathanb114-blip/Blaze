import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Play } from "lucide-react";
import { useEffect, useRef } from "react";
import { CategoryChips, LoadError, NetworkBar, Pager, Shell, SortBar, usePageTitle } from "@/components/shell";
import { VideoGrid, VideoGridSkeleton, VideoRail } from "@/components/video-card";
import { fetchFeatured, fetchSearch } from "@/lib/api";
import { SOURCE_META, type SortMode } from "@/lib/blaze/types";
import { formatDuration, formatViews } from "@/lib/utils";
import { useTube } from "@/store/tube";

const HOME_HEADING: Record<SortMode, string> = {
  "most-popular": "Hottest porn videos",
  latest: "Newest videos",
  "top-rated": "Top rated videos",
  longest: "Longest videos",
  "top-weekly": "This week's hottest",
  "top-monthly": "This month's hottest",
};

const SORTS = new Set<SortMode>([
  "most-popular",
  "latest",
  "top-rated",
  "longest",
  "top-weekly",
  "top-monthly",
]);

type HomeSearch = { sort?: SortMode; page?: number };

export const Route = createFileRoute("/")({
  validateSearch: (s: Record<string, unknown>): HomeSearch => {
    const out: HomeSearch = {};
    if (typeof s.sort === "string" && SORTS.has(s.sort as SortMode)) out.sort = s.sort as SortMode;
    const page = Number(s.page);
    if (Number.isFinite(page) && page > 1) out.page = page;
    return out;
  },
  component: Home,
});

function Home() {
  const { sort = "most-popular", page = 1 } = Route.useSearch();
  const navigate = Route.useNavigate();
  const orient = useTube((s) => s.orientation);
  const net = useTube((s) => s.net);
  const history = useTube((s) => s.history);
  usePageTitle(sort === "most-popular" ? "BLAZE" : `${HOME_HEADING[sort]} · BLAZE`);
  const q = useQuery({
    queryKey: ["search", "all", sort, page, orient, net],
    queryFn: () => fetchSearch({ q: "all", sort, page, orient, net }),
  });
  const featured = useQuery({
    queryKey: ["featured", orient, net],
    queryFn: () => fetchFeatured(orient, net),
    enabled: page === 1 && sort === "most-popular",
  });

  const prevFilter = useRef({ net, orient });
  useEffect(() => {
    if (prevFilter.current.net !== net || prevFilter.current.orient !== orient) {
      prevFilter.current = { net, orient };
      if (page > 1) void navigate({ search: (s) => ({ ...s, page: undefined }) });
    }
  }, [net, orient, page, navigate]);

  const hiddenIds = useTube((s) => s.hiddenIds);
  const isHot = page === 1 && sort === "most-popular";
  const all = (q.data?.results ?? []).filter((v) => !hiddenIds.includes(v.id));
  const hero =
    page === 1
      ? sort === "longest"
        ? all[0]
        : all.find((v) => v.playMode === "native") || all.find((v) => v.source === "pornhub") || all[0]
      : undefined;
  const rest = hero ? all.filter((v) => v.id !== hero.id) : all;
  const continueWatching = isHot ? history.slice(0, 12) : [];
  const becauseSeed =
    isHot
      ? history[0]?.tags.find((t) => t.length > 2 && !/hd|video|porn/i.test(t)) ||
        history[0]?.title.split(/\s+/).find((w) => w.length > 4)
      : undefined;
  const because = useQuery({
    queryKey: ["because", becauseSeed, orient, net],
    queryFn: () => fetchSearch({ q: becauseSeed!, sort: "most-popular", page: 1, orient, net }),
    enabled: Boolean(becauseSeed),
  });

  return (
    <Shell>
      <CategoryChips />
      <div className="mb-3 flex items-end justify-between gap-3">
        <h1 className="font-display text-3xl tracking-wide">{HOME_HEADING[sort]}</h1>
        {q.data ? (
          <p className="text-xs tabular-nums text-subtle">
            {q.data.total.toLocaleString()}+ videos · {q.data.sources.length} live tubes
          </p>
        ) : null}
      </div>
      <NetworkBar />
      <SortBar
        sort={sort}
        onChange={(next) => void navigate({ search: { sort: next, page: 1 } })}
      />
      {q.isLoading ? (
        <VideoGridSkeleton />
      ) : q.isError ? (
        <LoadError message="Could not load videos. Try again in a moment." onRetry={() => void q.refetch()} />
      ) : (
        <>
          {hero ? (
            <Link
              to="/video/$id"
              params={{ id: hero.id }}
              className="group mb-6 grid overflow-hidden rounded-md bg-surface sm:grid-cols-2"
            >
              <div className="relative aspect-video bg-surface-2">
                {hero.thumbnail ? (
                  <img
                    src={hero.thumbnail}
                    alt=""
                    decoding="async"
                    className="h-full w-full object-cover"
                    fetchPriority="high"
                    onError={(e) => {
                      e.currentTarget.style.display = "none";
                    }}
                  />
                ) : null}
                <span className="absolute inset-0 flex items-center justify-center">
                  <span className="flex size-16 items-center justify-center rounded-full bg-accent text-accent-fg">
                    <Play className="size-7 fill-current" />
                  </span>
                </span>
                {hero.duration ? (
                  <span className="absolute right-2 bottom-2 rounded-xs bg-overlay px-1.5 py-0.5 text-xs tabular-nums">
                    {formatDuration(hero.duration)}
                  </span>
                ) : null}
              </div>
              <div className="flex flex-col justify-center p-5">
                <p className="text-xs font-semibold tracking-wide text-accent uppercase">
                  {sort === "longest" ? "Longest" : "Featured"}
                </p>
                <h2 className="mt-2 font-sans text-xl font-semibold text-balance hyphens-none group-hover:text-accent">
                  {hero.title}
                </h2>
                <p className="mt-2 text-sm text-muted tabular-nums">
                  {[
                    hero.duration ? formatDuration(hero.duration) : "",
                    formatViews(hero.views) && `${formatViews(hero.views)} views`,
                    SOURCE_META[hero.source]?.label ?? hero.source,
                  ]
                    .filter(Boolean)
                    .join(" · ")}
                </p>
              </div>
            </Link>
          ) : null}
          {continueWatching.length > 0 ? (
            <VideoRail title="Continue watching" videos={continueWatching} seeAll={{ to: "/history" }} />
          ) : null}
          {because.data?.results.length ? (
            <VideoRail
              title={`Because you watched ${history[0]?.title.split(" ").slice(0, 4).join(" ") ?? ""}`}
              videos={because.data.results.filter((v) => v.id !== history[0]?.id)}
              seeAll={{ to: "/search", q: becauseSeed ?? "" }}
            />
          ) : null}
          {isHot && featured.data
            ? featured.data
                .filter((rail) => rail.id !== "hot")
                .map((rail) => (
                  <VideoRail
                    key={rail.id}
                    title={rail.title}
                    videos={rail.videos}
                    seeAll={
                      rail.query === "all"
                        ? { to: "/", sort: rail.id === "new" ? "latest" : "most-popular" }
                        : { to: "/search", q: rail.query }
                    }
                  />
                ))
            : null}
          <VideoGrid videos={rest} />
          <Pager
            page={page}
            totalPages={q.data?.totalPages ?? 1}
            onPage={(p) => void navigate({ search: (prev) => ({ ...prev, page: p }) })}
          />
        </>
      )}
    </Shell>
  );
}
