import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bookmark, BookmarkCheck, ChevronLeft, Eye, Flag, SkipForward } from "lucide-react";
import { useEffect, useState } from "react";
import { Player } from "@/components/player";
import { goBackOrHome, LoadError, Shell, usePageTitle } from "@/components/shell";
import { VideoCard, VideoGrid, VideoGridSkeleton } from "@/components/video-card";
import { fetchPlayable, fetchSearch } from "@/lib/api";
import { SOURCE_META } from "@/lib/blaze/types";
import { formatDuration, formatViews } from "@/lib/utils";
import { useTube, REPORT_REASONS, type ReportReason } from "@/store/tube";

function relatedSeed(title: string, tags: string[]): string {
  const skip = /^(hd|4k|video|porn|xxx|sex|hot|new|full|official|uncensored|all|60fps|1080p|720p|480p)$/i;
  const quality = /\b(hd|4k|1080p|720p|480p|60fps|porn|xxx)\b/i;
  const tag = tags.find((t) => {
    if (t.length < 3 || t.length > 22) return false;
    if (skip.test(t)) return false;
    if (quality.test(t) && t.trim().split(/\s+/).length <= 2) return false;
    return true;
  });
  if (tag) return tag;
  const words = title
    .split(/[^a-zA-Z0-9]+/)
    .filter((w) => w.length > 3 && !skip.test(w));
  return words.slice(0, 2).join(" ") || "hot";
}

export const Route = createFileRoute("/video/$id")({
  component: WatchPage,
});

function WatchPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const goBack = () => goBackOrHome(navigate);
  const orient = useTube((s) => s.orientation);
  const net = useTube((s) => s.net);
  const pushHistory = useTube((s) => s.pushHistory);
  const toggleLater = useTube((s) => s.toggleLater);
  const later = useTube((s) => s.later.some((v) => v.id === id));
  const reportVideo = useTube((s) => s.reportVideo);
  const [reportOpen, setReportOpen] = useState(false);

  const playable = useQuery({
    queryKey: ["playable", id],
    queryFn: () => fetchPlayable(id),
  });

  usePageTitle(playable.data?.title ? `${playable.data.title} · BLAZE` : "Watch · BLAZE");

  const relatedQ = playable.data ? relatedSeed(playable.data.title, playable.data.tags) : "hot";
  const related = useQuery({
    queryKey: ["related", relatedQ, orient, net],
    queryFn: () => fetchSearch({ q: relatedQ, sort: "most-popular", page: 1, orient, net }),
    enabled: Boolean(playable.data),
  });

  useEffect(() => {
    if (!playable.data) return;
    pushHistory({
      id: playable.data.id,
      title: playable.data.title,
      pageUrl: playable.data.pageUrl,
      thumbnail: playable.data.thumbnail,
      duration: playable.data.duration,
      views: playable.data.views,
      rating: null,
      added: null,
      tags: playable.data.tags,
      hd: true,
      source: playable.data.source,
      playMode: playable.data.playMode,
    });
  }, [playable.data, pushHistory]);

  const sourceLabel = playable.data ? SOURCE_META[playable.data.source]?.label : null;
  const relatedVideos = (related.data?.results ?? []).filter((v) => v.id !== id);
  const side = relatedVideos.slice(0, 8);
  const more = relatedVideos.slice(8, 26);

  return (
    <Shell>
      {playable.isLoading ? (
        <div>
          <button
            type="button"
            onClick={goBack}
            className="mb-3 inline-flex h-11 items-center gap-1 text-sm font-medium text-muted hover:text-fg"
          >
            <ChevronLeft className="size-5" />
            Back
          </button>
          <div className="aspect-video animate-pulse rounded-sm bg-surface-2" />
        </div>
      ) : playable.isError ? (
        <>
          <LoadError
            message={(playable.error as Error).message || "This video could not be loaded."}
            onRetry={() => void playable.refetch()}
          />
          <div className="mt-4 flex justify-center">
            <button
              type="button"
              onClick={goBack}
              className="inline-flex h-11 items-center gap-1 text-sm font-medium text-muted hover:text-fg"
            >
              <ChevronLeft className="size-4" />
              Back to videos
            </button>
          </div>
        </>
      ) : playable.data ? (
        <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_320px] lg:items-start lg:gap-6">
          <div>
            <Player key={id} video={playable.data} onBack={goBack} />
            <div className="mt-4 flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <h1 className="font-sans text-lg leading-snug font-semibold text-balance hyphens-none">
                  {playable.data.title}
                </h1>
                <p className="mt-1 flex flex-wrap items-center gap-3 text-xs text-subtle tabular-nums">
                  {playable.data.views != null ? (
                    <span className="inline-flex items-center gap-1">
                      <Eye className="size-3.5" />
                      {formatViews(playable.data.views)} views
                    </span>
                  ) : null}
                  {playable.data.duration ? <span>{formatDuration(playable.data.duration)}</span> : null}
                  {sourceLabel ? <span>{sourceLabel}</span> : null}
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  toggleLater({
                    id: playable.data!.id,
                    title: playable.data!.title,
                    pageUrl: playable.data!.pageUrl,
                    thumbnail: playable.data!.thumbnail,
                    duration: playable.data!.duration,
                    views: playable.data!.views,
                    rating: null,
                    added: null,
                    tags: playable.data!.tags,
                    hd: true,
                    source: playable.data!.source,
                    playMode: playable.data!.playMode,
                  })
                }
                className="inline-flex h-11 items-center gap-2 rounded-sm border border-border bg-surface-2 px-3 text-sm font-medium hover:bg-surface-3"
              >
                {later ? <BookmarkCheck className="size-4 text-accent" /> : <Bookmark className="size-4" />}
                {later ? "Saved" : "Watch later"}
              </button>
              <button
                type="button"
                onClick={() => setReportOpen((v) => !v)}
                className="inline-flex h-11 items-center gap-2 rounded-sm border border-border bg-surface-2 px-3 text-sm font-medium text-muted hover:bg-surface-3 hover:text-fg"
              >
                <Flag className="size-4" />
                Report
              </button>
              {side[0] ? (
                <Link
                  to="/video/$id"
                  params={{ id: side[0].id }}
                  className="inline-flex h-11 items-center gap-2 rounded-sm bg-accent px-3 text-sm font-semibold text-accent-fg hover:bg-accent-hover"
                >
                  <SkipForward className="size-4" />
                  Next
                </Link>
              ) : null}
            </div>
            {playable.data.tags.length > 0 ? (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {playable.data.tags.map((tag) => (
                  <Link
                    key={tag}
                    to="/search"
                    search={{ q: tag, page: 1, sort: "most-popular" }}
                    className="inline-flex h-11 items-center rounded-full bg-surface-2 px-3 text-xs font-medium text-muted hover:text-fg"
                  >
                    {tag}
                  </Link>
                ))}
              </div>
            ) : null}
            {reportOpen ? (
              <div className="mt-4 rounded-sm border border-border bg-surface p-4" role="region" aria-label="Report this video">
                <p className="text-sm font-semibold">Report this video</p>
                <p className="mt-1 text-xs leading-relaxed text-muted">
                  Reports stay on this device and hide the clip here. BLAZE does not host uploads. For illegal
                  material also contact the source network and local authorities.
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {REPORT_REASONS.map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => {
                        reportVideo(id, r.id as ReportReason);
                        setReportOpen(false);
                        goBack();
                      }}
                      className="inline-flex h-11 items-center rounded-sm border border-border bg-surface-2 px-3 text-sm font-medium hover:bg-surface-3"
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
          </div>
          <aside className="mt-8 hidden lg:mt-0 lg:block">
            <h2 className="mb-3 font-display text-xl tracking-wide">Up next</h2>
            {related.isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="aspect-video animate-pulse rounded-sm bg-surface-2" />
                ))}
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {side.map((v) => (
                  <VideoCard key={v.id} video={v} />
                ))}
              </div>
            )}
          </aside>
        </div>
      ) : null}

      {relatedVideos.length > 0 ? (
        <>
          <div className="mt-10 lg:hidden">
            <h2 className="mb-4 font-display text-2xl tracking-wide">Related videos</h2>
            {related.isLoading ? <VideoGridSkeleton count={12} /> : <VideoGrid videos={relatedVideos} />}
          </div>
          {more.length > 0 ? (
            <div className="mt-10 hidden lg:block">
              <h2 className="mb-4 font-display text-2xl tracking-wide">Related videos</h2>
              <VideoGrid videos={more} />
            </div>
          ) : null}
        </>
      ) : related.isLoading && playable.data ? (
        <>
          <h2 className="mt-10 mb-4 font-display text-2xl tracking-wide">Related videos</h2>
          <VideoGridSkeleton count={12} />
        </>
      ) : null}
    </Shell>
  );
}
