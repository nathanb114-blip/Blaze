import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Shell, usePageTitle } from "@/components/shell";
import { ALL_SOURCES, SOURCE_META } from "@/lib/blaze/types";
import { cn } from "@/lib/utils";
import { useTube } from "@/store/tube";

const BLURBS: Record<string, string> = {
  pornhub: "The largest mainstream tube. Official partner catalog.",
  xvideos: "Massive global library. Short and full-length uploads.",
  xnxx: "Sister catalog to XVideos with a different mix of uploads.",
  youporn: "Aylo network tube — studio and amateur clips.",
  xhamster: "Community-heavy tube spanning mainstream and niche.",
  eporner: "Full-length HD library with native in-app playback.",
  redtube: "Classic Aylo tube, official search API.",
  redgifs: "Short looping clips with native HD/SD streams.",
  tnaflix: "Long-running independent tube with studio and amateur mixes.",
  drtuber: "Fast-moving clip library, strong amateur and MILF catalogs.",
  nuvid: "Companion catalog to DrTuber with a different ranking mix.",
  xozilla: "Full-length KVS tube covering mainstream and fetish.",
  pornhat: "HD-leaning tube with a deep niche and amateur bench.",
  youjizz: "Huge independent catalog — amateur, studio, and long-form.",
  hqporner: "Full-length 1080p+ scenes from a dedicated HD tube.",
  sunporno: "Classic full-length tube with a deep archive.",
};

export const Route = createFileRoute("/networks")({
  component: NetworksPage,
});

function NetworksPage() {
  const net = useTube((s) => s.net);
  const setNet = useTube((s) => s.setNet);
  const navigate = useNavigate();
  usePageTitle("Networks · BLAZE");

  function pick(next: typeof net) {
    setNet(next);
    void navigate({ to: "/" });
  }

  return (
    <Shell>
      <h1 className="mb-2 font-display text-3xl tracking-wide">Networks</h1>
      <p className="mb-6 max-w-2xl text-sm text-muted">
        BLAZE searches every catalog below at once, then interleaves the results. Tap a network to browse it
        solo from Home. Mainstream, indie, HD, GIF, and niche tubes all feed the same grid.
      </p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <button
          type="button"
          onClick={() => pick("all")}
          className={cn(
            "rounded-sm border p-4 text-left",
            net === "all" ? "border-accent bg-surface" : "border-border bg-surface-2 hover:bg-surface-3",
          )}
        >
          <p className="font-display text-xl tracking-wide">All networks</p>
          <p className="mt-1 text-xs text-muted">Mix every catalog into one grid.</p>
        </button>
        {ALL_SOURCES.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => pick(s)}
            className={cn(
              "rounded-sm border p-4 text-left",
              net === s ? "border-accent bg-surface" : "border-border bg-surface-2 hover:bg-surface-3",
            )}
          >
            <p className="text-xs font-semibold tracking-wide text-accent">{SOURCE_META[s].short}</p>
            <p className="mt-1 font-display text-xl tracking-wide">{SOURCE_META[s].label}</p>
            <p className="mt-1 text-xs text-muted">{BLURBS[s]}</p>
          </button>
        ))}
      </div>
    </Shell>
  );
}
