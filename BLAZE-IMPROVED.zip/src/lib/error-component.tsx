import type { ErrorComponentProps } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { TriangleAlert } from "lucide-react";

export function AppErrorComponent({ error }: ErrorComponentProps) {
  return (
    <main className="flex min-h-svh flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg">
      <span className="text-danger" aria-hidden="true">
        <TriangleAlert className="size-10" strokeWidth={2} />
      </span>
      <h1 className="text-lg font-semibold">Something went wrong</h1>
      <p className="max-w-md text-sm break-words text-muted">
        {error.message || "An unexpected error occurred. Try reloading the page."}
      </p>
      <div className="mt-2 flex flex-wrap items-center justify-center gap-2">
        <Link
          to="/"
          className="inline-flex h-11 items-center rounded-sm bg-accent px-5 text-sm font-semibold text-accent-fg hover:bg-accent-hover"
        >
          Back to BLAZE
        </Link>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="inline-flex h-11 items-center rounded-sm border border-border bg-surface-2 px-5 text-sm font-medium text-fg hover:bg-surface-3"
        >
          Reload
        </button>
      </div>
    </main>
  );
}
