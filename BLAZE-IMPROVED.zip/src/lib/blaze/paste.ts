import { SOURCE_PREFIX, type TubeSource } from "./types.ts";

const PATTERNS: Array<{ re: RegExp; source: TubeSource }> = [
  { re: /pornhub\.com\/(?:view_video\.php\?viewkey=|embed\/)([A-Za-z0-9]+)/i, source: "pornhub" },
  { re: /xvideos\.com\/video\.([A-Za-z0-9]+)/i, source: "xvideos" },
  { re: /xvideos\.com\/video(\d+)/i, source: "xvideos" },
  { re: /xnxx\.com\/video-([A-Za-z0-9]+)/i, source: "xnxx" },
  { re: /eporner\.com\/(?:hd-porn\/|video-)([A-Za-z0-9]+)/i, source: "eporner" },
  { re: /redtube\.com\/(?:embed\/)?(\d+)/i, source: "redtube" },
  { re: /embed\.redtube\.com\/\?id=(\d+)/i, source: "redtube" },
  { re: /redgifs\.com\/watch\/([A-Za-z0-9]+)/i, source: "redgifs" },
  { re: /youporn\.com\/(?:watch|embed)\/(\d+)/i, source: "youporn" },
  { re: /xhamster\.com\/(?:videos\/(?:[a-z0-9-]+-)?|embed\/)(\d+)/i, source: "xhamster" },
  { re: /tnaflix\.com\/[^?\s]*video(\d+)/i, source: "tnaflix" },
  { re: /player\.tnaflix\.com\/video\/(\d+)/i, source: "tnaflix" },
  { re: /drtuber\.com\/(?:video|embed)\/(\d+)/i, source: "drtuber" },
  { re: /nuvid\.com\/(?:video|embed)\/(\d+)/i, source: "nuvid" },
  { re: /xozilla\.com\/(?:videos|embed)\/(\d+)/i, source: "xozilla" },
  { re: /pornhat\.com\/(?:video|embed)\/([a-z0-9-]+)/i, source: "pornhat" },
  { re: /youjizz\.com\/videos\/embed\/(\d+)/i, source: "youjizz" },
  { re: /youjizz\.com\/videos\/[^/\s]*?(\d+)\.html/i, source: "youjizz" },
  { re: /hqporner\.com\/hdporn\/(\d+-[A-Za-z0-9_-]+)/i, source: "hqporner" },
  { re: /sunporno\.com\/(?:v|videos|embed)\/(\d+)/i, source: "sunporno" },
];

export function parsePastedUrl(raw: string): string | null {
  const text = raw.trim();
  if (!/^https?:\/\//i.test(text)) return null;
  for (const p of PATTERNS) {
    const m = text.match(p.re);
    const id = m?.[1]?.replace(/\/$/, "");
    if (id) return `${SOURCE_PREFIX[p.source]}-${id}`;
  }
  return null;
}
