import type { PlayableQuality } from "./types.ts";
import { absUrl, decodeEntities } from "./html.ts";
import { isHlsManifest } from "./hls.ts";
import { signProxyUrl } from "./proxy-sign.server.ts";
import { safeFetchText } from "./fetch-safe.server.ts";

interface MediaDef {
  format?: string;
  quality?: string | number | number[];
  height?: number;
  videoUrl?: string;
  remote?: boolean;
}

export async function fetchVideoPage(
  url: string,
  timeout = 10000,
): Promise<{ html: string; url: string }> {
  const origin = new URL(url).origin + "/";
  const res = await safeFetchText(url, {
    timeout,
    maxBytes: 2_400_000,
    headers: {
      Accept: "text/html,application/xhtml+xml",
      Referer: origin,
    },
  });
  if (res.status >= 400) {
    throw Object.assign(new Error("Media unavailable"), { status: 404 });
  }
  return { html: res.text, url: res.url || url };
}

function sliceJson(source: string, start: number): unknown {
  const open = source[start];
  if (open !== "{" && open !== "[") return null;
  let depth = 0;
  let inStr = false;
  let esc = false;
  const limit = Math.min(source.length, start + 700_000);
  for (let i = start; i < limit; i++) {
    const c = source[i]!;
    if (inStr) {
      if (esc) {
        esc = false;
        continue;
      }
      if (c === "\\") {
        esc = true;
        continue;
      }
      if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') {
      inStr = true;
      continue;
    }
    if (c === "{" || c === "[") depth += 1;
    else if (c === "}" || c === "]") {
      depth -= 1;
      if (depth === 0) {
        try {
          return JSON.parse(source.slice(start, i + 1)) as unknown;
        } catch {
          return null;
        }
      }
    }
  }
  return null;
}

export function extractMediaDefinitions(html: string): MediaDef[] {
  const markers = ['"mediaDefinitions"', "mediaDefinitions"];
  for (const marker of markers) {
    let from = 0;
    while (from < html.length) {
      const idx = html.indexOf(marker, from);
      if (idx < 0) break;
      const colon = html.indexOf(":", idx + marker.length);
      if (colon < 0) break;
      let pos = colon + 1;
      while (pos < html.length && /\s/.test(html[pos] ?? "")) pos += 1;
      const parsed = sliceJson(html, pos);
      if (Array.isArray(parsed)) return parsed as MediaDef[];
      from = idx + marker.length;
    }
  }
  return [];
}

function standardHeight(n: number): boolean {
  return n === 144 || n === 240 || n === 250 || n === 360 || n === 480 || n === 720 || n === 1080 || n === 1440 || n === 2160;
}

function heightOf(def: MediaDef, url = ""): number {
  const q = def.quality;
  if (typeof q === "number" && q >= 144) return q;
  if (typeof q === "string") {
    const n = Number.parseInt(q, 10);
    if (Number.isFinite(n) && n >= 144) return n;
  }
  if (Array.isArray(q)) {
    const nums = q.map(Number).filter((n) => Number.isFinite(n) && n >= 144);
    if (nums.length) return Math.max(...nums);
  }
  const fromUrl = url.match(/(\d{3,4})p/i);
  if (fromUrl) return Number(fromUrl[1]);
  if (typeof def.height === "number" && def.height >= 144) {
    return standardHeight(def.height) ? def.height : def.height;
  }
  return 0;
}

function isHlsUrl(url: string, format?: string): boolean {
  return format === "hls" || /\.m3u8(\?|$)/i.test(url);
}

function isRemoteDef(def: MediaDef, url: string): boolean {
  if (/\.m3u8(\?|$)/i.test(url) || /\.mp4(\?|$)/i.test(url)) return false;
  if (def.remote === true) return true;
  return /\/(get_media|media\/(?:hls|mp4))/i.test(url);
}

async function fetchJson(url: string, referer: string): Promise<unknown> {
  const res = await safeFetchText(url, {
    timeout: 8000,
    maxBytes: 400_000,
    headers: {
      Accept: "application/json, */*",
      Referer: referer,
      Origin: new URL(referer).origin,
    },
  });
  if (res.status >= 400) return null;
  try {
    return JSON.parse(res.text) as unknown;
  } catch {
    return null;
  }
}

function pushQuality(
  bucket: Map<number, { url: string; hls: boolean }>,
  url: string,
  height: number,
  hls: boolean,
) {
  if (!url || height < 144) return;
  const existing = bucket.get(height);
  if (!existing) {
    bucket.set(height, { url, hls });
    return;
  }
  if (existing.hls && !hls) bucket.set(height, { url, hls });
}

function toSigned(bucket: Map<number, { url: string; hls: boolean }>, pageUrl: string): PlayableQuality[] {
  return [...bucket.entries()]
    .sort((a, b) => b[0] - a[0])
    .map(([height, item]) => ({
      label: `${height}p`,
      height,
      url: signProxyUrl("stream", item.url, pageUrl),
    }));
}

export async function qualitiesFromMediaDefinitions(
  html: string,
  pageUrl: string,
): Promise<PlayableQuality[]> {
  const defs = extractMediaDefinitions(html);
  if (!defs.length) return [];
  const bucket = new Map<number, { url: string; hls: boolean }>();
  const remotes: { url: string; format?: string }[] = [];

  for (const def of defs) {
    const abs = absUrl(String(def.videoUrl ?? ""), pageUrl);
    if (!abs) continue;
    if (isRemoteDef(def, abs)) {
      remotes.push({ url: abs, format: def.format });
      continue;
    }
    pushQuality(bucket, abs, heightOf(def, abs), isHlsUrl(abs, def.format));
  }

  const remotePayloads = await Promise.all(
    remotes.map(async (remote) => {
      const json = await fetchJson(remote.url, pageUrl);
      return Array.isArray(json) ? (json as MediaDef[]) : [];
    }),
  );
  for (const list of remotePayloads) {
    for (const def of list) {
      const abs = absUrl(String(def.videoUrl ?? ""), pageUrl);
      if (!abs) continue;
      if (isRemoteDef(def, abs)) continue;
      pushQuality(bucket, abs, heightOf(def, abs), isHlsUrl(abs, def.format));
    }
  }
  return toSigned(bucket, pageUrl);
}

export async function expandHlsMaster(masterUrl: string, pageUrl: string): Promise<PlayableQuality[]> {
  const res = await safeFetchText(masterUrl, {
    timeout: 6000,
    maxBytes: 80_000,
    headers: {
      Accept: "application/vnd.apple.mpegurl,application/x-mpegURL,*/*",
      Referer: pageUrl,
    },
  });
  if (res.status >= 400 || !isHlsManifest(res.text)) {
    return [
      {
        label: "Auto",
        height: 720,
        url: signProxyUrl("stream", masterUrl, pageUrl),
      },
    ];
  }
  const base = res.url || masterUrl;
  const lines = res.text.split(/\r?\n/);
  const bucket = new Map<number, { url: string; hls: boolean }>();
  for (let i = 0; i < lines.length; i++) {
    const inf = lines[i] ?? "";
    if (!inf.includes("EXT-X-STREAM-INF")) continue;
    const next = (lines[i + 1] ?? "").trim();
    if (!next || next.startsWith("#")) continue;
    const abs = absUrl(next, base);
    if (!abs) continue;
    const height =
      Number(inf.match(/RESOLUTION=\d+x(\d+)/i)?.[1] ?? 0) ||
      Number(inf.match(/NAME="(\d+)/)?.[1] ?? 0);
    pushQuality(bucket, abs, height || 720, true);
  }
  const signed = toSigned(bucket, pageUrl);
  if (signed.length) return signed;
  return [
    {
      label: "Auto",
      height: 720,
      url: signProxyUrl("stream", masterUrl, pageUrl),
    },
  ];
}

function setter(html: string, name: string): string | null {
  const re = new RegExp(`html5player\\.set${name}\\(['"]([^'"]+)['"]\\)`, "i");
  const m = html.match(re);
  return m?.[1] ? decodeEntities(m[1]) : null;
}

export async function qualitiesFromXvideos(html: string, pageUrl: string): Promise<PlayableQuality[]> {
  const hls = setter(html, "VideoHLS");
  const high = setter(html, "VideoUrlHigh");
  const low = setter(html, "VideoUrlLow");
  if (hls && /^https?:\/\//i.test(hls)) {
    const expanded = await expandHlsMaster(hls, pageUrl);
    if (expanded.length) return expanded;
  }
  const bucket = new Map<number, { url: string; hls: boolean }>();
  if (high) pushQuality(bucket, high, heightOf({}, high) || 360, false);
  if (low) pushQuality(bucket, low, heightOf({}, low) || 240, false);
  return toSigned(bucket, pageUrl);
}

export function collectMp4Qualities(html: string, pageUrl: string): PlayableQuality[] {
  const bucket = new Map<number, { url: string; hls: boolean }>();
  const re = /https?:\/\/[^"'\\\s<>]+?(\d{3,4})p[^"'\\\s<>]*\.mp4(?:\?[^"'\\\s<>]*)?/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const url = decodeEntities(m[0]);
    const height = Number(m[1]);
    const abs = absUrl(url, pageUrl);
    if (!abs) continue;
    pushQuality(bucket, abs, height, false);
  }
  const quoted = /(?:file|src|source|url)\s*[:=]\s*['"](https?:\/\/[^'"]+\.mp4[^'"]*)['"]/gi;
  while ((m = quoted.exec(html))) {
    const abs = absUrl(decodeEntities(m[1] ?? ""), pageUrl);
    if (!abs) continue;
    pushQuality(bucket, abs, heightOf({}, abs) || 720, false);
  }
  return toSigned(bucket, pageUrl);
}
