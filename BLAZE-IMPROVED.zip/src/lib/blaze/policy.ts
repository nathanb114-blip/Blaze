const PROHIBITED_PATTERNS: RegExp[] = [
  /\bcsam\b/i,
  /\bchild\s*(?:porn|sex|abuse|exploit)/i,
  /\bchildren\b/i,
  /\bchild\b/i,
  /\bkiddie\b/i,
  /\bkids?\b/i,
  /\bloli(?:con|ta)?\b/i,
  /\bshota(?:con)?\b/i,
  /\bpre[-\s]?teen/i,
  /\bunderage\b/i,
  /\bunder\s*18\b/i,
  /\bminor(?:s)?\b/i,
  /\bped[oa](?:phile|philia)?\b/i,
  /\bbestial(?:ity)?\b/i,
  /\bzoophil(?:ia|e|ic)?\b/i,
  /\banimal[-\s]?sex\b/i,
  /\bzoo[-\s]?sex\b/i,
  /\b(?:1[0-7]|[9])\s*(?:year|yr|y\/o|yo)\b/i,
  /\b(?:1[0-7]|[9])[-\s]?year[-\s]?old\b/i,
];

export function findProhibitedTerm(text: string): string | null {
  const value = text.normalize("NFKC");
  for (const re of PROHIBITED_PATTERNS) {
    const m = value.match(re);
    if (m) return m[0];
  }
  return null;
}

export function isProhibitedText(...parts: Array<string | null | undefined>): boolean {
  return parts.some((p) => (p ? findProhibitedTerm(p) !== null : false));
}

export function prohibitedErrorMessage(): string {
  return "That search is blocked.";
}
