export type MediaKind = "mp4" | "webm" | "hls" | "image" | "html" | "json" | "unknown";

function startsWith(bytes: Uint8Array, ascii: string, offset = 0): boolean {
  if (bytes.length < offset + ascii.length) return false;
  for (let i = 0; i < ascii.length; i++) {
    if (bytes[offset + i] !== ascii.charCodeAt(i)) return false;
  }
  return true;
}

function headerText(bytes: Uint8Array, n = 64): string {
  const slice = bytes.subarray(0, Math.min(n, bytes.length));
  return new TextDecoder("utf-8", { fatal: false }).decode(slice).trimStart();
}

export function classifyBytes(bytes: Uint8Array): MediaKind {
  if (bytes.length === 0) return "unknown";
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image";
  if (startsWith(bytes, "\x89PNG")) return "image";
  if (startsWith(bytes, "GIF87a") || startsWith(bytes, "GIF89a")) return "image";
  if (startsWith(bytes, "RIFF") && startsWith(bytes, "WEBP", 8)) return "image";
  if (bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3) {
    return "webm";
  }
  if (bytes.length >= 12 && startsWith(bytes, "ftyp", 4)) return "mp4";
  const text = headerText(bytes, 96);
  if (text.startsWith("#EXTM3U")) return "hls";
  const lower = text.toLowerCase();
  if (lower.startsWith("<!doctype") || lower.startsWith("<html") || lower.startsWith("<head")) {
    return "html";
  }
  if (lower.startsWith("{") || lower.startsWith("[")) return "json";
  return "unknown";
}

export function isBrowserMedia(kind: MediaKind): boolean {
  return kind === "mp4" || kind === "webm" || kind === "hls";
}

export function isImageKind(kind: MediaKind): boolean {
  return kind === "image";
}

export function kindFromContentType(ct: string | null | undefined): MediaKind | null {
  if (!ct) return null;
  const t = ct.split(";")[0]?.trim().toLowerCase() ?? "";
  if (t === "video/mp4" || t === "application/mp4" || t === "application/octet-stream") return "mp4";
  if (t === "video/webm") return "webm";
  if (t.includes("mpegurl") || t === "application/x-mpegurl" || t === "audio/mpegurl") return "hls";
  if (t.startsWith("image/")) return "image";
  if (t.startsWith("text/html")) return "html";
  if (t.includes("json")) return "json";
  return null;
}
