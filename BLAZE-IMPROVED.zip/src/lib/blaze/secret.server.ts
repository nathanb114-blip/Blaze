export const BLAZE_SIGNING_SECRET =
  process.env.BLAZE_SIGNING_SECRET ?? "blaze-hmac-v1-server-only-do-not-export";
