import type { Orientation, SearchResponse, SortMode, TubeSource, VideoCard } from "./types.ts";
import { ALL_SOURCES, FAST_SOURCES } from "./types.ts";

import { isProhibitedText, prohibitedErrorMessage } from "./policy.ts";
import {
  MIXED_PER_SOURCE,
  SOLO_PAGE_SIZE,
  cachedJson,
  card,
  encodeId,
  fitsOrientation,
  getJson,
  orientQuery,
  parseClock,
  parseRating,
  parseVideoId,
  parseViews,
  tagsFrom,
  thumb,
} from "./cards.server.ts";
import { LISTING_SEARCH, type PartnerPage } from "./listings.server.ts";
import { filterByQuery, pageMatchesQuery, stampQuery } from "./relevance.ts";

function phOrder(sort: SortMode): { ordering: string; period?: string } {
  if (sort === "latest") return { ordering: "newest" };
  if (sort === "top-rated") return { ordering: "rating" };
  if (sort === "top-weekly") return { ordering: "mostviewed", period: "weekly" };
  if (sort === "top-monthly") return { ordering: "mostviewed", period: "monthly" };
  return { ordering: "mostviewed" };
}

function epOrder(sort: SortMode): string {
  return sort === "longest" ? "longest" : sort;
}

function rgOrder(sort: SortMode): string {
  if (sort === "latest") return "latest";
  if (sort === "top-rated" || sort === "top-weekly" || sort === "top-monthly") return "top";
  return "trending";
}

function rtOrder(sort: SortMode): string {
  if (sort === "latest") return "newest";
  if (sort === "top-rated") return "rating";
  return "mostviewed";
}

async function searchEporner(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const url = new URL("https://www.eporner.com/api/v2/video/search/");
  url.searchParams.set("query", q === "all" ? "all" : q);
  url.searchParams.set("per_page", String(perPage));
  url.searchParams.set("page", String(page));
  url.searchParams.set("thumbsize", "big");
  url.searchParams.set("order", epOrder(sort));
  url.searchParams.set("gay", orientation === "gay" ? "2" : "0");
  url.searchParams.set("lq", "0");
  url.searchParams.set("format", "json");

  const data = (await cachedJson(url.toString(), () => getJson(url.toString()))) as {
    total_count?: number;
    total_pages?: number;
    videos?: Array<{
      id?: string;
      title?: string;
      keywords?: string;
      views?: number;
      rate?: string;
      url?: string;
      added?: string;
      length_sec?: number;
      default_thumb?: { src?: string };
    }>;
  };

  const results: VideoCard[] = [];
  for (const raw of data.videos ?? []) {
    const mapped = card({
      id: encodeId("eporner", (raw.id ?? "").trim()),
      title: (raw.title ?? "").trim(),
      pageUrl: (raw.url ?? "").trim(),
      thumbnail: thumb(raw.default_thumb?.src, "https://www.eporner.com/"),
      duration: typeof raw.length_sec === "number" ? raw.length_sec : null,
      views: typeof raw.views === "number" ? raw.views : null,
      rating: parseRating(raw.rate),
      added: raw.added ?? null,
      tags: tagsFrom(raw.keywords),
      source: "eporner",
      playMode: "native",
    });
    if (mapped) results.push(mapped);
  }
  return {
    source: "eporner",
    results,
    total: data.total_count ?? results.length,
    totalPages: data.total_pages ?? 1,
  };
}

async function searchPornhub(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const { ordering, period } = phOrder(sort);
  const url = new URL("https://www.pornhub.com/webmasters/search");
  if (q === "all") {
    url.searchParams.set("search", "");
  } else {
    url.searchParams.set("search", q);
  }
  url.searchParams.set("thumbsize", "large");
  url.searchParams.set("page", String(page));
  url.searchParams.set("ordering", ordering);
  if (period) url.searchParams.set("period", period);

  const data = (await cachedJson(url.toString(), () => getJson(url.toString()))) as {
    videos?: Array<{
      video_id?: string;
      title?: string;
      url?: string;
      duration?: string;
      views?: number | string;
      rating?: number | string;
      default_thumb?: string;
      thumb?: string;
      tags?: unknown;
      publish_date?: string;
      segment?: string;
    }>;
  };

  const results: VideoCard[] = [];
  for (const raw of data.videos ?? []) {
    const segment = (raw.segment ?? "").toLowerCase();
    if (orientation === "straight" && (segment === "gay" || segment === "shemale" || segment === "trans")) {
      continue;
    }
    if (orientation === "gay" && segment && segment !== "gay") continue;
    if (orientation === "trans" && segment && segment !== "shemale" && segment !== "trans") {
      if (!/trans|shemale/i.test(raw.title ?? "")) continue;
    }
    const mapped = card({
      id: encodeId("pornhub", (raw.video_id ?? "").trim()),
      title: (raw.title ?? "").trim(),
      pageUrl: (raw.url ?? "").trim(),
      thumbnail: thumb(raw.default_thumb || raw.thumb, "https://www.pornhub.com/"),
      duration: parseClock(raw.duration),
      views: parseViews(raw.views),
      rating: parseRating(raw.rating),
      added: raw.publish_date ?? null,
      tags: tagsFrom(raw.tags),
      source: "pornhub",
      playMode: "embed",
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  const total = results.length >= perPage ? page * perPage + 400 : (page - 1) * perPage + results.length;
  return { source: "pornhub", results, total, totalPages: Math.max(40, page + (results.length >= perPage ? 8 : 0)) };
}

async function searchRedtube(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const url = new URL("https://api.redtube.com/");
  url.searchParams.set("data", "redtube.Videos.searchVideos");
  url.searchParams.set("output", "json");
  url.searchParams.set("search", q === "all" ? "hot" : q);
  url.searchParams.set("thumbsize", "big");
  url.searchParams.set("page", String(page));
  url.searchParams.set("ordering", rtOrder(sort));

  const data = (await cachedJson(url.toString(), () => getJson(url.toString()))) as {
    count?: number | string;
    videos?: Array<{
      video?: {
        video_id?: string | number;
        title?: string;
        url?: string;
        duration?: string;
        views?: number | string;
        rating?: string | number;
        default_thumb?: string;
        thumb?: string;
        tags?: unknown;
        publish_date?: string;
        embed_url?: string;
      };
    }>;
  };

  const results: VideoCard[] = [];
  for (const wrap of data.videos ?? []) {
    const raw = wrap.video;
    if (!raw) continue;
    const mapped = card({
      id: encodeId("redtube", String(raw.video_id ?? "").trim()),
      title: (raw.title ?? "").trim(),
      pageUrl: (raw.url ?? "").trim(),
      thumbnail: thumb(raw.default_thumb || raw.thumb, "https://www.redtube.com/"),
      duration: parseClock(raw.duration),
      views: parseViews(raw.views),
      rating: parseRating(raw.rating),
      added: raw.publish_date ?? null,
      tags: tagsFrom(raw.tags),
      source: "redtube",
      playMode: "embed",
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  const total = Number(data.count) || results.length;
  return {
    source: "redtube",
    results,
    total: Number.isFinite(total) ? total : results.length,
    totalPages: Math.max(1, Math.ceil((Number.isFinite(total) ? total : results.length) / 20)),
  };
}

let rgToken: { value: string; exp: number } | null = null;

export async function redgifsToken(): Promise<string> {
  if (rgToken && rgToken.exp > Date.now() + 60_000) return rgToken.value;
  const data = (await getJson("https://api.redgifs.com/v2/auth/temporary")) as { token?: string };
  if (!data.token) throw Object.assign(new Error("Catalog unavailable"), { status: 502 });
  rgToken = { value: data.token, exp: Date.now() + 12 * 60 * 60 * 1000 };
  return data.token;
}

async function searchRedgifs(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const token = await redgifsToken();
  const q = orientQuery(query, orientation);
  const url = new URL("https://api.redgifs.com/v2/gifs/search");
  url.searchParams.set("search_text", q === "all" ? "amateur" : q);
  url.searchParams.set("count", String(Math.min(perPage, 40)));
  url.searchParams.set("page", String(page));
  if (q === "all") url.searchParams.set("order", rgOrder(sort));

  const data = (await cachedJson(`rg:${url.toString()}`, () =>
    getJson(url.toString(), { Authorization: `Bearer ${token}` }),
  )) as {
    total?: number;
    pages?: number;
    gifs?: Array<{
      id?: string;
      description?: string;
      duration?: number;
      views?: number;
      tags?: string[];
      urls?: { hd?: string; sd?: string; thumbnail?: string; poster?: string };
      userName?: string;
      sexuality?: unknown;
    }>;
  };

  const results: VideoCard[] = [];
  for (const raw of data.gifs ?? []) {
    const sex = String(raw.sexuality ?? "").toLowerCase();
    if (orientation === "straight" && (sex === "gay" || sex === "trans")) continue;
    if (orientation === "gay" && sex && sex !== "gay") continue;
    const title =
      (raw.description ?? "").trim() ||
      (raw.tags ?? []).slice(0, 3).join(" · ") ||
      (raw.userName ? `@${raw.userName}` : "RedGif");
    const mapped = card({
      id: encodeId("redgifs", (raw.id ?? "").trim()),
      title,
      pageUrl: raw.id ? `https://www.redgifs.com/watch/${raw.id}` : "",
      thumbnail: thumb(raw.urls?.poster || raw.urls?.thumbnail, "https://www.redgifs.com/"),
      duration: typeof raw.duration === "number" ? raw.duration : null,
      views: typeof raw.views === "number" ? raw.views : null,
      rating: null,
      added: null,
      tags: tagsFrom(raw.tags),
      source: "redgifs",
      playMode: "native",
      hd: Boolean(raw.urls?.hd),
    });
    if (mapped) results.push(mapped);
  }
  return {
    source: "redgifs",
    results,
    total: data.total ?? results.length,
    totalPages: data.pages ?? 1,
  };
}

const PARTNERS: Record<TubeSource, typeof searchEporner> = {
  eporner: searchEporner,
  pornhub: searchPornhub,
  redtube: searchRedtube,
  redgifs: searchRedgifs,
  xvideos: LISTING_SEARCH.xvideos,
  xnxx: LISTING_SEARCH.xnxx,
  youporn: LISTING_SEARCH.youporn,
  xhamster: LISTING_SEARCH.xhamster,
  tnaflix: LISTING_SEARCH.tnaflix,
  drtuber: LISTING_SEARCH.drtuber,
  nuvid: LISTING_SEARCH.nuvid,
  xozilla: LISTING_SEARCH.xozilla,
  pornhat: LISTING_SEARCH.pornhat,
  youjizz: LISTING_SEARCH.youjizz,
  hqporner: LISTING_SEARCH.hqporner,
  sunporno: LISTING_SEARCH.sunporno,
};

const LENGTH_SOURCES: TubeSource[] = [
  "eporner",
  "xvideos",
  "youporn",
  "tnaflix",
  "xozilla",
  "pornhat",
  "xhamster",
  "sunporno",
];

const DATE_SOURCES: TubeSource[] = [
  "pornhub",
  "eporner",
  "redtube",
  "xvideos",
  "youporn",
  "tnaflix",
  "xhamster",
];

const RATED_SOURCES: TubeSource[] = [
  "pornhub",
  "eporner",
  "xvideos",
  "youporn",
  "redtube",
  "tnaflix",
  "xhamster",
];

function applySort(results: VideoCard[], sort: SortMode): VideoCard[] {
  if (sort === "longest") {
    const MAX = 3.5 * 3600;
    const MIN = 12 * 60;
    const long = results.filter((v) => {
      const d = v.duration ?? 0;
      return d >= MIN && d <= MAX;
    });
    long.sort((a, b) => (b.duration ?? 0) - (a.duration ?? 0));
    if (long.length >= 8) return long;
    const rest = results.filter((v) => !long.includes(v));
    rest.sort((a, b) => (b.duration ?? 0) - (a.duration ?? 0));
    return [...long, ...rest];
  }
  if (sort === "top-rated") {
    return [...results].sort((a, b) => (b.rating ?? -1) - (a.rating ?? -1));
  }
  if (sort === "latest") {
    return [...results].sort((a, b) => {
      const da = a.added ? Date.parse(a.added) : 0;
      const db = b.added ? Date.parse(b.added) : 0;
      return (Number.isFinite(db) ? db : 0) - (Number.isFinite(da) ? da : 0);
    });
  }
  return results;
}

function emptyPage(source: TubeSource): PartnerPage {
  return { source, results: [], total: 0, totalPages: 0 };
}

function withTimeout(source: TubeSource, run: Promise<PartnerPage>, ms = 4000): Promise<PartnerPage> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(emptyPage(source)), ms);
    run
      .then((page) => {
        clearTimeout(timer);
        resolve(page);
      })
      .catch(() => {
        clearTimeout(timer);
        resolve(emptyPage(source));
      });
  });
}

function dedupeCards(results: VideoCard[]): VideoCard[] {
  const seenId = new Set<string>();
  const seenTitle = new Set<string>();
  const out: VideoCard[] = [];
  for (const v of results) {
    if (seenId.has(v.id)) continue;
    const key = v.title.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
    if (key.length >= 16 && seenTitle.has(key)) continue;
    seenId.add(v.id);
    if (key.length >= 16) seenTitle.add(key);
    out.push(v);
  }
  return out;
}

function interleave(pages: PartnerPage[]): VideoCard[] {
  const bySource = new Map(pages.map((p) => [p.source, p] as const));
  const ordered = ALL_SOURCES.map((s) => bySource.get(s)).filter((p): p is PartnerPage => Boolean(p));
  const out: VideoCard[] = [];
  const seen = new Set<string>();
  const max = Math.max(0, ...ordered.map((p) => p.results.length));
  for (let i = 0; i < max; i++) {
    for (const page of ordered) {
      const v = page.results[i];
      if (!v || seen.has(v.id)) continue;
      seen.add(v.id);
      out.push(v);
    }
  }
  return out;
}

async function gatherPages(
  nets: TubeSource[],
  run: (net: TubeSource) => Promise<PartnerPage>,
  mode: "all" | "query" | "length" = "all",
): Promise<PartnerPage[]> {
  const timeout = nets.length === 1 ? 8000 : mode === "all" ? 4200 : 6500;
  if (nets.length === 1) {
    const page = await withTimeout(nets[0]!, run(nets[0]!), timeout);
    return page.results.length ? [page] : [];
  }
  const collected: PartnerPage[] = [];
  const tasks = nets.map((net) =>
    withTimeout(net, run(net), timeout).then((page) => {
      collected.push(page);
      return page;
    }),
  );
  const all = Promise.all(tasks);
  if (mode === "length") {
    const early = new Promise<void>((resolve) => {
      const start = Date.now();
      const tick = () => {
        const live = collected.filter((p) => p.results.length > 0);
        if (live.length >= 3 || Date.now() - start >= 3800) {
          resolve();
          return;
        }
        setTimeout(tick, 80);
      };
      tick();
    });
    await Promise.race([all, early]);
    return collected.filter((p) => p.results.length > 0);
  }
  const early = new Promise<void>((resolve) => {
    const start = Date.now();
    const need = mode === "query" ? 3 : 6;
    const wait = mode === "query" ? 4500 : 2600;
    const extra = mode === "query" ? 700 : 1100;
    const tick = () => {
      const live = collected.filter((p) => p.results.length > 0);
      const quality = live.filter((p) => FAST_SOURCES.includes(p.source)).length;
      const enough = mode === "query" ? quality >= 2 && live.length >= need : live.length >= need;
      if (enough || Date.now() - start >= wait) {
        setTimeout(() => resolve(), extra);
        return;
      }
      setTimeout(tick, 70);
    };
    tick();
  });
  await Promise.race([all, early]);
  return collected.filter((p) => p.results.length > 0);
}

export async function searchPartners(opts: {
  query: string;
  page?: number;
  sort?: SortMode;
  orientation?: Orientation;
  net?: TubeSource | "all";
  only?: TubeSource[];
}): Promise<SearchResponse> {
  const query = opts.query.trim() || "all";
  if (query.length > 120) throw Object.assign(new Error("Query too long"), { status: 400 });
  if (isProhibitedText(query)) {
    throw Object.assign(new Error(prohibitedErrorMessage()), { status: 400 });
  }
  const page = Math.max(1, Math.min(opts.page ?? 1, 500));
  const sort = opts.sort ?? "most-popular";
  const orientation = opts.orientation ?? "straight";
  const nets: TubeSource[] = opts.only?.length
    ? opts.only
    : opts.net && opts.net !== "all"
      ? [opts.net]
      : ALL_SOURCES;
  const isQuery = query !== "all";
  const isLongest = sort === "longest";
  const isLatest = sort === "latest";
  const isRated = sort === "top-rated";
  let searchNets = isQuery ? nets.filter((n) => n !== "redgifs") : nets;
  if (isLongest) searchNets = searchNets.filter((n) => n !== "redgifs");
  if (searchNets.length > 1) {
    const prefer = isLongest ? LENGTH_SOURCES : isLatest ? DATE_SOURCES : isRated ? RATED_SOURCES : null;
    if (prefer) {
      const narrowed = searchNets.filter((n) => prefer.includes(n));
      if (narrowed.length) searchNets = narrowed;
    }
  }
  const perPage =
    searchNets.length === 1 ? SOLO_PAGE_SIZE : isQuery || isLongest || isLatest || isRated ? MIXED_PER_SOURCE * 2 : MIXED_PER_SOURCE;

  const pages = await gatherPages(
    searchNets,
    (net) => PARTNERS[net](query, page, sort, orientation, perPage),
    isLongest || isLatest || isRated ? "length" : isQuery ? "query" : "all",
  );

  const kept = isQuery
    ? pages.filter((p) => p.trusted || pageMatchesQuery(p.results, query))
    : pages;
  const use = kept.length > 0 ? kept : [];
  const ranked = use.map((p) => ({
    ...p,
    results: p.trusted ? p.results.map((v) => stampQuery(v, query)) : p.results,
  }));
  let results = interleave(ranked);
  if (isQuery) results = filterByQuery(results, query);
  results = results.filter((v) => fitsOrientation(v, orientation));
  results = applySort(results, sort);
  results = dedupeCards(results);
  const total = use.reduce((sum, p) => sum + p.total, 0);
  const rawPages = Math.max(1, ...use.map((p) => p.totalPages), results.length ? 1 : 0);
  const totalPages = searchNets.length === 1 ? Math.min(rawPages, 80) : Math.min(rawPages, 24);

  return {
    query,
    page,
    perPage: results.length || perPage,
    total,
    totalPages,
    results,
    sources: use.map((p) => p.source),
  };
}

export {
  MIXED_PER_SOURCE,
  SOLO_PAGE_SIZE,
  encodeId,
  getJson,
  parseClock,
  parseVideoId,
  parseViews,
  parseRating,
  tagsFrom,
  thumb,
};
