import { hmacSign, hmacVerify, PROXY_TTL_SECONDS, proxyMessage } from "./sign.ts";
import { BLAZE_SIGNING_SECRET } from "./secret.server.ts";
import { assertPublicHttpUrl } from "./ssrf.ts";

export function signProxyUrl(
  route: "image" | "stream",
  target: string,
  referer: string,
  ttl = PROXY_TTL_SECONDS,
): string {
  const url = assertPublicHttpUrl(target).href;
  const exp = Math.floor(Date.now() / 1000) + ttl;
  const sig = hmacSign(BLAZE_SIGNING_SECRET, proxyMessage(route, url, referer, exp));
  const params = new URLSearchParams({
    u: url,
    r: referer,
    e: String(exp),
    s: sig,
  });
  return `/api/${route}?${params.toString()}`;
}

export function verifyProxyRequest(
  route: "image" | "stream",
  u: string,
  r: string,
  e: string,
  s: string,
): { url: string; referer: string } {
  const exp = Number(e);
  if (!Number.isFinite(exp) || exp * 1000 < Date.now()) {
    throw Object.assign(new Error("Expired signature"), { status: 403 });
  }
  const target = assertPublicHttpUrl(u).href;
  const ok = hmacVerify(BLAZE_SIGNING_SECRET, proxyMessage(route, target, r, exp), s);
  if (!ok) throw Object.assign(new Error("Invalid signature"), { status: 403 });
  return { url: target, referer: r };
}
