import { createHash } from "node:crypto";
import { BLAZE_SIGNING_SECRET } from "./secret.server.ts";

type Bucket = { timestamps: number[]; windowMs: number; limit: number };

const buckets = new Map<string, Bucket>();
const MAX_KEYS = 4000;

export type RateName = "search" | "playable" | "stream" | "image";

const LIMITS: Record<RateName, { limit: number; windowMs: number }> = {
  search: { limit: 60, windowMs: 5 * 60 * 1000 },
  playable: { limit: 40, windowMs: 5 * 60 * 1000 },
  stream: { limit: 900, windowMs: 5 * 60 * 1000 },
  image: { limit: 400, windowMs: 5 * 60 * 1000 },
};

function clientKey(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for") ?? "";
  const ip = forwarded.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "local";
  return createHash("sha256")
    .update(`${BLAZE_SIGNING_SECRET}:${ip}`)
    .digest("hex")
    .slice(0, 20);
}

function prune() {
  if (buckets.size < MAX_KEYS) return;
  const now = Date.now();
  for (const [k, b] of buckets) {
    b.timestamps = b.timestamps.filter((t) => now - t < b.windowMs);
    if (b.timestamps.length === 0) buckets.delete(k);
    if (buckets.size < MAX_KEYS / 2) break;
  }
}

export function consumeRate(request: Request, name: RateName): { ok: true } | { ok: false; retryAfter: number } {
  prune();
  const spec = LIMITS[name];
  const key = `${name}:${clientKey(request)}`;
  const now = Date.now();
  let bucket = buckets.get(key);
  if (!bucket) {
    bucket = { timestamps: [], windowMs: spec.windowMs, limit: spec.limit };
    buckets.set(key, bucket);
  }
  bucket.timestamps = bucket.timestamps.filter((t) => now - t < spec.windowMs);
  if (bucket.timestamps.length >= spec.limit) {
    const oldest = bucket.timestamps[0] ?? now;
    const retryAfter = Math.max(1, Math.ceil((spec.windowMs - (now - oldest)) / 1000));
    return { ok: false, retryAfter };
  }
  bucket.timestamps.push(now);
  return { ok: true };
}
