import type { PlayableQuality, PlayableResponse, TubeSource } from "./types.ts";
import { SOURCE_META, SOURCE_PREFIX } from "./types.ts";
import { isProhibitedText } from "./policy.ts";
import { signProxyUrl } from "./proxy-sign.server.ts";
import { safeFetchText } from "./fetch-safe.server.ts";
import { absUrl, cleanTitle, decodeEntities } from "./html.ts";
import { getHtml } from "./cards.server.ts";
import { getJson, parseClock, parseVideoId, redgifsToken, tagsFrom, thumb } from "./partners.server.ts";
import {
  collectMp4Qualities,
  fetchVideoPage,
  qualitiesFromMediaDefinitions,
  qualitiesFromXvideos,
} from "./streams.server.ts";

const EP_ID_RE = /^[A-Za-z0-9]{6,16}$/;

export function parseDownloadQualities(html: string, pageUrl: string): PlayableQuality[] {
  const found: PlayableQuality[] = [];
  const re = /href="([^"]*\/dload\/[^"]+)"([^>]*)>([^<]*)/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const href = absUrl(m[1] ?? "", pageUrl);
    const attrs = m[2] ?? "";
    const labelRaw = decodeEntities(m[3] ?? "");
    if (!href || /\.mp4/i.test(href) === false) continue;
    if (/av1/i.test(href) || /av1/i.test(labelRaw)) continue;
    if (/checkSilent|login/i.test(attrs)) continue;
    const heightMatch = href.match(/\/(\d{3,4})\//) ?? labelRaw.match(/(\d{3,4})\s*p/i);
    const height = heightMatch ? Number(heightMatch[1]) : 0;
    if (!Number.isFinite(height) || height < 144) continue;
    if (found.some((q) => q.height === height)) continue;
    found.push({
      label: `${height}p`,
      height,
      url: signProxyUrl("stream", href, pageUrl),
    });
  }
  found.sort((a, b) => b.height - a.height);
  return found;
}

function parseContentUrl(html: string): string | null {
  const m = html.match(/"contentUrl"\s*:\s*"([^"]+)"/i);
  if (!m?.[1]) return null;
  const url = decodeEntities(m[1]);
  if (!/^https?:\/\//i.test(url)) return null;
  if (!/\.mp4(\?|$)/i.test(url)) return null;
  if (/gvideo\.eporner\.com/i.test(url)) return null;
  return url;
}

function parseTitle(html: string): string {
  const og = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i);
  if (og?.[1]) return decodeEntities(og[1]).replace(/\s*[|-]\s*EPORNER.*$/i, "").trim();
  const t = html.match(/<title>([^<]+)<\/title>/i);
  if (t?.[1]) return decodeEntities(t[1]).replace(/\s*[|-]\s*EPORNER.*$/i, "").trim();
  return "Video";
}

function stripSite(title: string): string {
  return cleanTitle(title)
    .replace(
      /\s*[|-]\s*(Pornhub|XVideos|XNXX|YouPorn|RedTube|xHamster|TNAFlix|DrTuber|Nuvid|Xozilla|PornHat|YouJizz|HQPorner|SunPorno|EPORNER).*$/i,
      "",
    )
    .trim();
}

function parseOgImage(html: string): string | null {
  return html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1] ?? null;
}

function parseTagsFromPage(html: string): string[] {
  const tags = new Set<string>();
  const re = /\/cat\/([a-z0-9-]+)\//gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const slug = (m[1] ?? "").replace(/-/g, " ");
    if (slug && slug.length < 32 && !isProhibitedText(slug)) tags.add(slug);
    if (tags.size >= 16) break;
  }
  return [...tags];
}

function nativePlayable(
  source: TubeSource,
  raw: string,
  pageUrl: string,
  qualities: PlayableQuality[],
  meta: {
    title: string;
    tags?: string[];
    views?: number | null;
    duration?: number | null;
    thumbnail?: string | null;
  },
): PlayableResponse {
  if (!qualities.length) throw Object.assign(new Error("Media unavailable"), { status: 404 });
  const title = meta.title && meta.title !== "Video" ? meta.title : `${SOURCE_META[source].label} video`;
  if (isProhibitedText(title)) throw Object.assign(new Error("That video is blocked."), { status: 404 });
  return {
    id: `${SOURCE_PREFIX[source]}-${raw}`,
    title,
    pageUrl,
    fileUrl: qualities[0]!.url,
    qualities,
    tags: meta.tags ?? [],
    views: meta.views ?? null,
    duration: meta.duration ?? null,
    thumbnail: meta.thumbnail ?? null,
    source,
    playMode: "native",
    embedUrl: null,
  };
}

async function resolveEporner(raw: string): Promise<PlayableResponse> {
  if (!EP_ID_RE.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.eporner.com/video-${raw}/`;
  const res = await safeFetchText(pageUrl, {
    timeout: 9000,
    maxBytes: 1_800_000,
    headers: { Accept: "text/html,application/xhtml+xml" },
  });
  if (res.status >= 400) {
    throw Object.assign(new Error("Media unavailable"), { status: 404 });
  }
  const html = res.text;
  const title = parseTitle(html);
  if (isProhibitedText(title, html.slice(0, 4000))) {
    throw Object.assign(new Error("That video is blocked."), { status: 404 });
  }
  let qualities = parseDownloadQualities(html, res.url || pageUrl);
  const content = parseContentUrl(html);
  if (qualities.length === 0 && content) {
    qualities = [{ label: "MP4", height: 720, url: signProxyUrl("stream", content, pageUrl) }];
  }
  if (qualities.length === 0) {
    throw Object.assign(new Error("Media unavailable"), { status: 404 });
  }
  const thumbSrc = parseOgImage(html);
  const durationMatch = html.match(/"duration"\s*:\s*"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?"/i);
  let duration: number | null = null;
  if (durationMatch) {
    duration =
      Number(durationMatch[1] ?? 0) * 3600 +
      Number(durationMatch[2] ?? 0) * 60 +
      Number(durationMatch[3] ?? 0);
    if (!duration) duration = null;
  }
  const viewsMatch = html.match(/([\d,]+)\s*views/i);
  const views = viewsMatch ? Number(viewsMatch[1]!.replace(/,/g, "")) : null;

  return {
    id: `ep-${raw}`,
    title,
    pageUrl,
    fileUrl: qualities[0]!.url,
    qualities,
    tags: parseTagsFromPage(html),
    views: Number.isFinite(views) ? views : null,
    duration,
    thumbnail: thumbSrc ? signProxyUrl("image", thumbSrc, pageUrl) : null,
    source: "eporner",
    playMode: "native",
    embedUrl: null,
  };
}

async function resolvePornhub(raw: string): Promise<PlayableResponse> {
  if (!/^[A-Za-z0-9]{6,24}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.pornhub.com/view_video.php?viewkey=${raw}`;
  try {
    const page = await fetchVideoPage(pageUrl);
    const title = stripSite(parseTitle(page.html)) || "Pornhub video";
    const qualities = await qualitiesFromMediaDefinitions(page.html, page.url);
    if (qualities.length) {
      const viewsMatch = page.html.match(/([\d,]+)\s*views/i);
      const views = viewsMatch ? Number(viewsMatch[1]!.replace(/,/g, "")) : null;
      return nativePlayable("pornhub", raw, pageUrl, qualities, {
        title,
        tags: tagsFrom(
          [...page.html.matchAll(/\/video\/search\?search=([^"'&]+)/gi)].map((m) =>
            decodeURIComponent(m[1] ?? "").replace(/\+/g, " "),
          ),
        ),
        views: Number.isFinite(views) ? views : null,
        duration: parseClock(page.html.match(/"duration"\s*:\s*"([^"]+)"/)?.[1] ?? null),
        thumbnail: thumb(parseOgImage(page.html), pageUrl),
      });
    }
  } catch {
    /* embed fallback */
  }
  let title = "Pornhub video";
  let tags: string[] = [];
  let views: number | null = null;
  let duration: number | null = null;
  let thumbnail: string | null = null;
  let resolvedPage = pageUrl;
  try {
    const data = (await getJson(
      `https://www.pornhub.com/webmasters/video_by_id?id=${encodeURIComponent(raw)}&thumbsize=large`,
    )) as {
      video?: {
        title?: string;
        url?: string;
        duration?: string;
        views?: number;
        tags?: unknown;
        default_thumb?: string;
      };
    };
    const hit = data.video;
    if (hit?.title) title = hit.title;
    if (hit?.url) resolvedPage = hit.url;
    if (hit?.views) views = hit.views;
    if (hit?.duration) duration = parseClock(hit.duration);
    tags = tagsFrom(hit?.tags);
    thumbnail = thumb(hit?.default_thumb, "https://www.pornhub.com/");
  } catch {
    /* embed still works */
  }
  const embedUrl = `https://www.pornhub.com/embed/${raw}`;
  return embedPlayable("pornhub", raw, resolvedPage, embedUrl, { title, image: null, tags, views, duration, thumbnail });
}

async function resolveRedtube(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{4,12}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.redtube.com/${raw}`;
  try {
    const page = await fetchVideoPage(pageUrl);
    const qualities = await qualitiesFromMediaDefinitions(page.html, page.url);
    if (qualities.length) {
      return nativePlayable("redtube", raw, pageUrl, qualities, {
        title: stripSite(parseTitle(page.html)),
        tags: tagsFrom(
          [...page.html.matchAll(/<meta[^>]+(?:name|property)=["'](?:video:tag|og:video:tag)["'][^>]+content=["']([^"']+)/gi)].map(
            (m) => m[1] ?? "",
          ),
        ),
        thumbnail: thumb(parseOgImage(page.html), pageUrl),
        duration: parseClock(page.html.match(/"duration"\s*:\s*"([^"]+)"/)?.[1] ?? null),
      });
    }
  } catch {
    /* fall through */
  }
  const url = `https://api.redtube.com/?data=redtube.Videos.getVideoById&video_id=${encodeURIComponent(raw)}&output=json&thumbsize=big`;
  const data = (await getJson(url)) as {
    video?: {
      title?: string;
      url?: string;
      duration?: string;
      views?: number | string;
      tags?: unknown;
      default_thumb?: string;
      embed_url?: string;
    };
  };
  const v = data.video;
  if (!v?.title) throw Object.assign(new Error("Media unavailable"), { status: 404 });
  if (isProhibitedText(v.title)) throw Object.assign(new Error("That video is blocked."), { status: 404 });
  const embedUrl = v.embed_url || `https://embed.redtube.com/?id=${raw}`;
  const views = typeof v.views === "number" ? v.views : Number(v.views);
  return embedPlayable("redtube", raw, v.url || pageUrl, embedUrl, {
    title: v.title,
    image: v.default_thumb ?? null,
    tags: tagsFrom(v.tags),
    views: Number.isFinite(views) ? views : null,
    duration: parseClock(v.duration),
  });
}

async function resolveRedgifs(raw: string): Promise<PlayableResponse> {
  if (!/^[A-Za-z0-9]{4,48}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const token = await redgifsToken();
  const data = (await getJson(`https://api.redgifs.com/v2/gifs/${encodeURIComponent(raw)}`, {
    Authorization: `Bearer ${token}`,
  })) as {
    gif?: {
      id?: string;
      description?: string;
      duration?: number;
      views?: number;
      tags?: string[];
      urls?: { hd?: string; sd?: string; poster?: string; thumbnail?: string };
      userName?: string;
    };
  };
  const g = data.gif;
  if (!g?.urls) throw Object.assign(new Error("Media unavailable"), { status: 404 });
  const title =
    (g.description ?? "").trim() ||
    (g.tags ?? []).slice(0, 3).join(" · ") ||
    (g.userName ? `@${g.userName}` : "RedGif");
  if (isProhibitedText(title, (g.tags ?? []).join(" "))) {
    throw Object.assign(new Error("That video is blocked."), { status: 404 });
  }
  const pageUrl = `https://www.redgifs.com/watch/${g.id ?? raw}`;
  const qualities: PlayableQuality[] = [];
  if (g.urls.hd) {
    qualities.push({ label: "HD", height: 1080, url: signProxyUrl("stream", g.urls.hd, pageUrl) });
  }
  if (g.urls.sd) {
    qualities.push({ label: "SD", height: 480, url: signProxyUrl("stream", g.urls.sd, pageUrl) });
  }
  if (qualities.length === 0) throw Object.assign(new Error("Media unavailable"), { status: 404 });
  return {
    id: `rg-${raw}`,
    title,
    pageUrl,
    fileUrl: qualities[0]!.url,
    qualities,
    tags: tagsFrom(g.tags),
    views: typeof g.views === "number" ? g.views : null,
    duration: typeof g.duration === "number" ? g.duration : null,
    thumbnail: thumb(g.urls.poster || g.urls.thumbnail, pageUrl),
    source: "redgifs",
    playMode: "native",
    embedUrl: null,
  };
}

async function headMeta(pageUrl: string): Promise<{ title: string; image: string | null; tags: string[] }> {
  try {
    const html = await getHtml(pageUrl, 7000);
    const title = stripSite(parseTitle(html)) || "Video";
    const image = parseOgImage(html);
    const tags = tagsFrom(
      [...html.matchAll(/<meta[^>]+(?:name|property)=["'](?:video:tag|og:video:tag)["'][^>]+content=["']([^"']+)/gi)].map(
        (m) => m[1] ?? "",
      ),
    );
    return { title: title || "Video", image, tags };
  } catch {
    return { title: "Video", image: null, tags: [] };
  }
}

async function nativeFromPages(
  source: TubeSource,
  raw: string,
  pageUrl: string,
  urls: string[],
  meta: {
    title: string;
    image: string | null;
    tags: string[];
    views?: number | null;
    duration?: number | null;
    thumbnail?: string | null;
  },
): Promise<PlayableResponse | null> {
  for (const url of urls) {
    try {
      const html = await getHtml(url, 8000);
      const qualities = collectMp4Qualities(html, url);
      if (qualities.length) {
        return nativePlayable(source, raw, pageUrl, qualities, {
          title: meta.title,
          tags: meta.tags,
          views: meta.views,
          duration: meta.duration,
          thumbnail: meta.thumbnail ?? thumb(meta.image, pageUrl),
        });
      }
    } catch {
      /* try next */
    }
  }
  return null;
}

function embedPlayable(
  source: TubeSource,
  raw: string,
  pageUrl: string,
  embedUrl: string,
  meta: {
    title: string;
    image: string | null;
    tags: string[];
    views?: number | null;
    duration?: number | null;
    thumbnail?: string | null;
  },
): PlayableResponse {
  if (isProhibitedText(meta.title)) throw Object.assign(new Error("That video is blocked."), { status: 404 });
  const prefix = SOURCE_PREFIX[source];
  return {
    id: `${prefix}-${raw}`,
    title: meta.title && meta.title !== "Video" ? meta.title : `${SOURCE_META[source].label} video`,
    pageUrl,
    fileUrl: embedUrl,
    qualities: [],
    tags: meta.tags,
    views: meta.views ?? null,
    duration: meta.duration ?? null,
    thumbnail: meta.thumbnail ?? thumb(meta.image, pageUrl),
    source,
    playMode: "embed",
    embedUrl,
  };
}

async function resolveXvideos(raw: string): Promise<PlayableResponse> {
  if (!/^[A-Za-z0-9._-]{4,24}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = /^\d+$/.test(raw) ? `https://www.xvideos.com/video${raw}/x` : `https://www.xvideos.com/video.${raw}/x`;
  const embedUrl = `https://www.xvideos.com/embedframe/${raw}`;
  try {
    const page = await fetchVideoPage(pageUrl);
    const qualities = await qualitiesFromXvideos(page.html, page.url);
    if (qualities.length) {
      return nativePlayable("xvideos", raw, pageUrl, qualities, {
        title: stripSite(parseTitle(page.html)),
        thumbnail: thumb(parseOgImage(page.html), pageUrl),
        duration: parseClock(page.html.match(/duration['"]?\s*[:=]\s*['"]?(\d+:\d+(?::\d+)?)/i)?.[1] ?? null),
      });
    }
  } catch {
    /* embed fallback */
  }
  const meta = await headMeta(pageUrl);
  return embedPlayable("xvideos", raw, pageUrl, embedUrl, meta);
}

async function resolveXnxx(raw: string): Promise<PlayableResponse> {
  if (!/^[A-Za-z0-9._-]{4,24}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.xnxx.com/video-${raw}/x`;
  const embedUrl = `https://www.xnxx.com/embedframe/${raw}`;
  try {
    const page = await fetchVideoPage(pageUrl);
    const qualities = await qualitiesFromXvideos(page.html, page.url);
    if (qualities.length) {
      return nativePlayable("xnxx", raw, pageUrl, qualities, {
        title: stripSite(parseTitle(page.html)),
        thumbnail: thumb(parseOgImage(page.html), pageUrl),
      });
    }
  } catch {
    /* embed fallback */
  }
  const meta = await headMeta(pageUrl);
  return embedPlayable("xnxx", raw, pageUrl, embedUrl, meta);
}

async function resolveYouporn(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{4,12}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.youporn.com/watch/${raw}/`;
  const embedUrl = `https://www.youporn.com/embed/${raw}/`;
  try {
    const page = await fetchVideoPage(pageUrl);
    const qualities = await qualitiesFromMediaDefinitions(page.html, page.url);
    if (qualities.length) {
      return nativePlayable("youporn", raw, pageUrl, qualities, {
        title: stripSite(parseTitle(page.html)),
        tags: tagsFrom(
          [...page.html.matchAll(/<meta[^>]+(?:name|property)=["'](?:video:tag|og:video:tag)["'][^>]+content=["']([^"']+)/gi)].map(
            (m) => m[1] ?? "",
          ),
        ),
        thumbnail: thumb(parseOgImage(page.html), pageUrl),
      });
    }
  } catch {
    /* embed fallback */
  }
  const meta = await headMeta(embedUrl);
  return embedPlayable("youporn", raw, pageUrl, embedUrl, meta);
}

async function resolveXhamster(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{4,12}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://xhamster.com/videos/${raw}`;
  const embedUrl = `https://xhamster.com/embed/${raw}`;
  const meta = await headMeta(pageUrl);
  return (
    (await nativeFromPages("xhamster", raw, pageUrl, [embedUrl, pageUrl], meta)) ??
    embedPlayable("xhamster", raw, pageUrl, embedUrl, meta)
  );
}

async function resolveTnaflix(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{4,12}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.tnaflix.com/video${raw}`;
  const embedUrl = `https://player.tnaflix.com/video/${raw}`;
  try {
    const html = await getHtml(embedUrl, 8000);
    const qualities = collectMp4Qualities(html, embedUrl);
    if (qualities.length) {
      return nativePlayable("tnaflix", raw, pageUrl, qualities, {
        title: stripSite(parseTitle(html)),
        thumbnail: thumb(parseOgImage(html), pageUrl),
      });
    }
  } catch {
    /* embed fallback */
  }
  const meta = await headMeta(embedUrl);
  return embedPlayable("tnaflix", raw, pageUrl, embedUrl, meta);
}

async function resolveDrtuber(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{4,12}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.drtuber.com/video/${raw}/`;
  const embedUrl = `https://www.drtuber.com/embed/${raw}`;
  const meta = await headMeta(pageUrl);
  return (
    (await nativeFromPages("drtuber", raw, pageUrl, [embedUrl, pageUrl], meta)) ??
    embedPlayable("drtuber", raw, pageUrl, embedUrl, meta)
  );
}

async function resolveNuvid(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{4,12}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.nuvid.com/video/${raw}/`;
  const embedUrl = `https://www.nuvid.com/embed/${raw}`;
  const meta = await headMeta(pageUrl);
  return (
    (await nativeFromPages("nuvid", raw, pageUrl, [embedUrl, pageUrl], meta)) ??
    embedPlayable("nuvid", raw, pageUrl, embedUrl, meta)
  );
}

async function resolveXozilla(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{4,12}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.xozilla.com/videos/${raw}/x/`;
  const embedUrl = `https://www.xozilla.com/embed/${raw}`;
  const meta = await headMeta(pageUrl);
  return (
    (await nativeFromPages("xozilla", raw, pageUrl, [embedUrl, pageUrl], meta)) ??
    embedPlayable("xozilla", raw, pageUrl, embedUrl, meta)
  );
}

async function resolvePornhat(raw: string): Promise<PlayableResponse> {
  if (!/^[A-Za-z0-9-]{3,80}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const isNumeric = /^\d+$/.test(raw);
  const pageUrl = isNumeric ? `https://www.pornhat.com/videos/${raw}/` : `https://www.pornhat.com/video/${raw}/`;
  let embedId = raw;
  if (!isNumeric) {
    try {
      const html = await getHtml(pageUrl, 7000);
      embedId =
        html.match(/\/embed\/(\d+)/)?.[1] ||
        html.match(/videos_screenshots\/\d+\/(\d+)/)?.[1] ||
        raw;
    } catch {
      embedId = raw;
    }
  }
  const embedUrl = /^\d+$/.test(embedId)
    ? `https://www.pornhat.com/embed/${embedId}`
    : pageUrl;
  const meta = await headMeta(pageUrl);
  return (
    (await nativeFromPages("pornhat", raw, pageUrl, [embedUrl, pageUrl], meta)) ??
    embedPlayable("pornhat", raw, pageUrl, embedUrl, meta)
  );
}

async function resolveYoujizz(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{5,12}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const embedUrl = `https://www.youjizz.com/videos/embed/${raw}`;
  const pageUrl = `https://www.youjizz.com/videos/${raw}.html`;
  const meta = await headMeta(embedUrl);
  return (
    (await nativeFromPages("youjizz", raw, pageUrl, [embedUrl, pageUrl], meta)) ??
    embedPlayable("youjizz", raw, pageUrl, embedUrl, meta)
  );
}

async function resolveHqporner(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{3,8}(?:-[A-Za-z0-9_-]+)?$/.test(raw)) {
    throw Object.assign(new Error("Invalid video"), { status: 400 });
  }
  const pageUrl = `https://hqporner.com/hdporn/${raw}.html`;
  const html = await getHtml(pageUrl, 8000);
  const title = parseTitle(html).replace(/\s*[|-]\s*HQPorner.*$/i, "").trim() || "HQPorner video";
  if (isProhibitedText(title)) throw Object.assign(new Error("That video is blocked."), { status: 404 });
  const frame =
    html.match(/src=["'](\/\/(?:mydaddy\.cc|hqwo\.cc)\/video\/[^"']+)/i)?.[1] ||
    html.match(/src=["'](https:\/\/(?:mydaddy\.cc|hqwo\.cc)\/video\/[^"']+)/i)?.[1];
  if (!frame) throw Object.assign(new Error("Media unavailable"), { status: 404 });
  const embedUrl = frame.startsWith("http") ? frame : `https:${frame}`;
  const thumbSrc = thumb(parseOgImage(html), pageUrl);
  const duration = parseClock(html.match(/(\d{1,2}:\d{2}(?::\d{2})?)/)?.[1] ?? null);
  const native = await nativeFromPages(
    "hqporner",
    raw,
    pageUrl,
    [embedUrl],
    { title, image: null, tags: parseTagsFromPage(html), duration, thumbnail: thumbSrc },
  );
  if (native) return native;
  return {
    id: `hq-${raw}`,
    title,
    pageUrl,
    fileUrl: embedUrl,
    qualities: [],
    tags: parseTagsFromPage(html),
    views: null,
    duration,
    thumbnail: thumbSrc,
    source: "hqporner",
    playMode: "embed",
    embedUrl,
  };
}

async function resolveSunporno(raw: string): Promise<PlayableResponse> {
  if (!/^[0-9]{3,12}$/.test(raw)) throw Object.assign(new Error("Invalid video"), { status: 400 });
  const pageUrl = `https://www.sunporno.com/v/${raw}/`;
  const embedUrl = `https://www.sunporno.com/embed/${raw}`;
  let title = "SunPorno video";
  let image: string | null = null;
  try {
    const html = await getHtml(embedUrl, 7000);
    title =
      html.match(/video_title:\s*'([^']+)'/)?.[1] ||
      parseTitle(html).replace(/\s*[|-]\s*SunPorno.*$/i, "").trim() ||
      title;
    image = html.match(/preview_url:\s*'(https:[^']+)'/)?.[1] ?? parseOgImage(html);
  } catch {
    const meta = await headMeta(pageUrl);
    title = meta.title || title;
    image = meta.image;
  }
  return (
    (await nativeFromPages("sunporno", raw, pageUrl, [embedUrl, pageUrl], { title, image, tags: [] })) ??
    embedPlayable("sunporno", raw, pageUrl, embedUrl, { title, image, tags: [] })
  );
}

const RESOLVERS: Record<TubeSource, (raw: string) => Promise<PlayableResponse>> = {
  eporner: resolveEporner,
  pornhub: resolvePornhub,
  redtube: resolveRedtube,
  redgifs: resolveRedgifs,
  xvideos: resolveXvideos,
  xnxx: resolveXnxx,
  youporn: resolveYouporn,
  xhamster: resolveXhamster,
  tnaflix: resolveTnaflix,
  drtuber: resolveDrtuber,
  nuvid: resolveNuvid,
  xozilla: resolveXozilla,
  pornhat: resolvePornhat,
  youjizz: resolveYoujizz,
  hqporner: resolveHqporner,
  sunporno: resolveSunporno,
};

export async function resolvePlayable(id: string): Promise<PlayableResponse> {
  const { source, raw } = parseVideoId(id.trim());
  if (!raw) throw Object.assign(new Error("Invalid video"), { status: 400 });
  return RESOLVERS[source](raw);
}
