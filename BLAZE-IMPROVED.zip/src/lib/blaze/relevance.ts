import type { VideoCard } from "./types.ts";
import { CATEGORIES } from "./categories.ts";

const WEAK = new Set([
  "a",
  "an",
  "and",
  "the",
  "of",
  "to",
  "in",
  "on",
  "for",
  "with",
  "hot",
  "sex",
  "porn",
  "video",
  "videos",
  "free",
  "hd",
  "xxx",
  "girl",
  "girls",
  "guy",
  "big",
  "all",
]);

const QUERY_ALIASES: Record<string, string[]> = {
  amateur: ["amateur", "homemade"],
  anal: ["anal", "ass fuck", "assfucking"],
  asian: ["asian", "japanese", "korean", "chinese", "thai", "filipina", "jav"],
  bbc: ["bbc", "big black cock"],
  bbw: ["bbw", "curvy", "chubby", "plus size"],
  "big ass": ["big ass", "pawg", "phat ass", "huge ass"],
  "big tits": ["big tits", "big boobs", "busty", "huge tits"],
  blonde: ["blonde", "blond"],
  blowjob: ["blowjob", "blow job", "pov blowjob", "cock sucking"],
  bondage: ["bondage", "bdsm", "tied up"],
  brunette: ["brunette"],
  college: ["college", "campus", "sorority"],
  compilation: ["compilation", "comp"],
  cosplay: ["cosplay", "costume"],
  couple: ["couple", "homemade couple"],
  creampie: ["creampie", "cream pie", "internal"],
  cuckold: ["cuckold", "cuck", "hotwife"],
  cumshot: ["cumshot", "facial", "cum shot"],
  deepthroat: ["deepthroat", "deep throat"],
  ebony: ["ebony"],
  feet: ["feet", "footjob", "soles", "foot fetish"],
  fetish: ["fetish"],
  gangbang: ["gangbang", "gang bang"],
  hardcore: ["hardcore"],
  hentai: ["hentai", "anime hentai", "2d hentai"],
  homemade: ["homemade", "amateur"],
  indian: ["indian", "desi", "hindi"],
  interracial: ["interracial", "bbc"],
  japanese: ["japanese", "jav", "japan"],
  goth: ["goth", "emo"],
  femdom: ["femdom", "dominatrix"],
  joi: ["joi", "jerk off instruction"],
  asmr: ["asmr"],
  latina: ["latina", "latin", "mexican", "colombian"],
  lesbian: ["lesbian", "lesbians", "girl on girl"],
  massage: ["massage"],
  mature: ["mature", "cougar"],
  milf: ["milf", "cougar", "stepmom", "step mom", "stepmother"],
  onlyfans: ["onlyfans"],
  orgy: ["orgy", "group sex"],
  outdoor: ["outdoor", "outside"],
  pov: ["pov", "point of view"],
  public: ["public", "outdoors"],
  redhead: ["redhead", "ginger"],
  rough: ["rough sex", "rough"],
  solo: ["solo", "masturbat"],
  squirt: ["squirt", "squirting"],
  stepmom: ["stepmom", "step mom", "stepmother"],
  stockings: ["stockings", "nylons", "pantyhose"],
  teen: ["teen", "18+", "eighteen"],
  threesome: ["threesome", "ffm", "fmf", "mfm"],
  toys: ["dildo", "vibrator", "sex toy"],
  uniform: ["uniform", "nurse", "maid", "teacher"],
  vintage: ["vintage", "classic", "retro"],
  wife: ["wife", "married", "hotwife"],
  "4k": ["4k", "uhd", "2160"],
  vr: ["vr", "virtual reality"],
  arab: ["arab", "arabic", "hijab"],
  brazilian: ["brazilian", "brazil"],
  european: ["european", "euro"],
  french: ["french", "france"],
  german: ["german"],
  korean: ["korean", "korea"],
  russian: ["russian", "russia"],
  pawg: ["pawg", "phat ass"],
  petite: ["petite"],
  casting: ["casting", "audition"],
  office: ["office", "secretary", "coworker"],
  cheating: ["cheating", "affair"],
  shower: ["shower", "bathroom"],
  oil: ["oiled", "oil massage"],
  gym: ["gym", "workout"],
  maid: ["maid"],
  nurse: ["nurse"],
  teacher: ["teacher"],
  "double penetration": ["double penetration", "double penet", " d.p"],
  hotwife: ["hotwife", "cuckold"],
  swinger: ["swinger", "swinging"],
  pegging: ["pegging"],
  rimming: ["rimming", "rimjob"],
  latex: ["latex"],
  tattoo: ["tattoo", "tattooed"],
  glasses: ["glasses"],
  hairy: ["hairy", "bush"],
  cartoon: ["cartoon", "hentai"],
  "3d": ["3d hentai", "3d porn"],
  parody: ["parody"],
  yoga: ["yoga"],
  car: ["car sex", "backseat", "parking lot"],
  hotel: ["hotel"],
  secretary: ["secretary"],
  cougar: ["cougar", "milf"],
  roleplay: ["roleplay", "role play"],
  caught: ["caught"],
  edging: ["edging"],
  facesitting: ["facesitting", "face sitting"],
  emo: ["emo", "goth"],
  "alt girl": ["alt girl", "goth", "emo"],
  bimbo: ["bimbo"],
  "step sister": ["step sister", "stepsister", "step sis"],
  trans: ["trans", "transgender", "shemale"],
  gay: ["gay"],
  bareback: ["bareback"],
  twink: ["twink"],
  bear: ["bear"],
  muscle: ["muscle", "jock"],
};

export function tokensForQuery(query: string): string[] {
  const q = query.trim().toLowerCase();
  if (!q || q === "all") return [];
  const cat = CATEGORIES.find((c) => c.query.toLowerCase() === q || c.slug === q.replace(/\s+/g, "-"));
  const extra = QUERY_ALIASES[q] ?? QUERY_ALIASES[cat?.query ?? ""] ?? [];
  const parts = q.split(/[\s/_-]+/).filter(Boolean);
  return [...new Set([q, ...parts, ...extra].map((t) => t.toLowerCase()))].filter(
    (t) => t.length >= 2 && !WEAK.has(t),
  );
}

function haystack(video: VideoCard): string {
  return `${video.title} ${(video.tags ?? []).join(" ")}`.toLowerCase();
}

export function scoreCard(video: VideoCard, query: string): number {
  const phrase = query.trim().toLowerCase();
  const tokens = tokensForQuery(query);
  if (!phrase || phrase === "all" || tokens.length === 0) return 1;
  const hay = haystack(video);
  let score = 0;
  if (hay.includes(phrase)) score += 10;
  for (const token of tokens) {
    if (token === phrase) continue;
    if (hay.includes(token)) score += token.length >= 5 ? 4 : 3;
  }
  return score;
}

export function filterByQuery(results: VideoCard[], query: string): VideoCard[] {
  const phrase = query.trim().toLowerCase();
  if (!phrase || phrase === "all") return results;
  const scored = results.map((v) => ({ v, s: scoreCard(v, phrase) }));
  scored.sort((a, b) => b.s - a.s);
  return scored.filter((x) => x.s > 0).map((x) => x.v);
}

export function pageMatchesQuery(results: VideoCard[], query: string): boolean {
  const phrase = query.trim().toLowerCase();
  if (!phrase || phrase === "all") return true;
  if (results.length === 0) return false;
  const hits = results.filter((v) => scoreCard(v, phrase) > 0).length;
  return hits >= Math.max(2, Math.ceil(results.length * 0.18));
}

export function stampQuery(video: VideoCard, query: string): VideoCard {
  const q = query.trim().toLowerCase();
  if (!q || q === "all") return video;
  if (video.tags.some((t) => t.toLowerCase() === q)) return video;
  return { ...video, tags: [q, ...video.tags].slice(0, 12) };
}
