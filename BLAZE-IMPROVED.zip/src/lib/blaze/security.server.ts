export function applySecurityHeaders(headers: Headers, kind: "private" | "image" | "stream" | "ok" = "private"): void {
  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("Referrer-Policy", "no-referrer");
  headers.set("X-Frame-Options", "DENY");
  headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  headers.set("Cross-Origin-Resource-Policy", "same-origin");
  headers.delete("X-Powered-By");
  if (kind === "private" || kind === "ok") {
    headers.set("Cache-Control", "no-store");
  }
  if (kind === "image") {
    headers.set("Cache-Control", "public, max-age=3600");
  }
}

export function originAllowed(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try {
    const o = new URL(origin);
    const host = request.headers.get("host") ?? "";
    if (o.host === host) return true;
    const hn = o.hostname.toLowerCase();
    if (hn.endsWith(".grok.me") || hn === "grok.com" || hn.endsWith(".grok.com") || hn === "localhost") {
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

export function jsonResponse(data: unknown, status = 200, kind: "private" | "ok" = "private"): Response {
  const headers = new Headers({ "content-type": "application/json; charset=utf-8" });
  applySecurityHeaders(headers, kind);
  return new Response(JSON.stringify(data), { status, headers });
}

export function errorResponse(message: string, status: number): Response {
  return jsonResponse({ error: message }, status);
}

export function sanitizeError(err: unknown): string {
  if (err && typeof err === "object" && "name" in err && (err as { name: string }).name === "SsrfError") {
    return "URL is not allowed";
  }
  const msg = err instanceof Error ? err.message : "Request failed";
  if (/ssrf|private ip|link-local/i.test(msg)) return "URL is not allowed";
  if (/timeout/i.test(msg)) return "Upstream timed out";
  if (/unavailable/i.test(msg)) return "Media unavailable";
  if (/blocked/i.test(msg)) return msg;
  if (/invalid video|missing video/i.test(msg)) return "That video could not be found.";
  if (/query too long/i.test(msg)) return "Query too long";
  if (msg.length > 0 && msg.length < 90 && !/ECONN|ENOTFOUND|fetch failed|socket/i.test(msg)) return msg;
  return "Request failed";
}
