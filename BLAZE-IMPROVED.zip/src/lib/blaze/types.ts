export type SortMode =
  | "most-popular"
  | "latest"
  | "top-rated"
  | "longest"
  | "top-weekly"
  | "top-monthly";

export type Orientation = "straight" | "gay" | "trans";

export type TubeSource =
  | "pornhub"
  | "xvideos"
  | "xnxx"
  | "youporn"
  | "xhamster"
  | "eporner"
  | "redtube"
  | "redgifs"
  | "tnaflix"
  | "drtuber"
  | "nuvid"
  | "xozilla"
  | "pornhat"
  | "youjizz"
  | "hqporner"
  | "sunporno";

export type PlayMode = "native" | "embed";

export const SOURCE_PREFIX: Record<TubeSource, string> = {
  pornhub: "ph",
  xvideos: "xv",
  xnxx: "xn",
  youporn: "yp",
  xhamster: "xh",
  eporner: "ep",
  redtube: "rt",
  redgifs: "rg",
  tnaflix: "tf",
  drtuber: "dt",
  nuvid: "nv",
  xozilla: "xz",
  pornhat: "ha",
  youjizz: "yj",
  hqporner: "hq",
  sunporno: "su",
};

export const PREFIX_SOURCE: Record<string, TubeSource> = {
  ph: "pornhub",
  xv: "xvideos",
  xn: "xnxx",
  yp: "youporn",
  xh: "xhamster",
  ep: "eporner",
  rt: "redtube",
  rg: "redgifs",
  tf: "tnaflix",
  dt: "drtuber",
  nv: "nuvid",
  xz: "xozilla",
  ha: "pornhat",
  yj: "youjizz",
  hq: "hqporner",
  su: "sunporno",
};

export const SOURCE_META: Record<
  TubeSource,
  { label: string; short: string; color: string; playMode: PlayMode }
> = {
  pornhub: { label: "Pornhub", short: "PH", color: "text-accent", playMode: "native" },
  xvideos: { label: "XVideos", short: "XV", color: "text-fg", playMode: "native" },
  xnxx: { label: "XNXX", short: "XX", color: "text-fg", playMode: "native" },
  youporn: { label: "YouPorn", short: "YP", color: "text-fg", playMode: "native" },
  xhamster: { label: "xHamster", short: "XH", color: "text-fg", playMode: "embed" },
  eporner: { label: "Eporner", short: "EP", color: "text-fg", playMode: "native" },
  redtube: { label: "RedTube", short: "RT", color: "text-fg", playMode: "native" },
  redgifs: { label: "RedGifs", short: "RG", color: "text-fg", playMode: "native" },
  tnaflix: { label: "TNAFlix", short: "TF", color: "text-fg", playMode: "native" },
  drtuber: { label: "DrTuber", short: "DT", color: "text-fg", playMode: "embed" },
  nuvid: { label: "Nuvid", short: "NV", color: "text-fg", playMode: "embed" },
  xozilla: { label: "Xozilla", short: "XZ", color: "text-fg", playMode: "embed" },
  pornhat: { label: "PornHat", short: "HAT", color: "text-fg", playMode: "embed" },
  youjizz: { label: "YouJizz", short: "YJ", color: "text-fg", playMode: "embed" },
  hqporner: { label: "HQPorner", short: "HQP", color: "text-fg", playMode: "embed" },
  sunporno: { label: "SunPorno", short: "SUN", color: "text-fg", playMode: "embed" },
};

export const ALL_SOURCES: TubeSource[] = [
  "pornhub",
  "xvideos",
  "xnxx",
  "youjizz",
  "eporner",
  "redtube",
  "hqporner",
  "tnaflix",
  "youporn",
  "sunporno",
  "redgifs",
  "drtuber",
  "nuvid",
  "xozilla",
  "pornhat",
  "xhamster",
];

export const FAST_SOURCES: TubeSource[] = ["pornhub", "xvideos", "eporner", "youjizz", "tnaflix"];

export interface VideoCard {
  id: string;
  title: string;
  pageUrl: string;
  thumbnail: string | null;
  duration: number | null;
  views: number | null;
  rating: number | null;
  added: string | null;
  tags: string[];
  hd: boolean;
  source: TubeSource;
  playMode: PlayMode;
}

export interface SearchResponse {
  query: string;
  page: number;
  perPage: number;
  total: number;
  totalPages: number;
  results: VideoCard[];
  sources: TubeSource[];
}

export interface FeaturedRail {
  id: string;
  title: string;
  query: string;
  videos: VideoCard[];
}

export interface PlayableQuality {
  label: string;
  height: number;
  url: string;
}

export interface PlayableResponse {
  id: string;
  title: string;
  pageUrl: string;
  fileUrl: string;
  qualities: PlayableQuality[];
  tags: string[];
  views: number | null;
  duration: number | null;
  thumbnail: string | null;
  source: TubeSource;
  playMode: PlayMode;
  embedUrl: string | null;
}

export const SORT_LABELS: Record<SortMode, string> = {
  "most-popular": "Hottest",
  latest: "Newest",
  "top-rated": "Top rated",
  longest: "Longest",
  "top-weekly": "This week",
  "top-monthly": "This month",
};
