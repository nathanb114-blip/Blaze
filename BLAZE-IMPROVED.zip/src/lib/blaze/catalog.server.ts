import type { FeaturedRail, Orientation, SearchResponse, SortMode, TubeSource } from "./types.ts";
import { FAST_SOURCES } from "./types.ts";
import { HOME_RAILS, CATEGORIES } from "./categories.ts";
import { prohibitedErrorMessage, isProhibitedText } from "./policy.ts";
import { searchPartners } from "./partners.server.ts";

export async function searchCatalog(opts: {
  query: string;
  page?: number;
  sort?: SortMode;
  orientation?: Orientation;
  net?: TubeSource | "all";
  only?: TubeSource[];
}): Promise<SearchResponse> {
  return searchPartners(opts);
}

export async function featuredRails(
  orientation: Orientation = "straight",
  net: TubeSource | "all" = "all",
): Promise<FeaturedRail[]> {
  const rails = HOME_RAILS.slice(0, orientation === "straight" ? 4 : 2);
  const only = net === "all" ? FAST_SOURCES : [net];
  const settled = await Promise.allSettled(
    rails.map(async (rail) => {
      const res = await searchCatalog({
        query: rail.query,
        page: 1,
        sort: (rail.order as SortMode) ?? "most-popular",
        orientation,
        only,
      });
      return {
        id: rail.id,
        title: rail.title,
        query: rail.query,
        videos: res.results.slice(0, 14),
      } satisfies FeaturedRail;
    }),
  );
  return settled
    .filter((s): s is PromiseFulfilledResult<FeaturedRail> => s.status === "fulfilled")
    .map((s) => s.value)
    .filter((r) => r.videos.length > 0);
}

export async function suggestTitles(q: string): Promise<string[]> {
  const query = q.trim();
  if (query.length < 2 || isProhibitedText(query)) return [];
  const needle = query.toLowerCase();
  const out: string[] = [];
  const seen = new Set<string>();
  const push = (term: string) => {
    const t = term.trim();
    if (!t || t.length > 42) return;
    const key = t.toLowerCase();
    if (seen.has(key) || isProhibitedText(t)) return;
    seen.add(key);
    out.push(t);
  };
  for (const c of CATEGORIES) {
    if (c.label.toLowerCase().startsWith(needle) || c.query.startsWith(needle)) push(c.label);
  }
  for (const c of CATEGORIES) {
    if (out.length >= 8) break;
    if (c.label.toLowerCase().includes(needle) || c.query.includes(needle)) push(c.label);
  }
  if (out.length >= 8) return out.slice(0, 8);
  const res = await searchCatalog({
    query,
    page: 1,
    sort: "most-popular",
    only: FAST_SOURCES.slice(0, 3),
  });
  for (const v of res.results) {
    if (out.length >= 8) break;
    for (const tag of v.tags) {
      if (tag.length > 24) continue;
      if (tag.toLowerCase().includes(needle)) push(tag);
      if (out.length >= 8) break;
    }
  }
  return out.slice(0, 8);
}

export { prohibitedErrorMessage };
