import type { Orientation, SearchResponse, SortMode, TubeSource, VideoCard } from "./types.ts";
import { card, encodeId, getHtml, orientQuery, parseClock, parseRating, parseViews, thumb } from "./cards.server.ts";
import { decodeEntities } from "./html.ts";

export interface PartnerPage {
  source: TubeSource;
  results: VideoCard[];
  total: number;
  totalPages: number;
  trusted?: boolean;
}

function emptyPage(source: TubeSource): PartnerPage {
  return { source, results: [], total: 0, totalPages: 0 };
}

function takeBlocks(html: string, marker: string): string[] {
  const parts = html.split(marker);
  return parts.slice(1);
}

function xvSort(sort: SortMode): string | null {
  if (sort === "latest") return "uploaddate";
  if (sort === "top-rated") return "rating";
  if (sort === "longest") return "length";
  if (sort === "most-popular" || sort === "top-weekly" || sort === "top-monthly") return "views";
  return null;
}

function parseWgcz(html: string, source: "xvideos" | "xnxx", origin: string, perPage: number): VideoCard[] {
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  for (const block of takeBlocks(html, 'id="video_')) {
    const slice = block.slice(0, 3500);
    const href = slice.match(/href="(\/video[^"]+)"/)?.[1];
    const titleRaw =
      slice.match(/\stitle="([^"]+)"/)?.[1] ||
      slice.match(/<a href="\/video[^"]+"[^>]*>\s*([^<]{3,120})/)?.[1] ||
      "";
    const title = decodeEntities(titleRaw).replace(/\s+\d+\s*min\s*$/i, "").trim();
    const thumbUrl = slice.match(/data-src="(https:[^"]+)"/)?.[1];
    const numeric = slice.match(/data-videoid="(\d+)"/)?.[1];
    const eid = slice.match(/data-eid="([^"]+)"/)?.[1] || slice.match(/^([^"]+)"/)?.[1];
    const hrefHex = href?.match(/^\/video\.([A-Za-z0-9]+)/)?.[1];
    const hrefXn = href?.match(/^\/video-([A-Za-z0-9]+)/)?.[1];
    const raw = source === "xvideos" ? hrefHex || numeric : hrefXn || eid || numeric;
    if (!raw || !href || !title || seen.has(raw)) continue;
    seen.add(raw);
    const durText =
      slice.match(/class="duration">([^<]+)</)?.[1] ||
      slice.match(/>(\d+\s*min)</i)?.[1] ||
      slice.match(/>(\d+min)</i)?.[1] ||
      slice.match(/(\d+)\s*min/i)?.[0] ||
      "";
    const viewsText =
      slice.match(/([\d.,]+[kmbKMB]?)\s*<span class="icon-f icf-eye"/)?.[1] ||
      slice.match(/([\d.,]+[kmbKMB]?)\s*Views/i)?.[1] ||
      "";
    const hd = /1080p|720p|video-hd|HD\b/.test(slice);
    const mapped = card({
      id: encodeId(source, raw),
      title,
      pageUrl: new URL(href, origin).href,
      thumbnail: thumb(thumbUrl, origin),
      duration: parseClock(durText.replace(/\s+/g, " ").trim()) ?? parseClock(durText.replace(/min/i, " min")),
      views: parseViews(viewsText.replace(/,/g, "")),
      rating: null,
      added: null,
      tags: [],
      source,
      hd,
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return results;
}

export async function searchXvideos(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const url = new URL("https://www.xvideos.com/");
  url.searchParams.set("k", q === "all" ? "sex" : q);
  url.searchParams.set("p", String(Math.max(0, page - 1)));
  const s = xvSort(sort);
  if (s) url.searchParams.set("sort", s);
  const html = await getHtml(url.toString());
  const results = parseWgcz(html, "xvideos", "https://www.xvideos.com/", perPage);
  const totalHint = html.match(/([\d,]+)\s*results/i);
  const total = totalHint ? Number(totalHint[1]!.replace(/,/g, "")) : page * perPage + (results.length >= perPage ? 400 : 0);
  return {
    source: "xvideos",
    results,
    total: Number.isFinite(total) && total > 0 ? total : results.length,
    totalPages: Math.max(1, Math.ceil((Number.isFinite(total) && total > 0 ? total : 800) / 27)),
  };
}

export async function searchXnxx(
  query: string,
  page: number,
  _sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const term = encodeURIComponent((q === "all" ? "hot" : q).replace(/\s+/g, " "));
  const pageBit = page > 1 ? `/${page - 1}` : "";
  const url = `https://www.xnxx.com/search/${term}${pageBit}`;
  const html = await getHtml(url);
  const results = parseWgcz(html, "xnxx", "https://www.xnxx.com/", perPage);
  const totalHint = html.match(/([\d,]+)\s*results/i);
  const total = totalHint ? Number(totalHint[1]!.replace(/,/g, "")) : results.length;
  return {
    source: "xnxx",
    results,
    total: Number.isFinite(total) ? total : results.length,
    totalPages: Math.max(1, Math.ceil((Number.isFinite(total) && total > 0 ? total : 800) / 36)),
  };
}

export async function searchYouporn(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const url = new URL("https://www.youporn.com/search/");
  url.searchParams.set("query", q === "all" ? "hot" : q);
  url.searchParams.set("page", String(page));
  if (sort === "latest") url.searchParams.set("o", "mr");
  else if (sort === "top-rated") url.searchParams.set("o", "tr");
  else if (sort === "longest") url.searchParams.set("o", "lg");
  else url.searchParams.set("o", "mv");
  const html = await getHtml(url.toString());
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const re = /data-video-id="(\d+)"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const id = m[1]!;
    if (seen.has(id)) continue;
    seen.add(id);
    const around = aroundSlice(html, m.index, 240, 2800);
    const title = decodeEntities(
      around.match(/aria-label="([^"]+)"/)?.[1] ||
        around.match(/alt="([^"]+)"/)?.[1] ||
        around.match(/class="[^"]*video-title[^"]*"[^>]*>[\s\S]{0,80}>([^<]{3,160})</)?.[1] ||
        "",
    ).trim();
    const href =
      around.match(/href="(https?:\/\/www\.youporn\.com\/watch\/[^"]+)"/)?.[1] ||
      around.match(/href="(\/watch\/[^"]+)"/)?.[1] ||
      around.match(/href='(\/watch\/[^']+)'/)?.[1];
    const thumbUrl =
      around.match(/data-(?:mediumthumb|poster|src)="(https:[^"]+)"/)?.[1] ||
      around.match(/src="(https:\/\/(?:ei|fi\d+|cdn)\.ypncdn\.com\/[^"]+\.(?:jpg|jpeg|webp)[^"]*)"/i)?.[1];
    const mapped = card({
      id: encodeId("youporn", id),
      title,
      pageUrl: href
        ? href.startsWith("http")
          ? href
          : `https://www.youporn.com${href}`
        : `https://www.youporn.com/watch/${id}/`,
      thumbnail: thumb(thumbUrl ? decodeEntities(thumbUrl) : null, "https://www.youporn.com/"),
      duration: parseClock(around.match(/(\d{1,2}:\d{2}(?::\d{2})?)/)?.[1]),
      views: parseViews(around.match(/([\d.,]+[kmbKMB]?)\s*views/i)?.[1]),
      rating: null,
      added: null,
      tags: [],
      source: "youporn",
      hd: /HD|1080|720/i.test(around),
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return {
    source: "youporn",
    results,
    total: results.length >= perPage ? page * perPage + 400 : (page - 1) * perPage + results.length,
    totalPages: Math.max(20, page + (results.length >= perPage ? 8 : 0)),
  };
}

export async function searchXhamster(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const term = encodeURIComponent(q === "all" ? "amateur" : q);
  let path = `https://xhamster.com/search/${term}`;
  if (sort === "latest") path += "?sort=newest";
  else if (sort === "top-rated") path += "?sort=best";
  else if (sort === "longest") path += "?sort=longest";
  else path += "?sort=views";
  if (page > 1) path += `${path.includes("?") ? "&" : "?"}page=${page}`;
  let html: string;
  try {
    html = await getHtml(path);
  } catch {
    return emptyPage("xhamster");
  }
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const linkRe = /href="(?:https:\/\/(?:[a-z]+\.)?xhamster\.com)?\/videos\/([a-z0-9-]+-)?(\d+)"/gi;
  let m: RegExpExecArray | null;
  while ((m = linkRe.exec(html))) {
    const id = m[2]!;
    if (seen.has(id)) continue;
    seen.add(id);
    const around = html.slice(Math.max(0, m.index - 400), m.index + 900);
    const title =
      decodeEntities(
        around.match(/alt="([^"]+)"/)?.[1] ||
          around.match(/title="([^"]+)"/)?.[1] ||
          (m[1] ? m[1].replace(/-$/, "").replace(/-/g, " ") : ""),
      ).trim() || `xHamster ${id}`;
    const thumbUrl =
      around.match(/(https:\/\/[^"'\s]+(?:xhcdn|xhamster)[^"'\s]+\.(?:jpg|jpeg|webp))/i)?.[1] ||
      around.match(/src="(https:[^"]+\.(?:jpg|jpeg|webp)[^"]*)"/i)?.[1];
    const dur = around.match(/(\d{1,2}:\d{2}(?::\d{2})?)/)?.[1];
    const mapped = card({
      id: encodeId("xhamster", id),
      title,
      pageUrl: `https://xhamster.com/videos/${m[1] ?? ""}${id}`,
      thumbnail: thumb(thumbUrl ?? null, "https://xhamster.com/"),
      duration: parseClock(dur),
      views: null,
      rating: null,
      added: null,
      tags: [],
      source: "xhamster",
      hd: /HD|4K|1080/i.test(around),
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return {
    source: "xhamster",
    results,
    total: results.length >= perPage ? page * perPage + 400 : results.length,
    totalPages: results.length >= perPage ? page + 8 : page,
  };
}

export type ListingSearch = (
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
) => Promise<PartnerPage>;

function kvsFolder(id: string): string {
  const n = Number(id);
  if (!Number.isFinite(n)) return id;
  return String(Math.floor(n / 1000) * 1000);
}

function aroundSlice(html: string, index: number, before = 200, after = 1600): string {
  return html.slice(Math.max(0, index - before), index + after);
}

function firstHttpImage(slice: string): string | null {
  return (
    slice.match(/data-original="(https:[^"]+)"/)?.[1] ||
    slice.match(/data-src="(https:[^"]+\.(?:jpg|jpeg|webp)[^"]*)"/i)?.[1] ||
    slice.match(/src="(https:[^"]+\.(?:jpg|jpeg|webp)[^"]*)"/i)?.[1] ||
    null
  );
}

export async function searchTnaflix(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const url = new URL("https://www.tnaflix.com/search");
  url.searchParams.set("what", q === "all" ? "hot" : q);
  if (page > 1) url.searchParams.set("page", String(page));
  if (sort === "latest") url.searchParams.set("sort", "date");
  else if (sort === "top-rated") url.searchParams.set("sort", "rating");
  else if (sort === "longest") url.searchParams.set("sort", "duration");
  const html = await getHtml(url.toString());
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const re = /data-vid="(\d+)"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const id = m[1]!;
    if (seen.has(id)) continue;
    seen.add(id);
    const around = html.slice(m.index, m.index + 2200);
    const href =
      around.match(/href="(https:\/\/www\.tnaflix\.com\/[^"]+\/video\d+)"/)?.[1] ||
      `https://www.tnaflix.com/video${id}`;
    const title = decodeEntities(
      around.match(/alt="([^"]+)"/)?.[1] || around.match(/title="([^"]+)"/)?.[1] || "",
    ).trim();
    const mapped = card({
      id: encodeId("tnaflix", id),
      title,
      pageUrl: href,
      thumbnail: thumb(firstHttpImage(around), "https://www.tnaflix.com/"),
      duration: parseClock(around.match(/video-duration">([^<]+)/)?.[1]),
      views: parseViews(around.match(/([\d.,]+[kmbKMB]?)\s*views/i)?.[1]),
      rating: null,
      added: null,
      tags: [],
      source: "tnaflix",
      hd: /720p|1080p|4K|HD/i.test(around),
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return {
    source: "tnaflix",
    results,
    total: results.length >= perPage ? page * perPage + 800 : (page - 1) * perPage + results.length,
    totalPages: results.length >= perPage ? page + 20 : page,
  };
}

export async function searchDrtuber(
  query: string,
  page: number,
  _sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const term = encodeURIComponent((q === "all" ? "hot" : q).replace(/\s+/g, " "));
  const url = `https://www.drtuber.com/search/videos/${term}${page > 1 ? `/${page}` : ""}`;
  const html = await getHtml(url);
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const re = /href="\/video\/(\d+)\/([^"]+)"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const id = m[1]!;
    if (seen.has(id)) continue;
    seen.add(id);
    const around = aroundSlice(html, m.index, 80, 1400);
    const title = decodeEntities(
      around.match(/alt="([^"]+)"/)?.[1] || around.match(/<span>\s*<em>([^<]+)/)?.[1] || m[2]!.replace(/-/g, " "),
    ).trim();
    const mapped = card({
      id: encodeId("drtuber", id),
      title,
      pageUrl: `https://www.drtuber.com/video/${id}/${m[2]}`,
      thumbnail: thumb(firstHttpImage(around), "https://www.drtuber.com/"),
      duration: parseClock(around.match(/time_thumb[^>]*>\s*<em>([^<]+)/)?.[1] || around.match(/>(\d{1,2}:\d{2}(?::\d{2})?)</)?.[1]),
      views: parseViews(around.match(/([\d.,]+[kmbKMB]?)\s*views/i)?.[1]),
      rating: parseViews(around.match(/ico_rate_like[\s\S]{0,40}<em>(\d+)%/)?.[1]) ? Number(around.match(/<em>(\d+)%/)?.[1]) : null,
      added: null,
      tags: [],
      source: "drtuber",
      hd: /HD|720|1080/i.test(around),
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return {
    source: "drtuber",
    results,
    total: results.length >= perPage ? page * perPage + 600 : (page - 1) * perPage + results.length,
    totalPages: results.length >= perPage ? page + 16 : page,
  };
}

export async function searchNuvid(
  query: string,
  page: number,
  _sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const term = encodeURIComponent((q === "all" ? "hot" : q).replace(/\s+/g, " "));
  const url = `https://www.nuvid.com/search/videos/${term}${page > 1 ? `/${page}` : ""}`;
  const html = await getHtml(url);
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const re = /href="\/video\/(\d+)\/([^"]+)"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const id = m[1]!;
    if (seen.has(id)) continue;
    seen.add(id);
    const around = aroundSlice(html, m.index, 40, 1400);
    const title = decodeEntities(
      around.match(/title="([^"]+)"/)?.[1] || around.match(/alt="([^"]+)"/)?.[1] || m[2]!.replace(/-/g, " "),
    ).trim();
    const mapped = card({
      id: encodeId("nuvid", id),
      title,
      pageUrl: `https://www.nuvid.com/video/${id}/${m[2]}`,
      thumbnail: thumb(firstHttpImage(around), "https://www.nuvid.com/"),
      duration: parseClock(around.match(/time_thumb[^>]*>\s*(?:<em>)?([^<]+)/)?.[1] || around.match(/>(\d{1,2}:\d{2}(?::\d{2})?)</)?.[1]),
      views: parseViews(around.match(/([\d.,]+[kmbKMB]?)\s*views/i)?.[1]),
      rating: null,
      added: null,
      tags: [],
      source: "nuvid",
      hd: /HD|720|1080/i.test(around),
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return {
    source: "nuvid",
    results,
    total: results.length >= perPage ? page * perPage + 600 : (page - 1) * perPage + results.length,
    totalPages: results.length >= perPage ? page + 16 : page,
  };
}

export async function searchXozilla(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const term = encodeURIComponent((q === "all" ? "amateur" : q).replace(/\s+/g, "-"));
  let path = `https://www.xozilla.com/search/${term}/`;
  if (page > 1) path = `https://www.xozilla.com/search/${term}/${page}/`;
  if (sort === "latest") path += "?sort_by=post_date";
  else if (sort === "top-rated") path += "?sort_by=rating";
  else if (sort === "longest") path += "?sort_by=duration";
  const html = await getHtml(path);
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const re = /href="https:\/\/www\.xozilla\.com\/videos\/(\d+)\/([^"/]+)\/?"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const id = m[1]!;
    if (seen.has(id)) continue;
    seen.add(id);
    const around = aroundSlice(html, m.index, 40, 1800);
    const title = decodeEntities(
      around.match(/alt="([^"]+)"/)?.[1] || m[2]!.replace(/-/g, " "),
    ).trim();
    const img =
      firstHttpImage(around) ||
      `https://i.xozilla.com/contents/videos_screenshots/${kvsFolder(id)}/${id}/300x169/1.jpg`;
    const mapped = card({
      id: encodeId("xozilla", id),
      title,
      pageUrl: `https://www.xozilla.com/videos/${id}/${m[2]}/`,
      thumbnail: thumb(img, "https://www.xozilla.com/"),
      duration: parseClock(
        around.match(/>(\d+m:\d+s)</)?.[1] ||
          around.match(/class="duration[^"]*">([^<]+)/)?.[1] ||
          around.match(/(\d{1,2}:\d{2}(?::\d{2})?)/)?.[1],
      ),
      views: parseViews(around.match(/([\d.,]+[kmbKMB]?)\s*(?:views|VIEWS)/i)?.[1]),
      rating: null,
      added: null,
      tags: [],
      source: "xozilla",
      hd: /HD|720|1080|4k/i.test(around),
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return {
    source: "xozilla",
    results,
    total: results.length >= perPage ? page * perPage + 800 : (page - 1) * perPage + results.length,
    totalPages: results.length >= perPage ? page + 20 : page,
  };
}

export async function searchPornhat(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const term = encodeURIComponent((q === "all" ? "amateur" : q).replace(/\s+/g, "-"));
  let path = `https://www.pornhat.com/search/${term}/`;
  if (page > 1) path = `https://www.pornhat.com/search/${term}/${page}/`;
  if (sort === "latest") path += "?sort_by=post_date";
  else if (sort === "top-rated") path += "?sort_by=rating";
  else if (sort === "longest") path += "?sort_by=duration";
  const html = await getHtml(path);
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const re = /href="(\/video\/([a-z0-9-]+)\/)"/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const slug = m[2]!;
    if (seen.has(slug)) continue;
    seen.add(slug);
    const around = aroundSlice(html, m.index, 80, 1800);
    const numeric =
      around.match(/videos_screenshots\/\d+\/(\d+)/)?.[1] ||
      around.match(/\/(\d{5,8})\/\1/)?.[1] ||
      around.match(/(\d{5,8})_preview/)?.[1];
    const raw = numeric || slug;
    if (seen.has(raw) && numeric) continue;
    if (numeric) seen.add(numeric);
    const title = decodeEntities(
      around.match(/title="([^"]+)"/)?.[1] || around.match(/alt="([^"]+)"/)?.[1] || slug.replace(/-/g, " "),
    ).trim();
    const img =
      firstHttpImage(around) ||
      (numeric
        ? `https://www.pornhat.com/contents/videos_screenshots/${kvsFolder(numeric)}/${numeric}/300x168/1.jpg`
        : null);
    const mapped = card({
      id: encodeId("pornhat", raw),
      title,
      pageUrl: `https://www.pornhat.com/video/${slug}/`,
      thumbnail: thumb(img, "https://www.pornhat.com/"),
      duration: parseClock(around.match(/(\d{1,2}:\d{2}(?::\d{2})?)/)?.[1]),
      views: parseViews(around.match(/([\d.,]+[kmbKMB]?)\s*views/i)?.[1]),
      rating: null,
      added: null,
      tags: [],
      source: "pornhat",
      hd: /HD|720|1080|4k/i.test(around),
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return {
    source: "pornhat",
    results,
    total: results.length >= perPage ? page * perPage + 800 : (page - 1) * perPage + results.length,
    totalPages: results.length >= perPage ? page + 20 : page,
  };
}

export async function searchYoujizz(
  query: string,
  page: number,
  _sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  const slug = encodeURIComponent((q === "all" ? "hot" : q).trim().replace(/\s+/g, "-"));
  const url = `https://www.youjizz.com/search/${slug}-${page}.html`;
  const html = await getHtml(url);
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const re = /data-video-id="(\d+)"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const id = m[1]!;
    if (seen.has(id)) continue;
    seen.add(id);
    const around = aroundSlice(html, m.index, 40, 2200);
    const href = around.match(/href=['"](\/videos\/[^'"]+)['"]/)?.[1];
    const title = decodeEntities(
      around.match(/class="[^"]*video-title[^"]*"[\s\S]{0,120}>([^<]{3,160})</)?.[1] ||
        around.match(/alt="([^"]+)"/)?.[1] ||
        (href ? href.replace(/^\/videos\//, "").replace(/-\d+\.html$/, "").replace(/[-_]+/g, " ") : ""),
    ).trim();
    const img = around.match(/data-original="(\/\/[^"]+)"/)?.[1] || around.match(/data-original="(https:[^"]+)"/)?.[1];
    const mapped = card({
      id: encodeId("youjizz", id),
      title,
      pageUrl: href ? `https://www.youjizz.com${href}` : `https://www.youjizz.com/videos/${id}.html`,
      thumbnail: thumb(img, "https://www.youjizz.com/"),
      duration: parseClock(around.match(/class="time"[^>]*>[\s\S]{0,80}?(\d{1,2}:\d{2}(?::\d{2})?)/)?.[1]),
      views: parseViews(around.match(/format-views">([\d.,]+)/)?.[1]),
      rating: parseRating(around.match(/data-value="([\d.]+)"/)?.[1]),
      added: null,
      tags: [],
      source: "youjizz",
      hd: /i-hd|HD|1080|720/i.test(around),
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return {
    source: "youjizz",
    results,
    total: results.length >= perPage ? page * perPage + 800 : (page - 1) * perPage + results.length,
    totalPages: results.length >= perPage ? page + 24 : page,
  };
}

const HQ_CATEGORY_SLUG: Record<string, string> = {
  milf: "milf",
  amateur: "amateur",
  anal: "anal",
  asian: "asian",
  lesbian: "lesbian",
  blonde: "blonde",
  brunette: "brunette",
  redhead: "redhead",
  ebony: "ebony",
  latina: "latina",
  teen: "teen",
  mature: "mature",
  pov: "pov",
  public: "public",
  outdoor: "outdoor",
  creampie: "creampie",
  cumshot: "cumshot",
  blowjob: "blowjob",
  threesome: "threesome",
  gangbang: "gangbang",
  interracial: "interracial",
  massage: "massage",
  "big tits": "big-tits",
  "big ass": "big-ass",
  squirt: "squirting",
  japanese: "japanese",
  homemade: "homemade",
  casting: "casting",
  russian: "russian",
  german: "german",
  french: "french",
  indian: "indian",
  arab: "arab",
  bondage: "bondage",
  fetish: "fetish",
  hentai: "hentai",
  compilation: "compilation",
};

export async function searchHqporner(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  let trusted = false;
  let urls: string[] = [];
  if (q === "all") {
    const top = sort === "latest" ? "https://hqporner.com/" : "https://hqporner.com/top";
    urls = [page > 1 ? `${top}/${page}` : top];
  } else {
    const slug = HQ_CATEGORY_SLUG[q.toLowerCase()] ?? q.replace(/\s+/g, "-");
    trusted = true;
    urls = [
      page > 1 ? `https://hqporner.com/category/${slug}/${page}` : `https://hqporner.com/category/${slug}`,
      `https://hqporner.com/?q=${encodeURIComponent(q)}`,
    ];
  }
  let usedFallback = false;
  for (let i = 0; i < urls.length; i++) {
    try {
      const html = await getHtml(urls[i]!);
      const results = parseHqporner(html, perPage);
      if (results.length === 0) continue;
      if (i > 0) usedFallback = true;
      return {
        source: "hqporner",
        results,
        total: results.length >= perPage ? page * perPage + 600 : (page - 1) * perPage + results.length,
        totalPages: results.length >= perPage ? page + 16 : page,
        trusted: trusted && !usedFallback,
      };
    } catch {
      continue;
    }
  }
  return emptyPage("hqporner");
}

function parseHqporner(html: string, perPage: number): VideoCard[] {
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const re = /href="\/hdporn\/(\d+)-([^"]+)\.html"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const id = m[1]!;
    const slug = m[2]!;
    const raw = `${id}-${slug}`;
    if (seen.has(id)) continue;
    seen.add(id);
    const around = aroundSlice(html, m.index, 80, 1600);
    const title = decodeEntities(
      around.match(/alt="([^"]+)"/)?.[1] || around.match(/<h3>\s*<a[^>]*>([^<]+)/)?.[1] || slug.replace(/_/g, " "),
    )
      .replace(/\b[a-z]/g, (c) => c.toUpperCase())
      .trim();
    const img =
      around.match(/src="(\/\/fastporndelivery\.hqporner\.com\/[^"]+)"/)?.[1] ||
      around.match(/defaultImage\("(\/\/[^"]+)"/)?.[1] ||
      firstHttpImage(around);
    const mapped = card({
      id: encodeId("hqporner", raw),
      title,
      pageUrl: `https://hqporner.com/hdporn/${raw}.html`,
      thumbnail: thumb(img, "https://hqporner.com/"),
      duration: parseClock(around.match(/(\d{1,2}:\d{2}(?::\d{2})?)/)?.[1]),
      views: null,
      rating: null,
      added: null,
      tags: [],
      source: "hqporner",
      hd: true,
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return results;
}

export async function searchSunporno(
  query: string,
  page: number,
  sort: SortMode,
  orientation: Orientation,
  perPage: number,
): Promise<PartnerPage> {
  const q = orientQuery(query, orientation);
  let url: string;
  if (q === "all") {
    if (sort === "longest") {
      url = page > 1 ? `https://www.sunporno.com/search/hot/${page}/?sort_by=duration` : "https://www.sunporno.com/search/hot/?sort_by=duration";
    } else if (sort === "latest") {
      url = page > 1 ? `https://www.sunporno.com/latest/${page}/` : "https://www.sunporno.com/latest/";
    } else {
      url = page > 1 ? `https://www.sunporno.com/${page}/` : "https://www.sunporno.com/";
    }
  } else {
    const term = encodeURIComponent(q.replace(/\s+/g, "-"));
    url = page > 1 ? `https://www.sunporno.com/search/${term}/${page}/` : `https://www.sunporno.com/search/${term}/`;
    if (sort === "longest") url += "?sort_by=duration";
    else if (sort === "latest") url += "?sort_by=post_date";
    else if (sort === "top-rated") url += "?sort_by=rating";
  }
  const html = await getHtml(url);
  const results: VideoCard[] = [];
  const seen = new Set<string>();
  const re = /href="https:\/\/www\.sunporno\.com\/v\/(\d+)\/([^"/]+)\/?"/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const id = m[1]!;
    if (seen.has(id)) continue;
    seen.add(id);
    const around = aroundSlice(html, m.index, 80, 1800);
    const title = decodeEntities(
      around.match(/title="([^"]+)"/)?.[1] || around.match(/alt="([^"]+)"/)?.[1] || m[2]!.replace(/-/g, " "),
    )
      .replace(/^Porn Videos/i, "")
      .trim();
    const img =
      around.match(/src="(https:\/\/[^"]+videos_screenshots[^"]+)"/)?.[1] || firstHttpImage(around);
    const mapped = card({
      id: encodeId("sunporno", id),
      title,
      pageUrl: `https://www.sunporno.com/v/${id}/${m[2]}/`,
      thumbnail: thumb(img, "https://www.sunporno.com/"),
      duration: parseClock(around.match(/(\d{1,2}:\d{2}(?::\d{2})?)/)?.[1]),
      views: parseViews(around.match(/([\d.,]+[kmbKMB]?)\s*views/i)?.[1]),
      rating: null,
      added: null,
      tags: [],
      source: "sunporno",
      hd: /HD|720|1080|4k/i.test(around),
    });
    if (mapped) results.push(mapped);
    if (results.length >= perPage) break;
  }
  return {
    source: "sunporno",
    results,
    total: results.length >= perPage ? page * perPage + 800 : (page - 1) * perPage + results.length,
    totalPages: results.length >= perPage ? page + 20 : page,
  };
}

export const LISTING_SEARCH: Record<
  | "xvideos"
  | "xnxx"
  | "youporn"
  | "xhamster"
  | "tnaflix"
  | "drtuber"
  | "nuvid"
  | "xozilla"
  | "pornhat"
  | "youjizz"
  | "hqporner"
  | "sunporno",
  ListingSearch
> = {
  xvideos: searchXvideos,
  xnxx: searchXnxx,
  youporn: searchYouporn,
  xhamster: searchXhamster,
  tnaflix: searchTnaflix,
  drtuber: searchDrtuber,
  nuvid: searchNuvid,
  xozilla: searchXozilla,
  pornhat: searchPornhat,
  youjizz: searchYoujizz,
  hqporner: searchHqporner,
  sunporno: searchSunporno,
};

export type { SearchResponse };

