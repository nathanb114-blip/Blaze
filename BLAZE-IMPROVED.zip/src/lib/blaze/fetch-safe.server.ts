import http from "node:http";
import https from "node:https";
import { lookup as dnsLookup } from "node:dns/promises";
import { Readable } from "node:stream";
import { assertPublicHttpUrl, isBlockedIp, SsrfError } from "./ssrf.ts";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const MAX_REDIRECTS = 5;
const DEFAULT_TIMEOUT = 8000;
const MAX_BUFFER = 2_500_000;

export interface SafeResponse {
  status: number;
  headers: http.IncomingHttpHeaders;
  url: string;
  body: Buffer;
}

function header(headers: http.IncomingHttpHeaders, name: string): string | undefined {
  const v = headers[name.toLowerCase()];
  if (Array.isArray(v)) return v[0];
  return v;
}

async function resolvePublic(hostname: string): Promise<{ address: string; family: number }> {
  const records = await dnsLookup(hostname, { all: true, verbatim: true });
  if (!records.length) throw new SsrfError("DNS lookup failed");
  for (const rec of records) {
    if (isBlockedIp(rec.address)) throw new SsrfError("Resolved address is not public");
  }
  const first = records[0]!;
  return { address: first.address, family: first.family };
}

function requestOnce(
  url: URL,
  pinned: { address: string; family: number },
  opts: {
    method?: string;
    headers?: Record<string, string>;
    timeout?: number;
  },
): Promise<{ status: number; headers: http.IncomingHttpHeaders; stream: http.IncomingMessage }> {
  const lib = url.protocol === "https:" ? https : http;
  const timeout = opts.timeout ?? DEFAULT_TIMEOUT;
  const headers: Record<string, string> = {
    Host: url.hostname,
    "User-Agent": UA,
    Accept: "*/*",
    "Accept-Language": "en-US,en;q=0.9",
    Connection: "close",
    ...opts.headers,
  };
  return new Promise((resolve, reject) => {
    const req = lib.request(
      {
        protocol: url.protocol,
        hostname: pinned.address,
        family: pinned.family,
        port: url.port ? Number(url.port) : url.protocol === "https:" ? 443 : 80,
        path: `${url.pathname}${url.search}`,
        method: opts.method ?? "GET",
        headers,
        setHost: false,
        servername: url.hostname,
        timeout,
      },
      (res) => {
        resolve({ status: res.statusCode ?? 0, headers: res.headers, stream: res });
      },
    );
    req.on("timeout", () => {
      req.destroy(new Error("timeout"));
    });
    req.on("error", reject);
    req.end();
  });
}

async function follow(
  raw: string,
  opts: {
    method?: string;
    headers?: Record<string, string>;
    timeout?: number;
    maxBytes?: number;
    redirects?: number;
  } = {},
): Promise<{ status: number; headers: http.IncomingHttpHeaders; stream: http.IncomingMessage; url: string }> {
  let current = assertPublicHttpUrl(raw);
  for (let hop = 0; hop <= (opts.redirects ?? MAX_REDIRECTS); hop++) {
    const pinned = await resolvePublic(current.hostname);
    const res = await requestOnce(current, pinned, opts);
    if (res.status >= 300 && res.status < 400) {
      res.stream.resume();
      const loc = header(res.headers, "location");
      if (!loc) throw new SsrfError("Redirect without Location");
      const next = new URL(loc, current);
      if (next.protocol !== "http:" && next.protocol !== "https:") {
        throw new SsrfError("Redirect to unsupported scheme");
      }
      current = assertPublicHttpUrl(next.href);
      continue;
    }
    return { ...res, url: current.href };
  }
  throw new SsrfError("Too many redirects");
}

async function readLimited(stream: Readable, maxBytes: number, truncate = false): Promise<Buffer> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of stream) {
    const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    size += buf.length;
    if (size > maxBytes) {
      const allowed = buf.length - (size - maxBytes);
      if (allowed > 0) chunks.push(buf.subarray(0, allowed));
      stream.destroy();
      if (truncate) return Buffer.concat(chunks);
      throw new Error("Response too large");
    }
    chunks.push(buf);
  }
  return Buffer.concat(chunks);
}

export async function safeFetchBuffer(
  url: string,
  opts: {
    timeout?: number;
    maxBytes?: number;
    headers?: Record<string, string>;
    method?: string;
    truncate?: boolean;
  } = {},
): Promise<SafeResponse> {
  const res = await follow(url, opts);
  const body = await readLimited(res.stream, opts.maxBytes ?? MAX_BUFFER, opts.truncate === true);
  return { status: res.status, headers: res.headers, url: res.url, body };
}

export async function safeFetchText(
  url: string,
  opts: { timeout?: number; maxBytes?: number; headers?: Record<string, string> } = {},
): Promise<{ status: number; url: string; text: string }> {
  const res = await safeFetchBuffer(url, opts);
  return { status: res.status, url: res.url, text: res.body.toString("utf8") };
}

export async function safeFetchStream(
  url: string,
  opts: { timeout?: number; headers?: Record<string, string>; method?: string } = {},
): Promise<{ status: number; headers: http.IncomingHttpHeaders; stream: http.IncomingMessage; url: string }> {
  return follow(url, { ...opts, redirects: MAX_REDIRECTS });
}

export function nodeStreamToWeb(stream: Readable): ReadableStream<Uint8Array> {
  return Readable.toWeb(stream) as ReadableStream<Uint8Array>;
}

export { UA as BROWSER_UA };
