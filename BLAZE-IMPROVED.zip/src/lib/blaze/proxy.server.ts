import { classifyBytes, isBrowserMedia, isImageKind, kindFromContentType } from "./classify.ts";
import { safeFetchBuffer, safeFetchStream, nodeStreamToWeb, BROWSER_UA } from "./fetch-safe.server.ts";
import { rewriteHlsManifest, isHlsManifest } from "./hls.ts";
import { verifyProxyRequest, signProxyUrl } from "./proxy-sign.server.ts";
import { applySecurityHeaders, errorResponse } from "./security.server.ts";
import { assertPublicHttpUrl } from "./ssrf.ts";

const IMAGE_MAX = 8 * 1024 * 1024;
const MANIFEST_MAX = 2_000_000;

function header(headers: Record<string, string | string[] | undefined>, name: string): string | undefined {
  const v = headers[name.toLowerCase()];
  if (Array.isArray(v)) return v[0];
  return v;
}

export async function handleImageProxy(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const u = url.searchParams.get("u") ?? "";
  const r = url.searchParams.get("r") ?? "";
  const e = url.searchParams.get("e") ?? "";
  const s = url.searchParams.get("s") ?? "";
  let target: { url: string; referer: string };
  try {
    target = verifyProxyRequest("image", u, r, e, s);
  } catch (err) {
    const status =
      err && typeof err === "object" && "status" in err ? Number((err as { status: number }).status) : 403;
    return errorResponse("Invalid or expired signature", status || 403);
  }

  const res = await safeFetchBuffer(target.url, {
    timeout: 4500,
    maxBytes: IMAGE_MAX,
    headers: {
      Referer: target.referer || new URL(target.url).origin + "/",
      Accept: "image/avif,image/webp,image/*,*/*;q=0.8",
    },
  });
  if (res.status >= 400) return errorResponse("Image unavailable", 502);
  const kind = classifyBytes(res.body);
  const ctKind = kindFromContentType(header(res.headers, "content-type"));
  if (!isImageKind(kind) && ctKind !== "image") {
    return errorResponse("Not an image", 415);
  }
  const contentType = header(res.headers, "content-type")?.split(";")[0] ?? "image/jpeg";
  const headers = new Headers({
    "content-type": contentType.startsWith("image/") ? contentType : "image/jpeg",
    "content-length": String(res.body.length),
  });
  applySecurityHeaders(headers, "image");
  return new Response(new Uint8Array(res.body), { status: 200, headers });
}

export async function handleStreamProxy(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const u = url.searchParams.get("u") ?? "";
  const r = url.searchParams.get("r") ?? "";
  const e = url.searchParams.get("e") ?? "";
  const s = url.searchParams.get("s") ?? "";
  let target: { url: string; referer: string };
  try {
    target = verifyProxyRequest("stream", u, r, e, s);
  } catch {
    return errorResponse("Invalid or expired signature", 403);
  }

  const referer = target.referer || new URL(target.url).origin + "/";
  const range = request.headers.get("range");
  const looksHls = /\.m3u8(\?|$)/i.test(target.url);

  if (looksHls) {
    const res = await safeFetchBuffer(target.url, {
      timeout: 7000,
      maxBytes: MANIFEST_MAX,
      headers: { Referer: referer, Accept: "application/vnd.apple.mpegurl,application/x-mpegURL,*/*" },
    });
    if (res.status >= 400) return errorResponse("Stream unavailable", 502);
    const text = res.body.toString("utf8");
    if (!isHlsManifest(text)) {
      const kind = classifyBytes(res.body);
      if (!isBrowserMedia(kind)) return errorResponse("Unsupported media", 415);
    }
    const rewritten = rewriteHlsManifest(text, target.url, (abs) => {
      assertPublicHttpUrl(abs);
      return signProxyUrl("stream", abs, referer);
    });
    const headers = new Headers({
      "content-type": "application/vnd.apple.mpegurl",
      "content-length": String(Buffer.byteLength(rewritten)),
    });
    applySecurityHeaders(headers, "stream");
    headers.set("Cache-Control", "private, max-age=30");
    return new Response(rewritten, { status: 200, headers });
  }

  const upstreamHeaders: Record<string, string> = {
    Referer: referer,
    Origin: new URL(target.url).origin,
    "User-Agent": BROWSER_UA,
    Accept: "*/*",
  };
  if (range) upstreamHeaders.Range = range;

  const peek = await safeFetchBuffer(target.url, {
    timeout: 8000,
    maxBytes: 64_000,
    truncate: true,
    headers: { ...upstreamHeaders, Range: range ?? "bytes=0-65535" },
  });
  if (peek.status >= 400) return errorResponse("Stream unavailable", 502);
  const kind = classifyBytes(peek.body);
  const ctKind = kindFromContentType(header(peek.headers, "content-type"));
  if (kind === "hls" || (ctKind === "hls" && isHlsManifest(peek.body.toString("utf8")))) {
    const text = peek.body.toString("utf8");
    const rewritten = rewriteHlsManifest(text, peek.url || target.url, (abs) => {
      assertPublicHttpUrl(abs);
      return signProxyUrl("stream", abs, referer);
    });
    const headers = new Headers({ "content-type": "application/vnd.apple.mpegurl" });
    applySecurityHeaders(headers, "stream");
    return new Response(rewritten, { status: 200, headers });
  }
  if (!isBrowserMedia(kind) && ctKind !== "mp4" && ctKind !== "webm") {
    if (kind === "image" || kind === "html" || kind === "json") {
      return errorResponse("Unsupported media", 415);
    }
  }

  const streamed = await safeFetchStream(target.url, {
    timeout: 20_000,
    headers: upstreamHeaders,
  });
  if (streamed.status >= 400 && streamed.status !== 206) {
    streamed.stream.resume();
    return errorResponse("Stream unavailable", 502);
  }

  const headers = new Headers();
  const pass = ["content-type", "content-length", "content-range", "accept-ranges"];
  for (const name of pass) {
    const v = header(streamed.headers, name);
    if (v) headers.set(name, v);
  }
  if (!headers.has("content-type") || headers.get("content-type") === "application/octet-stream") {
    headers.set("content-type", kind === "webm" ? "video/webm" : "video/mp4");
  }
  if (!headers.has("accept-ranges")) headers.set("accept-ranges", "bytes");
  applySecurityHeaders(headers, "stream");
  headers.set("Cache-Control", "private, max-age=120");
  return new Response(nodeStreamToWeb(streamed.stream), {
    status: streamed.status || 200,
    headers,
  });
}
