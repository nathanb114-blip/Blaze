import { absUrl } from "./html.ts";

export function isHlsManifest(text: string): boolean {
  return text.trimStart().startsWith("#EXTM3U");
}

export function rewriteHlsManifest(
  text: string,
  baseUrl: string,
  sign: (absolute: string) => string,
): string {
  return text
    .split(/\r?\n/)
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;
      if (trimmed.startsWith("#")) {
        return line.replace(/URI="([^"]+)"/g, (_, uri: string) => {
          const abs = absUrl(uri, baseUrl);
          return abs ? `URI="${sign(abs)}"` : `URI="${uri}"`;
        });
      }
      const abs = absUrl(trimmed, baseUrl);
      return abs ? sign(abs) : line;
    })
    .join("\n");
}
