export function decodeEntities(input: string): string {
  return input.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (full, body: string) => {
    const key = body.toLowerCase();
    if (key.startsWith("#x")) {
      const n = Number.parseInt(key.slice(2), 16);
      return Number.isFinite(n) ? String.fromCodePoint(n) : full;
    }
    if (key.startsWith("#")) {
      const n = Number.parseInt(key.slice(1), 10);
      return Number.isFinite(n) ? String.fromCodePoint(n) : full;
    }
    return ENTITY_MAP[key] ?? full;
  });
}

const ENTITY_MAP: Record<string, string> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  nbsp: " ",
};

export function cleanTitle(raw: string): string {
  let t = decodeEntities(String(raw ?? ""));
  if (/[ÃÂâïÆØ]/.test(t)) {
    try {
      const bytes = Uint8Array.from({ length: t.length }, (_, i) => t.charCodeAt(i) & 0xff);
      const decoded = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
      if (decoded && !decoded.includes("\uFFFD") && decoded !== t) t = decoded;
    } catch {
      /* keep original */
    }
  }
  t = Array.from(t)
    .filter((char) => {
      const code = char.codePointAt(0) ?? 0;
      return code > 31 && code !== 127 && code !== 0xfffd;
    })
    .join("");
  return t
    .replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, "")
    .replace(/^[èéêëåãâäàáøæïîìíôöòóûüùúÿçñ±ÃÂ]+/i, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function isJunkTitle(title: string): boolean {
  const t = title.trim();
  if (t.length < 3) return true;
  if (/^video\s*upload/i.test(t)) return true;
  if (/^(untitled|no title|n\/a|null|undefined|private video)$/i.test(t)) return true;
  if (/^\d{1,2}[./-]\d{1,2}[./-]\d{2,4}$/.test(t)) return true;
  if (/^[a-z]?\d{4,}$/i.test(t)) return true;
  const letters = (t.match(/\p{L}/gu) ?? []).length;
  if (letters < 3) return true;
  return false;
}

export function decodeMaybeUrl(input: string): string {
  let value = decodeEntities(input.trim());
  try {
    value = decodeURIComponent(value);
  } catch {
    /* keep */
  }
  return value.replace(/\\u002f/gi, "/").replace(/\\\//g, "/");
}

export function attr(tag: string, name: string): string | null {
  const re = new RegExp(`(?:^|\\s)${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, "i");
  const m = tag.match(re);
  if (!m) return null;
  return decodeEntities(m[1] ?? m[2] ?? m[3] ?? "").trim() || null;
}

export function absUrl(href: string, base: string): string | null {
  const raw = decodeMaybeUrl(href).trim();
  if (!raw || raw.startsWith("javascript:") || raw.startsWith("data:")) return null;
  try {
    const resolved = new URL(raw, base);
    if (resolved.protocol !== "http:" && resolved.protocol !== "https:") return null;
    return resolved.href;
  } catch {
    return null;
  }
}
