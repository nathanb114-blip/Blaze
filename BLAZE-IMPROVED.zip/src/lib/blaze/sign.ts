import { createHmac, timingSafeEqual } from "node:crypto";

export function hmacSign(secret: string, message: string): string {
  return createHmac("sha256", secret).update(message).digest("base64url");
}

export function hmacVerify(secret: string, message: string, signature: string): boolean {
  const expected = hmacSign(secret, message);
  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export function proxyMessage(
  route: "image" | "stream",
  url: string,
  referer: string,
  exp: number,
): string {
  return `${route}\n${url}\n${referer}\n${exp}`;
}

export const PROXY_TTL_SECONDS = 12 * 60 * 60;
