const BLOCKED_HOSTS = new Set([
  "localhost",
  "localhost.localdomain",
  "metadata.google.internal",
  "metadata.internal",
  "ip6-localhost",
  "ip6-loopback",
]);

function ipv4ToInt(ip: string): number | null {
  const parts = ip.split(".");
  if (parts.length !== 4) return null;
  const nums = parts.map((p) => Number(p));
  if (nums.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) return null;
  return ((nums[0]! << 24) >>> 0) + (nums[1]! << 16) + (nums[2]! << 8) + nums[3]!;
}

function inCidr(ip: string, cidr: string): boolean {
  const [base, bitsStr] = cidr.split("/");
  const bits = Number(bitsStr);
  const ipInt = ipv4ToInt(ip);
  const baseInt = ipv4ToInt(base ?? "");
  if (ipInt == null || baseInt == null || !Number.isFinite(bits)) return false;
  const mask = bits === 0 ? 0 : (~0 << (32 - bits)) >>> 0;
  return (ipInt & mask) === (baseInt & mask);
}

const V4_BLOCKS = [
  "0.0.0.0/8",
  "10.0.0.0/8",
  "100.64.0.0/10",
  "127.0.0.0/8",
  "169.254.0.0/16",
  "172.16.0.0/12",
  "192.0.0.0/24",
  "192.0.2.0/24",
  "192.168.0.0/16",
  "198.18.0.0/15",
  "198.51.100.0/24",
  "203.0.113.0/24",
  "224.0.0.0/4",
  "240.0.0.0/4",
];

function expandIpv6(ip: string): string | null {
  let v = ip.trim().toLowerCase();
  if (v.startsWith("[") && v.endsWith("]")) v = v.slice(1, -1);
  if (v.includes(".")) {
    const mapped = v.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/i);
    if (mapped) return mapped[1] ?? null;
  }
  const [head, tail] = v.split("::");
  const headParts = head ? head.split(":") : [];
  const tailParts = tail ? tail.split(":") : [];
  if (!v.includes("::") && v.split(":").length !== 8) return null;
  const missing = 8 - headParts.filter(Boolean).length - tailParts.filter(Boolean).length;
  const mid = Array.from({ length: Math.max(missing, 0) }, () => "0");
  const parts = [...headParts.filter(Boolean), ...mid, ...tailParts.filter(Boolean)];
  if (parts.length !== 8) return null;
  return parts.map((p) => p.padStart(4, "0")).join(":");
}

export function isBlockedIp(ip: string): boolean {
  const raw = ip.trim().toLowerCase();
  if (!raw) return true;
  if (raw === "::1" || raw === "::" || raw === "0:0:0:0:0:0:0:1") return true;
  if (raw.includes(".")) {
    const v4 = raw.startsWith("::ffff:") ? raw.slice(7) : raw;
    if (v4 === "255.255.255.255") return true;
    return V4_BLOCKS.some((c) => inCidr(v4, c));
  }
  const full = expandIpv6(raw);
  if (!full) return true;
  if (full === "0000:0000:0000:0000:0000:0000:0000:0001") return true;
  if (full === "0000:0000:0000:0000:0000:0000:0000:0000") return true;
  const first = Number.parseInt(full.slice(0, 4), 16);
  if ((first & 0xfe00) === 0xfc00) return true;
  if ((first & 0xffc0) === 0xfe80) return true;
  if ((first & 0xff00) === 0xff00) return true;
  return false;
}

export function isBlockedHostname(hostname: string): boolean {
  const host = hostname.replace(/\.$/, "").toLowerCase();
  if (BLOCKED_HOSTS.has(host)) return true;
  if (host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal")) {
    return true;
  }
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) && isBlockedIp(host)) return true;
  return false;
}

export class SsrfError extends Error {
  constructor(message = "Blocked private or unsupported URL") {
    super(message);
    this.name = "SsrfError";
  }
}

export function assertPublicHttpUrl(raw: string): URL {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new SsrfError("Invalid URL");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new SsrfError("Only HTTP and HTTPS are allowed");
  }
  if (url.username || url.password) {
    throw new SsrfError("URLs with credentials are not allowed");
  }
  if (isBlockedHostname(url.hostname)) {
    throw new SsrfError("Host is not allowed");
  }
  return url;
}
