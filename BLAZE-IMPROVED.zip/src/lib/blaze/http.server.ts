import type { RateName } from "./rate-limit.server.ts";
import { consumeRate } from "./rate-limit.server.ts";
import { errorResponse, originAllowed, sanitizeError } from "./security.server.ts";

export async function handleApi(
  request: Request,
  allowed: string[],
  rate: RateName | null,
  run: () => Promise<Response>,
): Promise<Response> {
  const method = request.method.toUpperCase();
  if (method === "OPTIONS") {
    const headers = new Headers({
      Allow: [...allowed, "OPTIONS"].join(", "),
      "Access-Control-Allow-Methods": [...allowed, "OPTIONS"].join(", "),
      "Access-Control-Allow-Headers": "content-type",
      "Access-Control-Max-Age": "600",
    });
    return new Response(null, { status: 204, headers });
  }
  if (!allowed.includes(method)) {
    return errorResponse("Method not allowed", 405);
  }
  if (!originAllowed(request)) {
    return errorResponse("Origin not allowed", 403);
  }
  if (rate) {
    const hit = consumeRate(request, rate);
    if (!hit.ok) {
      const headers = new Headers({
        "content-type": "application/json; charset=utf-8",
        "Retry-After": String(hit.retryAfter),
        "Cache-Control": "no-store",
      });
      return new Response(JSON.stringify({ error: "Too many requests" }), {
        status: 429,
        headers,
      });
    }
  }
  try {
    return await run();
  } catch (err) {
    const status =
      err && typeof err === "object" && "status" in err && typeof (err as { status: unknown }).status === "number"
        ? (err as { status: number }).status
        : 500;
    return errorResponse(sanitizeError(err), status >= 400 && status < 600 ? status : 500);
  }
}

export function readQuery(request: Request): URLSearchParams {
  return new URL(request.url).searchParams;
}
