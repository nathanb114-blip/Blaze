import type { Orientation, PlayMode, TubeSource, VideoCard } from "./types.ts";
import { PREFIX_SOURCE, SOURCE_META, SOURCE_PREFIX } from "./types.ts";
import { isProhibitedText } from "./policy.ts";
import { signProxyUrl } from "./proxy-sign.server.ts";
import { safeFetchText } from "./fetch-safe.server.ts";
import { cleanTitle, isJunkTitle } from "./html.ts";

export const MIXED_PER_SOURCE = 8;
export const SOLO_PAGE_SIZE = 40;

const cache = new Map<string, { at: number; data: unknown }>();
const CACHE_MS = 40_000;

export async function cachedJson<T>(key: string, load: () => Promise<T>, ttl = CACHE_MS): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttl) return hit.data as T;
  const data = await load();
  cache.set(key, { at: Date.now(), data });
  if (cache.size > 280) {
    const first = cache.keys().next().value;
    if (first) cache.delete(first);
  }
  return data;
}

export async function getJson(url: string, headers?: Record<string, string>): Promise<unknown> {
  const res = await safeFetchText(url, {
    timeout: 7000,
    maxBytes: 2_000_000,
    headers: { Accept: "application/json", ...headers },
  });
  if (res.status >= 400) throw Object.assign(new Error("Catalog unavailable"), { status: 502 });
  return JSON.parse(res.text) as unknown;
}

export async function getHtml(url: string, timeout = 9000): Promise<string> {
  let referer = "https://www.google.com/";
  try {
    referer = `${new URL(url).origin}/`;
  } catch {
    /* keep default */
  }
  const res = await safeFetchText(url, {
    timeout,
    maxBytes: 1_800_000,
    headers: {
      Accept: "text/html,application/xhtml+xml",
      Referer: referer,
    },
  });
  if (res.status >= 400) throw Object.assign(new Error("Catalog unavailable"), { status: 502 });
  return res.text;
}

export function parseClock(raw: string | number | null | undefined): number | null {
  if (typeof raw === "number" && Number.isFinite(raw) && raw > 0) return Math.round(raw);
  if (typeof raw !== "string") return null;
  const text = raw.trim();
  const min = text.match(/^(\d+)\s*min/i);
  if (min) return Number(min[1]) * 60;
  const compact = text.replace(/\s+/g, "");
  const ms = compact.match(/^(\d+)m:?(\d+)s?$/i);
  if (ms) return Number(ms[1]) * 60 + Number(ms[2] ?? 0);
  const parts = text.split(":").map((p) => Number(p));
  if (parts.length < 2 || parts.length > 3 || parts.some((n) => !Number.isFinite(n))) return null;
  if (parts.length === 2) return parts[0]! * 60 + parts[1]!;
  return parts[0]! * 3600 + parts[1]! * 60 + parts[2]!;
}

export function parseViews(raw: unknown): number | null {
  if (typeof raw === "number" && Number.isFinite(raw)) return raw;
  if (typeof raw !== "string") return null;
  const text = raw.replace(/,/g, "").trim();
  const m = text.match(/^([\d.]+)\s*([kmb])?$/i);
  if (!m) {
    const n = Number(text);
    return Number.isFinite(n) ? n : null;
  }
  const n = Number(m[1]);
  if (!Number.isFinite(n)) return null;
  const u = (m[2] ?? "").toLowerCase();
  if (u === "k") return Math.round(n * 1_000);
  if (u === "m") return Math.round(n * 1_000_000);
  if (u === "b") return Math.round(n * 1_000_000_000);
  return n;
}

export function parseRating(raw: unknown): number | null {
  if (typeof raw === "number" && Number.isFinite(raw)) return raw > 5 ? raw : raw * 20;
  if (typeof raw !== "string") return null;
  const n = Number.parseFloat(raw);
  if (!Number.isFinite(n)) return null;
  return n > 5 ? n : n * 20;
}

export function tagsFrom(raw: unknown): string[] {
  if (!raw) return [];
  if (typeof raw === "string") {
    return raw
      .split(",")
      .map((t) => cleanTitle(t.trim()))
      .filter((t) => t.length > 1 && t.length < 40 && !isProhibitedText(t))
      .slice(0, 12);
  }
  if (!Array.isArray(raw)) return [];
  const out: string[] = [];
  for (const item of raw) {
    const name =
      typeof item === "string"
        ? item
        : item && typeof item === "object" && "tag_name" in item
          ? String((item as { tag_name: unknown }).tag_name)
          : "";
    const t = cleanTitle(name.trim());
    if (t.length > 1 && t.length < 40 && !isProhibitedText(t) && !out.includes(t)) out.push(t);
    if (out.length >= 12) break;
  }
  return out;
}

export function thumb(url: string | null | undefined, referer: string): string | null {
  if (!url) return null;
  let href = url.trim();
  if (href.startsWith("//")) href = `https:${href}`;
  if (!/^https?:\/\//i.test(href)) return null;
  try {
    return signProxyUrl("image", href, referer);
  } catch {
    return null;
  }
}

export function card(partial: Omit<VideoCard, "hd" | "playMode"> & { hd?: boolean; playMode?: PlayMode }): VideoCard | null {
  const title = cleanTitle(partial.title);
  if (!partial.id || !title || !partial.pageUrl) return null;
  if (isJunkTitle(title)) return null;
  if (isProhibitedText(title, partial.tags.join(" "), partial.pageUrl)) return null;
  const meta = SOURCE_META[partial.source];
  return {
    ...partial,
    title,
    hd: partial.hd ?? true,
    playMode: partial.playMode ?? meta.playMode,
  };
}

export function encodeId(source: TubeSource, raw: string): string {
  return `${SOURCE_PREFIX[source]}-${raw}`;
}

export function parseVideoId(id: string): { source: TubeSource; raw: string } {
  const m = id.match(/^([a-z]{2})-(.+)$/i);
  if (m) {
    const source = PREFIX_SOURCE[m[1]!.toLowerCase()];
    if (source) return { source, raw: m[2]! };
  }
  throw Object.assign(new Error("Invalid video"), { status: 404 });
}

export function fitsOrientation(v: VideoCard, orientation: Orientation): boolean {
  const blob = `${v.title} ${v.tags.join(" ")}`;
  const trans = /\b(shemale|shemales|ladyboy|ladyboys|futanari|tgirl|t-girl|transwoman|trans girl|dickgirl|transsexual)\b/i.test(
    blob,
  );
  const gay = /\b(gay|twink|twinks)\b/i.test(blob);
  if (orientation === "straight") return !trans && !gay;
  if (orientation === "gay") return !trans;
  return true;
}

export function orientQuery(query: string, orientation: Orientation): string {
  if (query === "all") {
    if (orientation === "gay") return "gay";
    if (orientation === "trans") return "trans";
    return "all";
  }
  if (orientation === "gay" && !/gay|twink|bear|muscle/i.test(query)) return `${query} gay`;
  if (orientation === "trans" && !/trans/i.test(query)) return `${query} trans`;
  return query;
}
