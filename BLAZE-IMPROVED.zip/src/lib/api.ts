import type {
  FeaturedRail,
  Orientation,
  PlayableResponse,
  SearchResponse,
  SortMode,
  TubeSource,
} from "@/lib/blaze/types";

async function getJson<T>(path: string): Promise<T> {
  const res = await fetch(path);
  const data = (await res.json().catch(() => ({}))) as { error?: string } & T;
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

export function searchPath(opts: {
  q: string;
  page?: number;
  sort?: SortMode;
  orient?: Orientation;
  net?: TubeSource | "all";
}): string {
  const p = new URLSearchParams();
  p.set("q", opts.q || "all");
  p.set("page", String(opts.page ?? 1));
  p.set("sort", opts.sort ?? "most-popular");
  p.set("orient", opts.orient ?? "straight");
  p.set("net", opts.net ?? "all");
  return `/api/search?${p.toString()}`;
}

export function fetchSearch(opts: {
  q: string;
  page?: number;
  sort?: SortMode;
  orient?: Orientation;
  net?: TubeSource | "all";
}): Promise<SearchResponse> {
  return getJson<SearchResponse>(searchPath(opts));
}

export function fetchFeatured(orient: Orientation, net: TubeSource | "all" = "all"): Promise<FeaturedRail[]> {
  const p = new URLSearchParams();
  p.set("orient", orient);
  p.set("net", net);
  return getJson<FeaturedRail[]>(`/api/featured?${p.toString()}`);
}

export function fetchPlayable(id: string): Promise<PlayableResponse> {
  return getJson<PlayableResponse>(`/api/playable?id=${encodeURIComponent(id)}`);
}

export function fetchSuggest(q: string): Promise<string[]> {
  return getJson<{ suggestions: string[] }>(`/api/suggest?q=${encodeURIComponent(q)}`).then(
    (d) => d.suggestions ?? [],
  );
}
