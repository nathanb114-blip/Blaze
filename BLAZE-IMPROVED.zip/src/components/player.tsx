import { useEffect, useLayoutEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import {
  ChevronDown,
  ChevronLeft,
  Maximize,
  Minimize,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
} from "lucide-react";
import type { PlayableQuality, PlayableResponse } from "@/lib/blaze/types";
import { cn, formatDuration } from "@/lib/utils";
import { useTube } from "@/store/tube";

function unlockOrientation() {
  try {
    screen.orientation?.unlock?.();
  } catch {
    /* ignore */
  }
}

type FsEl = HTMLElement & {
  webkitRequestFullscreen?: () => Promise<void> | void;
  webkitRequestFullScreen?: () => Promise<void> | void;
  mozRequestFullScreen?: () => Promise<void> | void;
  msRequestFullscreen?: () => Promise<void> | void;
};

type FsDoc = Document & {
  webkitFullscreenElement?: Element | null;
  mozFullScreenElement?: Element | null;
  msFullscreenElement?: Element | null;
  webkitExitFullscreen?: () => Promise<void> | void;
  webkitCancelFullScreen?: () => Promise<void> | void;
  mozCancelFullScreen?: () => Promise<void> | void;
  msExitFullscreen?: () => Promise<void> | void;
};

type IosVideo = HTMLVideoElement & {
  webkitEnterFullscreen?: () => void;
  webkitExitFullscreen?: () => void;
  webkitDisplayingFullscreen?: boolean;
  webkitSupportsPresentationMode?: (mode: string) => boolean;
  webkitSetPresentationMode?: (mode: "inline" | "fullscreen" | "picture-in-picture") => void;
  webkitPresentationMode?: string;
  webkitPlaysinline?: boolean;
};

function isTouchIos() {
  if (typeof navigator === "undefined") return false;
  return /iPad|iPhone|iPod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
}

function inTopWindow() {
  try {
    return window.top === window;
  } catch {
    return false;
  }
}

function forceInline(v: HTMLVideoElement | null | undefined) {
  if (!v) return;
  const ios = v as IosVideo;
  v.playsInline = true;
  v.controls = false;
  ios.webkitPlaysinline = true;
  v.setAttribute("playsinline", "true");
  v.setAttribute("webkit-playsinline", "true");
}

function nativeFsElement(): Element | null {
  const doc = document as FsDoc;
  return (
    document.fullscreenElement ||
    doc.webkitFullscreenElement ||
    doc.mozFullScreenElement ||
    doc.msFullscreenElement ||
    null
  );
}

function requestNativeFs(el: HTMLElement): Promise<boolean> {
  const node = el as FsEl;
  const fn =
    node.requestFullscreen ||
    node.webkitRequestFullscreen ||
    node.webkitRequestFullScreen ||
    node.mozRequestFullScreen ||
    node.msRequestFullscreen;
  if (!fn) return Promise.resolve(false);
  try {
    return Promise.race([
      Promise.resolve(fn.call(node)).then(
        () => true,
        () => false,
      ),
      new Promise<boolean>((resolve) => window.setTimeout(() => resolve(false), 600)),
    ]);
  } catch {
    return Promise.resolve(false);
  }
}

function exitNativeFs(): Promise<void> {
  if (!nativeFsElement()) return Promise.resolve();
  const doc = document as FsDoc;
  const fn =
    document.exitFullscreen ||
    doc.webkitExitFullscreen ||
    doc.webkitCancelFullScreen ||
    doc.mozCancelFullScreen ||
    doc.msExitFullscreen;
  if (!fn) return Promise.resolve();
  try {
    return Promise.resolve(fn.call(document)).then(
      () => undefined,
      () => undefined,
    );
  } catch {
    return Promise.resolve();
  }
}

export function useStayInApp() {
  useEffect(() => {
    const originalOpen = window.open;
    window.open = () => null;
    const block = (e: Event) => {
      const target = e.target;
      if (!(target instanceof Element)) return;
      const a = target.closest("a");
      if (!a) return;
      if (a.hasAttribute("download")) return;
      const href = a.getAttribute("href") ?? "";
      if (
        !href ||
        href.startsWith("#") ||
        href.startsWith("/") ||
        href.startsWith("?") ||
        href.startsWith("blob:") ||
        href.startsWith("data:")
      ) {
        return;
      }
      try {
        const next = new URL(href, window.location.href);
        if (next.origin !== window.location.origin) {
          e.preventDefault();
          e.stopPropagation();
        }
      } catch {
        e.preventDefault();
      }
    };
    document.addEventListener("click", block, true);
    document.addEventListener("auxclick", block, true);
    return () => {
      window.open = originalOpen;
      document.removeEventListener("click", block, true);
      document.removeEventListener("auxclick", block, true);
    };
  }, []);
}

function useTheater(box: RefObject<HTMLElement | null>, video?: RefObject<HTMLVideoElement | null>) {
  const [fs, setFs] = useState(false);
  const wantFs = useRef(false);

  useEffect(() => {
    const onFs = () => {
      const native = Boolean(nativeFsElement());
      if (native && wantFs.current) {
        setFs(true);
        document.body.classList.add("theater-open");
        return;
      }
      if (!native) {
        wantFs.current = false;
        document.body.classList.remove("theater-open");
        setFs(false);
      }
    };
    document.addEventListener("fullscreenchange", onFs);
    document.addEventListener("webkitfullscreenchange", onFs);
    return () => {
      document.removeEventListener("fullscreenchange", onFs);
      document.removeEventListener("webkitfullscreenchange", onFs);
    };
  }, []);

  useEffect(() => {
    return () => {
      wantFs.current = false;
      document.body.classList.remove("theater-open");
      unlockOrientation();
    };
  }, []);

  async function enter() {
    wantFs.current = true;
    setFs(true);
    document.body.classList.add("theater-open");
    if (!isTouchIos() && inTopWindow() && box.current) {
      void requestNativeFs(box.current);
    }
  }

  async function exit() {
    wantFs.current = false;
    const ios = video?.current as IosVideo | undefined;
    if (ios?.webkitDisplayingFullscreen && typeof ios.webkitExitFullscreen === "function") {
      try {
        ios.webkitExitFullscreen();
      } catch {
        /* ignore */
      }
    }
    await exitNativeFs();
    document.body.classList.remove("theater-open");
    setFs(false);
    unlockOrientation();
  }

  return { fs, enter, exit, toggle: () => (fs ? exit() : enter()) };
}

export function Player({ video, onBack }: { video: PlayableResponse; onBack?: () => void }) {
  if (video.playMode === "embed" && video.embedUrl) {
    return <EmbedPlayer video={video} onBack={onBack} />;
  }
  return <NativePlayer video={video} onBack={onBack} />;
}

function QualityMenu({
  options,
  value,
  onChange,
  tone = "overlay",
  name = "Video quality",
}: {
  options: { label: string; value: number }[];
  value: number;
  onChange: (next: number) => void;
  tone?: "overlay" | "solid";
  name?: string;
}) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const current = options.find((o) => o.value === value)?.label ?? options[0]?.label ?? "HD";
  const btnClass =
    tone === "solid"
      ? "flex h-11 min-w-20 items-center justify-center gap-1 rounded-sm border border-border bg-surface-2 px-3 text-sm font-semibold text-fg hover:bg-surface-3"
      : "flex h-11 min-w-[3.25rem] items-center justify-center gap-1 rounded-xs bg-overlay px-2.5 text-xs font-semibold text-fg";

  useEffect(() => {
    if (!open) return;
    function onDoc(e: MouseEvent) {
      if (root.current && !root.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  if (options.length === 0) return null;
  if (options.length === 1) {
    return (
      <span className={cn(btnClass, "pointer-events-auto")}>
        {current}
      </span>
    );
  }

  return (
    <div ref={root} className="relative pointer-events-auto">
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={name}
        onClick={() => setOpen((v) => !v)}
        className={btnClass}
      >
        {current}
        <ChevronDown className={cn("size-3.5", open && "rotate-180")} />
      </button>
      {open ? (
        <ul
          role="listbox"
          aria-label={name}
          className="absolute top-full right-0 z-40 mt-1 min-w-28 overflow-hidden rounded-xs border border-border bg-surface shadow-player"
        >
          {options.map((o) => (
            <li key={`${o.label}-${o.value}`}>
              <button
                type="button"
                role="option"
                aria-selected={o.value === value}
                className={cn(
                  "flex h-11 w-full items-center px-3 text-left text-sm font-medium",
                  o.value === value ? "bg-accent text-accent-fg" : "text-fg hover:bg-surface-2",
                )}
                onClick={() => {
                  onChange(o.value);
                  setOpen(false);
                }}
              >
                {o.label}
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

function DockedControls({
  quality,
  speed,
  onToggleFs,
  onBack,
}: {
  quality?: ReactNode;
  speed?: ReactNode;
  onToggleFs: () => void;
  onBack?: () => void;
}) {
  return (
    <div className="mt-2 flex flex-wrap items-center gap-2">
      {onBack ? (
        <button
          type="button"
          onClick={onBack}
          className="inline-flex h-11 items-center gap-1 rounded-sm bg-accent px-3 text-sm font-semibold text-accent-fg hover:bg-accent-hover"
        >
          <ChevronLeft className="size-5" />
          Back
        </button>
      ) : null}
      {quality ? (
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-muted">Quality</span>
          {quality}
        </div>
      ) : null}
      {speed ? (
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-muted">Speed</span>
          {speed}
        </div>
      ) : null}
      <button
        type="button"
        onClick={onToggleFs}
        className="inline-flex h-11 items-center gap-2 rounded-sm border border-border bg-surface-2 px-3 text-sm font-semibold text-fg hover:bg-surface-3"
      >
        <Maximize className="size-4" />
        Full screen
      </button>
    </div>
  );
}

function OverlayBack({ onBack, label = "Back" }: { onBack: () => void; label?: string }) {
  return (
    <button
      type="button"
      onClick={onBack}
      className="pointer-events-auto flex h-11 items-center gap-1 rounded-xs bg-overlay px-2.5 text-sm font-semibold text-fg"
      aria-label={label}
    >
      <ChevronLeft className="size-5" />
      Back
    </button>
  );
}

function OverlayFs({ onToggle, fs }: { onToggle: () => void; fs: boolean }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className="pointer-events-auto flex size-11 items-center justify-center rounded-xs bg-overlay text-fg"
      aria-label={fs ? "Exit fullscreen" : "Fullscreen"}
    >
      {fs ? <Minimize className="size-5" /> : <Maximize className="size-5" />}
    </button>
  );
}

function TopChrome({
  fs,
  onBack,
  onToggleFs,
  quality,
}: {
  fs: boolean;
  onBack?: () => void;
  onToggleFs: () => void;
  quality?: ReactNode;
}) {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-center justify-between gap-2 p-2 pt-[max(0.5rem,env(safe-area-inset-top))]">
      {fs ? (
        <OverlayBack onBack={onToggleFs} label="Exit fullscreen" />
      ) : onBack ? (
        <OverlayBack onBack={onBack} label="Back to videos" />
      ) : (
        <span />
      )}
      <div className="flex items-center gap-1">
        {quality}
        <OverlayFs onToggle={onToggleFs} fs={fs} />
      </div>
    </div>
  );
}

function EmbedPlayer({ video, onBack }: { video: PlayableResponse; onBack?: () => void }) {
  const box = useRef<HTMLDivElement>(null);
  const { fs, toggle, exit } = useTheater(box);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        if (fs) {
          e.preventDefault();
          void exit();
        } else {
          onBack?.();
        }
      } else if (e.key === "f") {
        e.preventDefault();
        void toggle();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  return (
    <div>
    <div
      ref={box}
      className={cn("player-stage relative rounded-sm bg-bg shadow-player", fs && "player-theater")}
    >
      {started ? (
        <iframe
          src={video.embedUrl ?? video.fileUrl}
          title={video.title}
          className="relative z-0 aspect-video h-full w-full bg-bg"
          allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
          referrerPolicy="origin"
          sandbox="allow-scripts allow-same-origin allow-presentation allow-fullscreen"
          allowFullScreen
          tabIndex={-1}
        />
      ) : (
        <button
          type="button"
          onClick={() => setStarted(true)}
          className="relative flex aspect-video h-full w-full items-center justify-center bg-surface-2"
          aria-label="Play"
        >
          {video.thumbnail ? (
            <img src={video.thumbnail} alt="" className="absolute inset-0 h-full w-full object-cover" />
          ) : null}
          <span className="absolute inset-0 bg-gradient-to-t from-overlay to-transparent" />
          <span className="relative flex size-20 items-center justify-center rounded-full bg-accent text-accent-fg shadow-player">
            <Play className="ml-1 size-9 fill-current" />
          </span>
        </button>
      )}
      {fs ? (
        <TopChrome fs onToggleFs={() => void exit()} />
      ) : (
        <TopChrome fs={false} onBack={onBack} onToggleFs={() => void toggle()} />
      )}
      {!fs ? (
        <div className="player-chrome pointer-events-none absolute inset-x-0 bottom-0 z-30 flex items-end justify-end bg-gradient-to-t from-overlay to-transparent px-3 pt-10 pb-2">
          <OverlayFs onToggle={() => void toggle()} fs={false} />
        </div>
      ) : null}
    </div>
      {!fs ? <DockedControls onBack={onBack} onToggleFs={() => void toggle()} /> : null}
    </div>
  );
}

function pickStartQuality(qs: PlayableQuality[]): number {
  if (!qs.length) return 0;
  const idx = qs.findIndex((q) => q.height > 0 && q.height <= 720);
  return idx >= 0 ? idx : 0;
}

function NativePlayer({ video, onBack }: { video: PlayableResponse; onBack?: () => void }) {
  const el = useRef<HTMLVideoElement>(null);
  const box = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<import("hls.js").default | null>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [vol, setVol] = useState(1);
  const [time, setTime] = useState(0);
  const [dur, setDur] = useState(video.duration ?? 0);
  const [qIndex, setQIndex] = useState(() => pickStartQuality(video.qualities));
  const [hlsLevels, setHlsLevels] = useState<PlayableQuality[]>([]);
  const [hlsLevel, setHlsLevel] = useState(-1);
  const [unavailable, setUnavailable] = useState(false);
  const [ready, setReady] = useState(false);
  const [show, setShow] = useState(true);
  const hideTimer = useRef<number | null>(null);
  const timeRef = useRef(0);
  const lastSave = useRef(0);
  const setProgress = useTube((s) => s.setProgress);
  const { fs, toggle, exit } = useTheater(box, el);
  const [rate, setRate] = useState(1);

  const quality = video.qualities[qIndex] ?? video.qualities[0];
  const src = quality?.url ?? video.fileUrl;
  const menuQualities = video.qualities.length > 1 ? video.qualities : hlsLevels;
  const chromeOn = show || !playing;

  useLayoutEffect(() => {
    forceInline(el.current);
  }, [src, video.id]);

  useEffect(() => {
    timeRef.current = 0;
    lastSave.current = 0;
    setQIndex(pickStartQuality(video.qualities));
    setTime(0);
  }, [video.id, video.qualities]);

  useEffect(() => {
    const node = el.current;
    if (!node || !src) return;
    let cancelled = false;
    setUnavailable(false);
    setReady(false);

    const resumeAt = timeRef.current > 1 ? timeRef.current : (useTube.getState().progress[video.id] ?? 0);

    async function attach() {
      hlsRef.current?.destroy();
      hlsRef.current = null;
      if (!node) return;
      forceInline(node);

      const isHls = /\.m3u8/i.test(src);

      if (isHls) {
        const Hls = (await import("hls.js")).default;
        if (cancelled || !node) return;
        if (Hls.isSupported()) {
          const hls = new Hls({
            enableWorker: true,
            maxBufferLength: 30,
            capLevelToPlayerSize: true,
          });
          hls.loadSource(src);
          hls.attachMedia(node);
          hls.on(Hls.Events.MANIFEST_PARSED, (_e, data) => {
            const levels = (data.levels ?? [])
              .map((lvl, i) => ({
                label: lvl.height ? `${lvl.height}p` : `L${i + 1}`,
                height: lvl.height ?? 0,
                url: String(i),
              }))
              .filter((q) => q.height >= 144);
            const unique: PlayableQuality[] = [];
            for (const q of levels.sort((a, b) => b.height - a.height)) {
              if (!unique.some((u) => u.height === q.height)) unique.push(q);
            }
            if (unique.length > 1 && video.qualities.length <= 1) setHlsLevels(unique);
          });
          hls.on(Hls.Events.ERROR, (_e, data) => {
            if (!data.fatal || cancelled) return;
            if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
              hls.startLoad();
              return;
            }
            if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
              hls.recoverMediaError();
              return;
            }
            setUnavailable(true);
          });
          hlsRef.current = hls;
        } else {
          node.src = src;
        }
      } else {
        node.src = src;
      }

      await new Promise<void>((resolve) => {
        if (!node || node.readyState >= 1) {
          resolve();
          return;
        }
        const done = () => resolve();
        node.addEventListener("loadedmetadata", done, { once: true });
        window.setTimeout(done, 8000);
      });
      if (cancelled || !node) return;
      if (resumeAt > 1 && Number.isFinite(node.duration) && node.duration > resumeAt) {
        try {
          node.currentTime = resumeAt;
        } catch {
          /* ignore */
        }
      }
      setReady(true);
      setDur(node.duration || video.duration || 0);
      forceInline(node);
      node.playbackRate = rate;
      if (useTube.getState().autoplay) void node.play().catch(() => setPlaying(false));
    }

    void attach();

    return () => {
      cancelled = true;
      hlsRef.current?.destroy();
      hlsRef.current = null;
    };
  }, [src, video.id, video.duration, video.qualities.length, rate]);

  useEffect(() => {
    const node = el.current;
    if (node) node.playbackRate = rate;
  }, [rate]);

  useEffect(() => {
    const node = el.current;
    if (!node) return;
    const onPlay = () => setPlaying(true);
    const onPause = () => {
      setPlaying(false);
      setProgress(video.id, node.currentTime);
    };
    const onTime = () => {
      const now = node.currentTime;
      timeRef.current = now;
      setTime(now);
      if (Math.abs(now - lastSave.current) >= 5) {
        lastSave.current = now;
        setProgress(video.id, now);
      }
    };
    const onMeta = () => {
      setDur(node.duration || video.duration || 0);
      setReady(true);
    };
    const onPlaying = () => {
      setReady(true);
      setPlaying(true);
    };
    const onErr = () => {
      const code = node.error?.code ?? 0;
      if (code === 1) return;
      if (hlsRef.current) return;
      setUnavailable(true);
    };
    node.addEventListener("play", onPlay);
    node.addEventListener("pause", onPause);
    node.addEventListener("timeupdate", onTime);
    node.addEventListener("loadedmetadata", onMeta);
    node.addEventListener("playing", onPlaying);
    node.addEventListener("error", onErr);
    return () => {
      node.removeEventListener("play", onPlay);
      node.removeEventListener("pause", onPause);
      node.removeEventListener("timeupdate", onTime);
      node.removeEventListener("loadedmetadata", onMeta);
      node.removeEventListener("playing", onPlaying);
      node.removeEventListener("error", onErr);
      if (node.currentTime > 1) setProgress(video.id, node.currentTime);
    };
  }, [setProgress, video.duration, video.id]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      const node = el.current;
      if (!node) return;
      if (e.key === " " || e.key === "k") {
        e.preventDefault();
        if (node.paused) {
          forceInline(node);
          void node.play().then(() => forceInline(node)).catch(() => undefined);
        }
        else node.pause();
      } else if (e.key === "f") {
        e.preventDefault();
        void toggle();
      } else if (e.key === "ArrowRight") {
        node.currentTime = Math.min(node.duration || 0, node.currentTime + 10);
      } else if (e.key === "ArrowLeft") {
        node.currentTime = Math.max(0, node.currentTime - 10);
      } else if (e.key === "m") {
        node.muted = !node.muted;
        setMuted(node.muted);
      } else if (e.key === "Escape") {
        if (fs) {
          e.preventDefault();
          void exit();
        } else {
          onBack?.();
        }
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [exit, fs, onBack, toggle]);

  function pokeChrome() {
    setShow(true);
    if (hideTimer.current) window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => {
      if (!el.current?.paused) setShow(false);
    }, 2800);
  }

  useEffect(() => {
    if (playing) pokeChrome();
    else setShow(true);
  }, [playing]);

  function togglePlay() {
    const node = el.current;
    if (!node) return;
    forceInline(node);
    if (node.paused) void node.play().catch(() => setPlaying(false));
    else node.pause();
    pokeChrome();
  }

  function seek(next: number) {
    const node = el.current;
    if (!node || !Number.isFinite(next)) return;
    node.currentTime = Math.max(0, Math.min(next, dur || next));
    timeRef.current = node.currentTime;
  }

  function changeQuality(index: number) {
    if (video.qualities.length > 1) {
      setQIndex(index);
      return;
    }
    const hls = hlsRef.current;
    if (!hls) return;
    if (index < 0) {
      hls.currentLevel = -1;
      setHlsLevel(-1);
      return;
    }
    const height = hlsLevels[index]?.height;
    const match = typeof height === "number" ? hls.levels.findIndex((lvl) => lvl.height === height) : index;
    hls.currentLevel = match >= 0 ? match : index;
    setHlsLevel(index);
  }

  if (unavailable) {
    return (
      <div className="flex aspect-video flex-col items-center justify-center gap-3 rounded-sm bg-surface-2 text-center">
        <p className="font-display text-2xl tracking-wide">Media unavailable</p>
        <p className="text-sm text-muted">This upload is dead or blocked. Try a related video.</p>
        {onBack ? (
          <button
            type="button"
            onClick={onBack}
            className="inline-flex h-11 items-center rounded-sm bg-accent px-4 text-sm font-semibold text-accent-fg"
          >
            Back to videos
          </button>
        ) : null}
      </div>
    );
  }

  const pct = dur > 0 ? (time / dur) * 100 : 0;
  const qualityOptions =
    video.qualities.length > 1
      ? video.qualities.map((q, i) => ({ label: q.label, value: i }))
      : hlsLevels.length > 1
        ? [{ label: "Auto", value: -1 }, ...hlsLevels.map((q, i) => ({ label: q.label, value: i }))]
        : menuQualities.map((q, i) => ({ label: q.label, value: i }));
  const qualityValue = video.qualities.length > 1 ? qIndex : hlsLevel;
  const qualityMenu = (
    <QualityMenu options={qualityOptions} value={qualityValue} onChange={changeQuality} />
  );
  const qualityDock = (
    <QualityMenu options={qualityOptions} value={qualityValue} onChange={changeQuality} tone="solid" />
  );
  const speedOptions = [
    { label: "0.5×", value: 0.5 },
    { label: "0.75×", value: 0.75 },
    { label: "1×", value: 1 },
    { label: "1.25×", value: 1.25 },
    { label: "1.5×", value: 1.5 },
    { label: "2×", value: 2 },
  ];
  const speedDock = (
    <QualityMenu options={speedOptions} value={rate} onChange={(next) => setRate(next)} tone="solid" name="Playback speed" />
  );

  return (
    <div>
    <div
      ref={box}
      className={cn("player-stage relative rounded-sm bg-bg shadow-player", fs && "player-theater")}
      onMouseMove={pokeChrome}
      onTouchStart={(e) => {
        if (!show && playing) e.preventDefault();
        pokeChrome();
      }}
    >
      <video
        ref={el}
        className="h-full w-full bg-bg object-contain"
        playsInline
        controls={false}
        preload="metadata"
        poster={video.thumbnail ?? undefined}
        onClick={togglePlay}
      />
      {!ready && !playing ? (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <span className="size-10 animate-spin rounded-full border-2 border-accent border-t-transparent" />
        </div>
      ) : null}
      {ready && !playing ? (
        <button
          type="button"
          onClick={togglePlay}
          className="absolute inset-0 z-10 flex items-center justify-center"
          aria-label="Play"
        >
          <span className="flex size-20 items-center justify-center rounded-full bg-accent text-accent-fg shadow-player">
            <Play className="ml-1 size-9 fill-current" />
          </span>
        </button>
      ) : null}
      <TopChrome
        fs={fs}
        onBack={onBack}
        onToggleFs={() => void (fs ? exit() : toggle())}
        quality={qualityMenu}
      />
      <div
        className={cn(
          "player-chrome absolute inset-x-0 bottom-0 z-30 bg-gradient-to-t from-overlay to-transparent px-3 pt-10 pb-2 transition-opacity duration-200",
          chromeOn ? "opacity-100" : "pointer-events-none opacity-0",
        )}
      >
        <input
          type="range"
          min={0}
          max={dur || 0}
          step={0.1}
          value={time}
          aria-label="Seek"
          onChange={(e) => seek(Number(e.target.value))}
          className="h-1 w-full cursor-pointer accent-accent"
          style={{ backgroundSize: `${pct}% 100%` }}
        />
        <div className="mt-1 flex items-center gap-1 text-fg">
          <button type="button" onClick={() => seek(time - 10)} className="flex size-11 items-center justify-center" aria-label="Rewind 10 seconds">
            <SkipBack className="size-5" />
          </button>
          <button type="button" onClick={togglePlay} className="flex size-11 items-center justify-center" aria-label={playing ? "Pause" : "Play"}>
            {playing ? <Pause className="size-6 fill-current" /> : <Play className="size-6 fill-current" />}
          </button>
          <button type="button" onClick={() => seek(time + 10)} className="flex size-11 items-center justify-center" aria-label="Forward 10 seconds">
            <SkipForward className="size-5" />
          </button>
          <button
            type="button"
            onClick={() => {
              const node = el.current;
              if (!node) return;
              node.muted = !node.muted;
              setMuted(node.muted);
            }}
            className="flex size-11 items-center justify-center"
            aria-label={muted ? "Unmute" : "Mute"}
          >
            {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={muted ? 0 : vol}
            aria-label="Volume"
            className="hidden h-1 w-20 cursor-pointer accent-accent sm:block"
            onChange={(e) => {
              const node = el.current;
              const v = Number(e.target.value);
              setVol(v);
              if (node) {
                node.volume = v;
                node.muted = v === 0;
                setMuted(v === 0);
              }
            }}
          />
          <span className="ml-1 text-xs tabular-nums text-muted">
            {formatDuration(time)} / {formatDuration(dur)}
          </span>
          <span className="flex-1" />
          {qualityMenu}
          <button type="button" onClick={() => void toggle()} className="flex size-11 items-center justify-center" aria-label={fs ? "Exit fullscreen" : "Fullscreen"}>
            {fs ? <Minimize className="size-5" /> : <Maximize className="size-5" />}
          </button>
        </div>
      </div>
    </div>
      {!fs ? (
        <DockedControls quality={qualityDock} speed={speedDock} onBack={onBack} onToggleFs={() => void toggle()} />
      ) : null}
    </div>
  );
}
