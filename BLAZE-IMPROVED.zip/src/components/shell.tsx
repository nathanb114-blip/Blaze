import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Clock,
  Grid3x3,
  Home,
  Menu,
  Search,
  Settings,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState, type FormEvent, type KeyboardEvent as ReactKeyboardEvent, type ReactNode } from "react";
import { BlazeLogo } from "@/components/logo";
import { useStayInApp } from "@/components/player";
import { fetchSuggest } from "@/lib/api";
import { parsePastedUrl } from "@/lib/blaze/paste";
import { catsForOrientation } from "@/lib/blaze/categories";
import { ALL_SOURCES, SORT_LABELS, SOURCE_META, type SortMode } from "@/lib/blaze/types";
import { cn } from "@/lib/utils";
import { useTube } from "@/store/tube";

const ORIENTS = [
  { id: "straight", label: "Straight" },
  { id: "gay", label: "Gay" },
  { id: "trans", label: "Trans" },
] as const;

export function usePageTitle(title: string) {
  useEffect(() => {
    const prev = document.title;
    document.title = title;
    return () => {
      document.title = prev;
    };
  }, [title]);
}

export function goBackOrHome(navigate: ReturnType<typeof useNavigate>) {
  if (typeof window !== "undefined") {
    const prev = document.referrer;
    try {
      if (prev && new URL(prev).origin === window.location.origin && window.history.length > 1) {
        window.history.back();
        return;
      }
    } catch {
      /* fall through */
    }
    if (!prev && window.history.length > 1) {
      window.history.back();
      return;
    }
  }
  void navigate({ to: "/" });
}

export function Shell({
  children,
  query = "",
  activeCat,
}: {
  children: ReactNode;
  query?: string;
  activeCat?: string;
}) {
  useStayInApp();
  const [menu, setMenu] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isWatch = pathname.startsWith("/video/");

  useEffect(() => {
    setMenu(false);
  }, [pathname]);

  useEffect(() => {
    if (!menu) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenu(false);
    };
    document.addEventListener("keydown", onKey);
    document.body.classList.add("theater-open");
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.classList.remove("theater-open");
    };
  }, [menu]);

  return (
    <div className="min-h-svh bg-bg text-fg">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:rounded-sm focus:bg-accent focus:px-3 focus:py-2 focus:text-sm focus:font-semibold focus:text-accent-fg"
      >
        Skip to videos
      </a>
      {isWatch ? null : <Header query={query} menu={menu} onMenu={() => setMenu((v) => !v)} />}
      {menu ? <MenuDrawer activeCat={activeCat} onClose={() => setMenu(false)} /> : null}
      <main
        id="main"
        className={cn(
          "mx-auto w-full max-w-[1400px] px-3 pt-4 md:px-5",
          isWatch ? "pb-8 pt-3 md:pb-10" : "pb-24 md:pb-10",
        )}
      >
        {children}
      </main>
      {isWatch ? null : <MobileDock />}
      {isWatch ? null : (
        <footer className="hidden border-t border-border md:block">
          <div className="mx-auto flex max-w-[1400px] flex-wrap items-center justify-between gap-3 px-5 py-6 text-xs text-subtle">
            <p>BLAZE · 18+ adults only. Videos stay on this device — no accounts, no uploads.</p>
            <nav className="flex flex-wrap gap-1">
              <Link to="/categories" className="inline-flex h-11 items-center px-2 hover:text-fg">
                Categories
              </Link>
              <Link to="/networks" className="inline-flex h-11 items-center px-2 hover:text-fg">
                Networks
              </Link>
              <Link to="/later" className="inline-flex h-11 items-center px-2 hover:text-fg">
                Watch later
              </Link>
              <Link to="/settings" className="inline-flex h-11 items-center px-2 hover:text-fg">
                Settings
              </Link>
            </nav>
          </div>
        </footer>
      )}
    </div>
  );
}

function Header({
  query,
  menu,
  onMenu,
}: {
  query: string;
  menu: boolean;
  onMenu: () => void;
}) {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isWatch = pathname.startsWith("/video/");
  const orientation = useTube((s) => s.orientation);
  const setOrientation = useTube((s) => s.setOrientation);
  const laterCount = useTube((s) => s.later.length);
  const [value, setValue] = useState(query);
  const [suggests, setSuggests] = useState<string[]>([]);
  const [openSuggest, setOpenSuggest] = useState(false);
  const [activeSuggest, setActiveSuggest] = useState(-1);
  const formRef = useRef<HTMLFormElement>(null);
  const suggestRequest = useRef(0);

  useEffect(() => {
    setValue(query);
  }, [query]);

  useEffect(() => {
    const q = value.trim();
    const requestId = ++suggestRequest.current;
    if (q.length < 2 || parsePastedUrl(q)) {
      setSuggests([]);
      setOpenSuggest(false);
      return;
    }
    const t = window.setTimeout(() => {
      void fetchSuggest(q)
        .then((list) => {
          if (requestId !== suggestRequest.current) return;
          setSuggests(list.filter(Boolean).slice(0, 8));
          setActiveSuggest(-1);
        })
        .catch(() => {
          if (requestId === suggestRequest.current) setSuggests([]);
        });
    }, 160);
    return () => window.clearTimeout(t);
  }, [value]);

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (formRef.current && !formRef.current.contains(e.target as Node)) setOpenSuggest(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  function go(e: FormEvent) {
    e.preventDefault();
    const text = value.trim();
    setOpenSuggest(false);
    if (!text) {
      void navigate({ to: "/" });
      return;
    }
    const pasted = parsePastedUrl(text);
    if (pasted) {
      void navigate({ to: "/video/$id", params: { id: pasted } });
      return;
    }
    void navigate({ to: "/search", search: { q: text } });
  }

  function pickSuggest(term: string) {
    setValue(term);
    setOpenSuggest(false);
    setActiveSuggest(-1);
    void navigate({ to: "/search", search: { q: term } });
  }

  function onSearchKey(e: ReactKeyboardEvent<HTMLInputElement>) {
    if (e.key === "Escape") {
      setOpenSuggest(false);
      setActiveSuggest(-1);
      return;
    }
    if (!openSuggest || suggests.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveSuggest((i) => (i + 1) % suggests.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveSuggest((i) => (i <= 0 ? suggests.length - 1 : i - 1));
    } else if (e.key === "Enter" && activeSuggest >= 0 && suggests[activeSuggest]) {
      e.preventDefault();
      pickSuggest(suggests[activeSuggest]!);
    }
  }

  return (
    <header
      className={cn(
        "z-40 border-b border-border bg-bg/95 pt-[env(safe-area-inset-top)] backdrop-blur",
        isWatch ? "relative" : "sticky top-0",
      )}
    >
      <div className="mx-auto flex h-14 max-w-[1400px] items-center gap-2 px-3 md:gap-3 md:px-5">
        {isWatch ? (
          <button
            type="button"
            onClick={() => goBackOrHome(navigate)}
            className="inline-flex size-11 shrink-0 items-center justify-center rounded-sm text-fg hover:bg-surface-2"
            aria-label="Back to videos"
          >
            <ChevronLeft className="size-6" />
          </button>
        ) : (
          <button
            type="button"
            onClick={onMenu}
            className="inline-flex size-11 shrink-0 items-center justify-center rounded-sm text-muted hover:bg-surface-2 hover:text-fg"
            aria-label={menu ? "Close menu" : "Open menu"}
            aria-expanded={menu}
          >
            {menu ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        )}
        <Link to="/" className="inline-flex min-h-11 shrink-0 items-center" aria-label="BLAZE home">
          <BlazeLogo size="sm" />
        </Link>
        <form ref={formRef} onSubmit={go} className="relative flex min-w-0 flex-1 items-center gap-1.5">
          <label className="relative min-w-0 flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
            <input
              value={value}
              onChange={(e) => {
                setValue(e.target.value);
                setOpenSuggest(true);
              }}
              onFocus={() => setOpenSuggest(true)}
              onKeyDown={onSearchKey}
              placeholder="Search or paste a URL"
              aria-label="Search or paste a URL"
              className="h-10 w-full rounded-sm border border-border bg-surface-2 pr-3 pl-9 text-sm text-fg outline-none placeholder:text-subtle focus:border-accent"
              enterKeyHint="search"
              autoCapitalize="none"
              autoComplete="off"
              spellCheck={false}
              aria-autocomplete="list"
              aria-expanded={openSuggest && suggests.length > 0}
              aria-controls="search-suggest"
              aria-activedescendant={activeSuggest >= 0 ? `search-suggest-${activeSuggest}` : undefined}
              id="search-q"
            />
          </label>
          <button
            type="submit"
            className="inline-flex size-10 shrink-0 items-center justify-center rounded-sm bg-accent text-sm font-semibold text-accent-fg hover:bg-accent-hover sm:h-10 sm:w-auto sm:px-4"
            aria-label="Search"
          >
            <Search className="size-4 sm:hidden" />
            <span className="hidden sm:inline">Search</span>
          </button>
          {openSuggest && suggests.length > 0 ? (
            <ul
              id="search-suggest"
              className="absolute top-full left-0 z-50 mt-1 w-full min-w-0 overflow-hidden rounded-sm border border-border bg-surface shadow-player sm:max-w-lg"
              role="listbox"
            >
              {suggests.map((term, i) => (
                <li key={term} id={`search-suggest-${i}`} role="option" aria-selected={i === activeSuggest}>
                  <button
                    type="button"
                    className={cn(
                      "flex h-11 w-full items-center gap-2 px-3 text-left text-sm text-fg",
                      i === activeSuggest ? "bg-surface-2" : "hover:bg-surface-2",
                    )}
                    onClick={() => pickSuggest(term)}
                    onMouseEnter={() => setActiveSuggest(i)}
                  >
                    <Search className="size-3.5 shrink-0 text-subtle" />
                    <span className="truncate">{term}</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
        </form>
        {!isWatch ? (
          <div className="hidden items-center gap-0.5 lg:flex">
            {ORIENTS.map((o) => (
              <button
                key={o.id}
                type="button"
                onClick={() => setOrientation(o.id)}
                className={cn(
                  "h-10 rounded-full px-3 text-xs font-semibold",
                  orientation === o.id ? "bg-accent text-accent-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
                )}
              >
                {o.label}
              </button>
            ))}
          </div>
        ) : null}
        <nav className="flex shrink-0 items-center">
          <Link
            to="/later"
            className="relative inline-flex size-10 items-center justify-center rounded-sm text-muted hover:bg-surface-2 hover:text-fg"
            aria-label="Watch later"
          >
            <Bookmark className="size-5" />
            {laterCount > 0 ? (
              <span className="absolute top-1.5 right-1.5 size-1.5 rounded-full bg-accent" />
            ) : null}
          </Link>
          <Link
            to="/history"
            className="hidden size-10 items-center justify-center rounded-sm text-muted hover:bg-surface-2 hover:text-fg sm:inline-flex"
            aria-label="Watch history"
          >
            <Clock className="size-5" />
          </Link>
          <Link
            to="/settings"
            className="hidden size-10 items-center justify-center rounded-sm text-muted hover:bg-surface-2 hover:text-fg sm:inline-flex"
            aria-label="Settings"
          >
            <Settings className="size-5" />
          </Link>
        </nav>
      </div>
    </header>
  );
}

function MenuDrawer({ activeCat, onClose }: { activeCat?: string; onClose: () => void }) {
  const orientation = useTube((s) => s.orientation);
  const setOrientation = useTube((s) => s.setOrientation);
  const cats = catsForOrientation(orientation);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-labelledby="browse-title">
      <button type="button" className="absolute inset-0 bg-overlay" aria-label="Close menu" onClick={onClose} />
      <aside className="relative flex h-full w-[min(100%,20rem)] flex-col border-r border-border bg-surface shadow-player">
        <div className="flex h-14 items-center justify-between border-b border-border px-4">
          <p id="browse-title" className="font-display text-xl tracking-wide">Browse</p>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex size-10 items-center justify-center rounded-sm text-muted hover:bg-surface-2 hover:text-fg"
            aria-label="Close menu"
          >
            <X className="size-5" />
          </button>
        </div>
        <div className="flex gap-1 px-3 py-3">
          {ORIENTS.map((o) => (
            <button
              key={o.id}
              type="button"
              onClick={() => setOrientation(o.id)}
              className={cn(
                "h-10 flex-1 rounded-full text-xs font-semibold",
                orientation === o.id ? "bg-accent text-accent-fg" : "bg-surface-2 text-muted hover:text-fg",
              )}
            >
              {o.label}
            </button>
          ))}
        </div>
        <nav className="space-y-0.5 px-3 pb-2">
          <DrawerLink to="/" active={pathname === "/"} icon={<Home className="size-4" />} onClick={onClose}>
            Home
          </DrawerLink>
          <DrawerLink
            to="/categories"
            active={pathname === "/categories"}
            icon={<Grid3x3 className="size-4" />}
            onClick={onClose}
          >
            All categories
          </DrawerLink>
          <DrawerLink to="/networks" active={pathname === "/networks"} onClick={onClose}>
            Networks
          </DrawerLink>
          <DrawerLink to="/later" active={pathname === "/later"} onClick={onClose}>
            Watch later
          </DrawerLink>
          <DrawerLink to="/history" active={pathname === "/history"} onClick={onClose}>
            History
          </DrawerLink>
          <DrawerLink to="/settings" active={pathname === "/settings"} onClick={onClose}>
            Settings
          </DrawerLink>
        </nav>
        <p className="px-4 pt-2 pb-1 text-xs font-semibold tracking-wider text-subtle uppercase">Categories</p>
        <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-8">
          {cats.map((c) => (
            <Link
              key={c.slug}
              to="/cat/$slug"
              params={{ slug: c.slug }}
              onClick={onClose}
              className={cn(
                "flex h-10 items-center rounded-sm px-3 text-sm",
                activeCat === c.slug ? "bg-accent text-accent-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
              )}
            >
              {c.label}
            </Link>
          ))}
        </div>
      </aside>
    </div>
  );
}

function DrawerLink({
  to,
  active,
  icon,
  onClick,
  children,
}: {
  to: string;
  active: boolean;
  icon?: ReactNode;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className={cn(
        "flex h-10 items-center gap-2 rounded-sm px-3 text-sm font-medium",
        active ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
      )}
    >
      {icon}
      {children}
    </Link>
  );
}

export function CategoryChips({ active }: { active?: string }) {
  const orientation = useTube((s) => s.orientation);
  const cats = catsForOrientation(orientation);
  return (
    <div className="no-scrollbar -mx-1 mb-4 flex flex-nowrap gap-1.5 overflow-x-auto pb-1">
      {cats.map((c) => (
        <Link
          key={c.slug}
          to="/cat/$slug"
          params={{ slug: c.slug }}
          className={cn(
            "inline-flex h-10 shrink-0 items-center rounded-full px-3.5 text-xs font-medium",
            active === c.slug ? "bg-accent text-accent-fg" : "bg-surface-2 text-muted hover:bg-surface-3 hover:text-fg",
          )}
        >
          {c.label}
        </Link>
      ))}
      <Link
        to="/categories"
        className="inline-flex h-10 shrink-0 items-center rounded-full bg-surface-2 px-3.5 text-xs font-medium text-accent hover:bg-surface-3"
      >
        All
      </Link>
    </div>
  );
}

export function NetworkBar() {
  const net = useTube((s) => s.net);
  const setNet = useTube((s) => s.setNet);
  return (
    <div className="no-scrollbar mb-3 flex flex-nowrap gap-1.5 overflow-x-auto pb-1">
      <button
        type="button"
        onClick={() => setNet("all")}
        className={cn(
          "h-10 shrink-0 rounded-full px-3.5 text-xs font-semibold",
          net === "all" ? "bg-accent text-accent-fg" : "bg-surface-2 text-muted hover:text-fg",
        )}
      >
        All
      </button>
      {ALL_SOURCES.map((s) => (
        <button
          key={s}
          type="button"
          onClick={() => setNet(s)}
          className={cn(
            "h-10 shrink-0 rounded-full px-3.5 text-xs font-semibold",
            net === s ? "bg-accent text-accent-fg" : "bg-surface-2 text-muted hover:text-fg",
          )}
          title={SOURCE_META[s].label}
        >
          {SOURCE_META[s].short}
        </button>
      ))}
    </div>
  );
}

export function SortBar({ sort, onChange }: { sort: SortMode; onChange: (next: SortMode) => void }) {
  return (
    <div className="no-scrollbar mb-4 flex flex-nowrap gap-1 overflow-x-auto pb-1">
      {(Object.keys(SORT_LABELS) as SortMode[]).map((key) => (
        <button
          key={key}
          type="button"
          onClick={() => onChange(key)}
          className={cn(
            "h-10 shrink-0 rounded-full px-3.5 text-xs font-medium",
            sort === key ? "bg-accent text-accent-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
          )}
        >
          {SORT_LABELS[key]}
        </button>
      ))}
    </div>
  );
}

export function Pager({
  page,
  totalPages,
  onPage,
}: {
  page: number;
  totalPages: number;
  onPage: (page: number) => void;
}) {
  const pages = useMemo(() => {
    const max = Math.max(1, Math.min(totalPages, 80));
    const cur = Math.min(Math.max(1, page), max);
    const set = new Set<number>([1, max, cur, cur - 1, cur + 1, cur - 2, cur + 2]);
    return [...set].filter((n) => n >= 1 && n <= max).sort((a, b) => a - b);
  }, [page, totalPages]);

  if (totalPages <= 1) return null;

  return (
    <nav className="mt-8 flex items-center justify-center gap-1" aria-label="Pagination">
      <button
        type="button"
        disabled={page <= 1}
        onClick={() => onPage(page - 1)}
        className="inline-flex size-10 items-center justify-center rounded-sm bg-surface-2 text-muted disabled:opacity-40 hover:text-fg"
        aria-label="Previous page"
      >
        <ChevronLeft className="size-4" />
      </button>
      {pages.map((n, i) => {
        const gap = i > 0 && n - pages[i - 1]! > 1;
        return (
          <span key={n} className="flex items-center gap-1">
            {gap ? <span className="px-1 text-subtle">…</span> : null}
            <button
              type="button"
              onClick={() => onPage(n)}
              className={cn(
                "inline-flex size-10 items-center justify-center rounded-sm text-sm font-medium",
                n === page ? "bg-accent text-accent-fg" : "bg-surface-2 text-muted hover:text-fg",
              )}
            >
              {n}
            </button>
          </span>
        );
      })}
      <button
        type="button"
        disabled={page >= totalPages}
        onClick={() => onPage(page + 1)}
        className="inline-flex size-10 items-center justify-center rounded-sm bg-surface-2 text-muted disabled:opacity-40 hover:text-fg"
        aria-label="Next page"
      >
        <ChevronRight className="size-4" />
      </button>
    </nav>
  );
}

export function LoadError({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center gap-4 py-16 text-center">
      <p className="text-sm text-muted">{message}</p>
      <button
        type="button"
        onClick={onRetry}
        className="inline-flex h-11 items-center rounded-sm bg-accent px-5 text-sm font-semibold text-accent-fg hover:bg-accent-hover"
      >
        Try again
      </button>
    </div>
  );
}

function MobileDock() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const laterCount = useTube((s) => s.later.length);
  const items = [
    { to: "/", label: "Home", icon: Home, match: pathname === "/" },
    {
      to: "/categories",
      label: "Browse",
      icon: Grid3x3,
      match: pathname === "/categories" || pathname.startsWith("/cat/"),
    },
    { to: "/later", label: "Later", icon: Bookmark, match: pathname === "/later", badge: laterCount > 0 },
    { to: "/history", label: "History", icon: Clock, match: pathname === "/history" },
    { to: "/settings", label: "Settings", icon: Settings, match: pathname === "/settings" },
  ] as const;

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
      <div className="mx-auto flex h-14 max-w-lg items-stretch px-1">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "relative flex flex-1 flex-col items-center justify-center gap-0.5 text-xs font-medium",
                item.match ? "text-accent" : "text-muted",
              )}
            >
              <Icon className="size-5" />
              {item.label}
              {"badge" in item && item.badge ? (
                <span className="absolute top-1 left-1/2 size-1.5 translate-x-2 rounded-full bg-accent" />
              ) : null}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
