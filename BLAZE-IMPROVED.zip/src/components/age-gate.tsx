import { useLayoutEffect, useState, type ReactNode } from "react";
import { BlazeLogo } from "@/components/logo";

const ADULT_KEY = "blaze-18";
const EXIT_URL = "https://www.wikipedia.org/";

let memoryOk = false;

function readOk(): boolean {
  if (memoryOk) return true;
  if (typeof window === "undefined") return false;
  try {
    if (window.localStorage.getItem(ADULT_KEY) === "1") return true;
  } catch {
    /* ignore */
  }
  try {
    if (window.sessionStorage.getItem(ADULT_KEY) === "1") return true;
  } catch {
    /* ignore */
  }
  try {
    if (document.cookie.split(";").some((part) => part.trim().startsWith(`${ADULT_KEY}=1`))) {
      return true;
    }
  } catch {
    /* ignore */
  }
  return false;
}

function writeOk() {
  memoryOk = true;
  try {
    window.localStorage.setItem(ADULT_KEY, "1");
  } catch {
    /* ignore */
  }
  try {
    window.sessionStorage.setItem(ADULT_KEY, "1");
  } catch {
    /* ignore */
  }
  try {
    document.cookie = `${ADULT_KEY}=1; path=/; max-age=31536000; samesite=lax`;
  } catch {
    /* ignore */
  }
}

export function resetAgeGate() {
  memoryOk = false;
  try {
    window.localStorage.removeItem(ADULT_KEY);
  } catch {
    /* ignore */
  }
  try {
    window.sessionStorage.removeItem(ADULT_KEY);
  } catch {
    /* ignore */
  }
  try {
    document.cookie = `${ADULT_KEY}=; path=/; max-age=0; samesite=lax`;
  } catch {
    /* ignore */
  }
}

export function AgeGate({ onEnter }: { onEnter: () => void }) {
  useLayoutEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  function enter() {
    writeOk();
    document.body.style.overflow = "";
    onEnter();
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="age-title"
      className="fixed inset-0 z-[100] overflow-y-auto overscroll-contain bg-bg"
    >
      <div aria-hidden="true" className="age-glow pointer-events-none absolute inset-x-0 top-0 h-64" />
      <div className="relative mx-auto flex min-h-svh w-full max-w-md flex-col justify-center px-5 py-8">
        <div className="flex justify-center">
          <BlazeLogo size="lg" />
        </div>
        <h1
          id="age-title"
          className="mt-5 text-center font-display text-4xl font-semibold tracking-wide text-fg"
        >
          18+ only
        </h1>
        <p className="mt-3 text-center text-sm leading-relaxed text-muted">
          BLAZE is an adults-only video tube. You must be 18 or older to enter.
        </p>
        <div className="sticky bottom-0 z-10 mt-8 flex flex-col gap-3 bg-bg pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          <button
            type="button"
            onClick={enter}
            autoFocus
            className="flex h-14 w-full touch-manipulation items-center justify-center rounded-sm bg-accent text-base font-semibold tracking-wide text-accent-fg hover:bg-accent-hover"
          >
            I am 18 or older — enter
          </button>
          <button
            type="button"
            onClick={() => {
              try {
                window.location.href = window.top && window.top !== window ? "about:blank" : EXIT_URL;
              } catch {
                window.location.href = EXIT_URL;
              }
            }}
            className="flex h-12 w-full touch-manipulation items-center justify-center rounded-sm border border-border bg-surface-2 text-sm font-medium text-fg hover:bg-surface-3"
          >
            Exit
          </button>
        </div>
        <p className="mt-4 text-center text-xs leading-relaxed text-subtle">
          Content involving minors, animals, or other illegal material is blocked.
          This confirmation stays on this device. It is not identity verification.
        </p>
      </div>
    </div>
  );
}

export function AgeWall({ children }: { children: ReactNode }) {
  const [ok, setOk] = useState(false);

  useLayoutEffect(() => {
    if (readOk()) setOk(true);
  }, []);

  function enter() {
    writeOk();
    document.body.style.overflow = "";
    setOk(true);
  }

  if (!ok) {
    return <AgeGate onEnter={enter} />;
  }

  return <>{children}</>;
}
