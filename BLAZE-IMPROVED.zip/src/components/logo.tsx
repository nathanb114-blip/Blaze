import { cn } from "@/lib/utils";

export function BlazeMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("shrink-0", className)}
      aria-hidden="true"
    >
      <path
        d="M16 2.5c1.4 4.2 2 7.1 1.2 9.6-.5 1.6-1.6 2.9-2.2 4.4 2.8-1 5.6-3.4 7.4-6.2 2.6 4.3 3.2 8.1 1.6 11.4C22.2 25.7 19.4 28 16 29.5 12.6 28 9.8 25.7 8 21.7c-1.6-3.3-1-7.1 1.6-11.4 1.8 2.8 4.6 5.2 7.4 6.2-.6-1.5-1.7-2.8-2.2-4.4C14 9.6 14.6 6.7 16 2.5Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function BlazeLogo({
  size = "md",
  wordmark = true,
}: {
  size?: "sm" | "md" | "lg";
  wordmark?: boolean;
}) {
  const mark = size === "lg" ? "h-11 w-11" : size === "sm" ? "h-6 w-6" : "h-8 w-8";
  const type =
    size === "lg" ? "text-6xl" : size === "sm" ? "text-2xl" : "text-3xl leading-none";
  return (
    <span className="inline-flex items-center gap-1.5 text-accent">
      <BlazeMark className={mark} />
      {wordmark ? (
        <span className={cn("font-display font-semibold tracking-[0.14em] text-fg", type)}>
          BLAZE
        </span>
      ) : null}
    </span>
  );
}
