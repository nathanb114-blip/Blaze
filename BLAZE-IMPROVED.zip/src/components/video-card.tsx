import { Link } from "@tanstack/react-router";
import { Bookmark, BookmarkCheck, Play } from "lucide-react";
import type { VideoCard as VideoCardData } from "@/lib/blaze/types";
import { SOURCE_META, type SortMode } from "@/lib/blaze/types";
import { formatDuration, formatViews, timeAgo } from "@/lib/utils";
import { useTube, type HistoryItem } from "@/store/tube";

export function VideoCard({ video }: { video: VideoCardData }) {
  const later = useTube((s) => s.isLater(video.id));
  const toggleLater = useTube((s) => s.toggleLater);
  const progress = useTube((s) => s.progress[video.id] ?? 0);
  const source = SOURCE_META[video.source] ?? SOURCE_META.eporner;
  const pct = video.duration && progress > 0 ? Math.min(100, (progress / video.duration) * 100) : 0;
  const watchedAt = "watchedAt" in video ? (video as HistoryItem).watchedAt : undefined;

  return (
    <article className="group relative">
      <Link to="/video/$id" params={{ id: video.id }} className="block" aria-label={video.title}>
        <div className="relative aspect-video overflow-hidden rounded-sm bg-surface-2">
          {video.thumbnail ? (
            <img
              src={video.thumbnail}
              alt=""
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.04]"
              loading="lazy"
              decoding="async"
              onError={(e) => {
                e.currentTarget.style.display = "none";
              }}
            />
          ) : (
            <div className="flex h-full items-center justify-center text-subtle">
              <Play className="size-8" />
            </div>
          )}
          <div className="thumb-shade pointer-events-none absolute inset-0" />
          <span className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-150 group-hover:opacity-100">
            <span className="flex size-12 items-center justify-center rounded-full bg-accent text-accent-fg shadow-card">
              <Play className="size-5 fill-current" />
            </span>
          </span>
          {video.hd ? (
            <span className="absolute top-1.5 left-1.5 rounded-xs bg-accent px-1.5 py-0.5 font-display text-xs font-semibold tracking-wider text-accent-fg">
              HD
            </span>
          ) : null}
          <span className="absolute bottom-1.5 left-1.5 rounded-xs bg-overlay px-1.5 py-0.5 font-sans text-xs font-medium text-fg">
            {source.short}
          </span>
          {video.duration ? (
            <span className="absolute right-1.5 bottom-1.5 rounded-xs bg-overlay px-1.5 py-0.5 font-sans text-xs font-medium tabular-nums text-fg">
              {formatDuration(video.duration)}
            </span>
          ) : null}
          {pct > 2 ? (
            <span className="absolute inset-x-0 bottom-0 h-0.5 bg-surface-3">
              <span className="block h-full bg-accent" style={{ width: `${pct}%` }} />
            </span>
          ) : null}
        </div>
        <h3 className="mt-2 line-clamp-2 text-sm leading-snug font-medium hyphens-none text-fg group-hover:text-accent">
          {video.title}
        </h3>
        <p className="mt-1 text-xs text-subtle tabular-nums">
          {[
            watchedAt ? timeAgo(watchedAt) : "",
            formatViews(video.views) && `${formatViews(video.views)} views`,
            video.rating != null && `${Math.round(video.rating)}%`,
            source.label,
          ]
            .filter(Boolean)
            .join(" · ")}
        </p>
      </Link>
      <button
        type="button"
        aria-label={later ? "Remove from watch later" : "Save to watch later"}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          toggleLater(video);
        }}
        className="absolute top-1.5 right-1.5 flex size-10 items-center justify-center rounded-xs bg-overlay text-fg opacity-0 transition-opacity group-hover:opacity-100 group-focus-within:opacity-100 focus-visible:opacity-100 hover:text-accent max-md:opacity-100"
      >
        {later ? <BookmarkCheck className="size-4" /> : <Bookmark className="size-4" />}
      </button>
    </article>
  );
}

export function VideoGrid({
  videos,
  empty = "No videos found.",
}: {
  videos: VideoCardData[];
  empty?: string;
}) {
  const hiddenIds = useTube((s) => s.hiddenIds);
  const visible = videos.filter((v) => !hiddenIds.includes(v.id));
  if (!visible.length) {
    return (
      <div className="flex flex-col items-center gap-3 rounded-sm border border-dashed border-border bg-surface/40 px-5 py-14 text-center">
        <Play className="size-7 text-subtle" aria-hidden="true" />
        <p className="text-sm font-medium text-muted">{empty}</p>
        <Link
          to="/"
          className="inline-flex h-11 items-center rounded-sm bg-surface-2 px-4 text-sm font-semibold text-fg hover:bg-surface-3"
        >
          Browse popular videos
        </Link>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6">
      {visible.map((v) => (
        <VideoCard key={v.id} video={v} />
      ))}
    </div>
  );
}

export function VideoRail({
  title,
  videos,
  seeAll,
}: {
  title: string;
  videos: VideoCardData[];
  seeAll?: { to: "/history" } | { to: "/search"; q: string } | { to: "/"; sort: SortMode };
}) {
  const hiddenIds = useTube((s) => s.hiddenIds);
  const visible = videos.filter((v) => !hiddenIds.includes(v.id));
  if (!visible.length) return null;
  return (
    <section className="mb-8">
      <div className="mb-3 flex items-end justify-between gap-3">
        <h2 className="font-display text-2xl tracking-wide">{title}</h2>
        {seeAll?.to === "/history" ? (
          <Link to="/history" className="inline-flex h-11 items-center px-2 text-sm font-medium text-accent hover:text-accent-hover">
            See all
          </Link>
        ) : seeAll?.to === "/search" ? (
          <Link
            to="/search"
            search={{ q: seeAll.q, page: 1, sort: "most-popular" }}
            className="inline-flex h-11 items-center px-2 text-sm font-medium text-accent hover:text-accent-hover"
          >
            See all
          </Link>
        ) : seeAll?.to === "/" ? (
          <Link
            to="/"
            search={{ sort: seeAll.sort, page: 1 }}
            className="inline-flex h-11 items-center px-2 text-sm font-medium text-accent hover:text-accent-hover"
          >
            See all
          </Link>
        ) : null}
      </div>
      <div className="no-scrollbar -mx-1 flex flex-nowrap gap-3 overflow-x-auto px-1 pb-2">
        {visible.slice(0, 14).map((v) => (
          <div key={v.id} className="w-44 shrink-0 sm:w-52">
            <VideoCard video={v} />
          </div>
        ))}
      </div>
    </section>
  );
}

export function VideoGridSkeleton({ count = 18 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="animate-pulse">
          <div className="aspect-video rounded-sm bg-surface-2" />
          <div className="mt-2 h-3 w-5/6 rounded-xs bg-surface-2" />
          <div className="mt-1.5 h-2.5 w-1/3 rounded-xs bg-surface-2" />
        </div>
      ))}
    </div>
  );
}
